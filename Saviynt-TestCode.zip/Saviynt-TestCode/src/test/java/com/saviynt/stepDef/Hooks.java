package com.saviynt.stepDef;

import java.io.IOException;

import com.saviynt.pageobject.BaseClass;

import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks {
	


	@Before()
	public void beforeScenario() {
		System.out.println("*************Saviynt Automation testing***********");

	}

	@AfterStep
	public void addScreenshot(Scenario scenario) throws IOException {

		scenario.attach(BaseClass.getByteScreenshot(), "image/png", "image");

	}

	@After
	public void afterScenario() {
		System.out.println("############End##########");
	}
}