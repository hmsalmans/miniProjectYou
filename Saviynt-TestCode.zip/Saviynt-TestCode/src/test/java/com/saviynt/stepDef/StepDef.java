package com.saviynt.stepDef;

import java.awt.AWTException;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import com.saviynt.pageobject.AdminPage;
import com.saviynt.pageobject.ApplicationsPage;
import com.saviynt.pageobject.BaseClass;
import com.saviynt.pageobject.CertificationPage;
import com.saviynt.pageobject.ChangeOfPosition;
import com.saviynt.pageobject.DelegatePage;
import com.saviynt.pageobject.EntitlementPage;
import com.saviynt.pageobject.LOA_LTDPage;
import com.saviynt.pageobject.LoginPage;
import com.saviynt.pageobject.LogoutPage;
import com.saviynt.pageobject.RoleCreationPage;
import com.saviynt.pageobject.SODPage;
import com.saviynt.pageobject.SecuritySystem;
import com.saviynt.pageobject.SelectCsvFileForUpload;
import com.saviynt.pageobject.UserCreationPage;
import com.saviynt.pageobject.UserTermimnation;
import com.saviynt.pageobject.UserUpdationPage;
import com.saviynt.pageobject.WorkFlow;
import com.utils.BrowserUtil;
import com.utils.ExcelUtil;
import com.utils.commonFunctionUtil;
import com.saviynt.pageobject.BirthRightAccessValidationPage;
import org.junit.Assert;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class StepDef extends BaseClass {
	Scenario scenario; // for parallel execution
	@Before
	public void SetUp(Scenario s) {
		scenario = s;
	}
	
	String projectPath=System.getProperty("user.dir");
	
	private static Logger log = LogManager.getLogger();
	
	BrowserUtil browser = new BrowserUtil();
	
	LoginPage lp = new LoginPage(driver);
	LogoutPage logout = new LogoutPage(driver);
	UserCreationPage uc = new UserCreationPage(driver);
	UserUpdationPage update = new UserUpdationPage(driver);
	UserTermimnation ut = new UserTermimnation(driver);
	AdminPage ap = new AdminPage(driver);
	ApplicationsPage apps = new ApplicationsPage(driver);
	RoleCreationPage rc = new RoleCreationPage(driver);
	WorkFlow wf = new WorkFlow(driver);
	EntitlementPage ep = new EntitlementPage(driver);
	SecuritySystem ss = new SecuritySystem(driver);
	LOA_LTDPage leaveStatus = new LOA_LTDPage(driver);
	ChangeOfPosition changePositionCertification = new ChangeOfPosition(driver);
	CertificationPage cp = new CertificationPage(driver);
	BirthRightAccessValidationPage ba = new BirthRightAccessValidationPage(driver);
	SODPage sod = new SODPage(driver);
	DelegatePage delegate = new DelegatePage(driver);
	commonFunctionUtil commonFunction=new commonFunctionUtil();
	SelectCsvFileForUpload selectFile=new SelectCsvFileForUpload(driver);
	ExcelUtil common = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","common");
	ExcelUtil usersheet = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","user");
	ExcelUtil entitlement = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","entitlement");
	ExcelUtil workflow = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","workflow");
	ExcelUtil roleSheet = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","role");
	ExcelUtil userLifeCycleManagement = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","UserLifeCycle");
	ExcelUtil appOwnerCertificationSheet = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","appOwnerCertification");
	ExcelUtil certification = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","ceritification");
	ExcelUtil sodSheet = new ExcelUtil(projectPath+"/src/test//resources/TestData/InputParameterSheet.xlsx","sod");
	
	/*// Login details
	
	String UserTypeForLogin = common.readCellValue(0, 1);
	String AdminUserName = common.readCellValue(1, 1);
	String AdminPassword = common.readCellValue(2, 1);
	String managerUserName = common.readCellValue(3, 1);
	String managerPassword = common.readCellValue(4, 1);
	String managersManagerUserName = common.readCellValue(5, 1);
	String managersManagerPassword = common.readCellValue(6, 1);
	*/
	//String ExternalUserName = excel.readCellValue(7, 1);
	//String ExternalPassword = excel.readCellValue(8, 1);
	/*String ExternalUserNameForSingleWorkFlow = common.readCellValue(7, 1);
	String ExternalPasswordForSingleWorkFlow = common.readCellValue(8, 1);
	String ExternalUserNameForTwoLevelWorkFlow = common.readCellValue(9, 1);
	String ExternalPasswordForTwoLevelWorkFlow = common.readCellValue(10, 1);
	String externalUserNameForEntitlementApproval = common.readCellValue(11, 1);
	String externalUserPasswordForEntitlementApproval = common.readCellValue(12, 1);
	String ExternalUserNameForTwoLevelSerialWorkFlow = common.readCellValue(13, 1);
	String ExternalPasswordForTwoLevelSerialWorkFlow = common.readCellValue(14, 1);
	String EntitlementMetaDataUserName = common.readCellValue(15, 1);
	String EntitlementMetaDataPassword = common.readCellValue(16, 1);
	String WorkFlowUserName = common.readCellValue(17, 1);
	String WorkFlowFirstName = common.readCellValue(18, 1);
	String WorkFlowLastName = common.readCellValue(19, 1);
	String ExternalUserNameSOD = common.readCellValue(20, 1);
	String ExternalPasswordSOD = common.readCellValue(21, 1);
	*/
	// User details
	String userType = usersheet.readCellValue(0, 1);
	String category = usersheet.readCellValue(1, 1);
	String employeeType = usersheet.readCellValue(2, 1);
	String firstName = usersheet.readCellValue(3, 1);
	String lastName = usersheet.readCellValue(4, 1);
	String fullName = usersheet.readCellValue(5, 1);
	String jobTitle = usersheet.readCellValue(6, 1);
	String managerName = usersheet.readCellValue(7, 1);
	String hrEmployeeId = usersheet.readCellValue(8, 1);
	String partnerAccess = usersheet.readCellValue(9, 1);
	String partnerFirstName = usersheet.readCellValue(10, 1);
	String partnerLastName = usersheet.readCellValue(11, 1);
	String email = usersheet.readCellValue(12, 1);
	// Role Details
	String roleName = roleSheet.readCellValue(0, 1);
	String roleType = roleSheet.readCellValue(1, 1);
	String roleDisplay = roleSheet.readCellValue(2, 1);
	String roleDescription = roleSheet.readCellValue(3, 1);
	String role2 = roleSheet.readCellValue(4, 1);
	String roleType2 = roleSheet.readCellValue(5, 1);
	String role3 = roleSheet.readCellValue(6, 1);
	String roleType3=roleSheet.readCellValue(7, 1);
	String roleOwner = roleSheet.readCellValue(8, 1);
	String roleEntitlementName = roleSheet.readCellValue(9, 1);
	String childRole = roleSheet.readCellValue(10, 1);
	String existingRoleName=roleSheet.readCellValue(11, 1);
	String roleToRequestAccess = roleSheet.readCellValue(12, 1);
	String roleAccessToUser= roleSheet.readCellValue(13, 1);
	String externalUserNameForRole=common.readCellValue(22, 1);
	String externalUserPasswordForRole=common.readCellValue(23, 1);

	// Entitlement Details
	String entitlementName = entitlement.readCellValue(0, 1);
	String securitySys = entitlement.readCellValue(1, 1);
	String endPointValue = entitlement.readCellValue(2, 1);
	String entitlementTypeValue = entitlement.readCellValue(3, 1);
	String entitlementDescription = entitlement.readCellValue(4, 1);
	String entitlementOwner = entitlement.readCellValue(5, 1);
	String associateEntitlement = entitlement.readCellValue(6, 1);
	String soxCriticalValue = entitlement.readCellValue(7, 1);
	String SyscriticalValue = entitlement.readCellValue(8, 1);
	String RiskValue = entitlement.readCellValue(9, 1);
	String EntitlementRoleName = entitlement.readCellValue(10, 1);
	String EntilementMap = entitlement.readCellValue(11, 1);
	String manageEntitlementTab = entitlement.readCellValue(12, 1);
	String entitlementStatus = entitlement.readCellValue(13, 1);
	String userForInactiveEntitlement = entitlement.readCellValue(14, 1);
	String EntitmentForInactiveValidation = entitlement.readCellValue(15, 1);
	String EntitmentWithAssociateEntitlement = entitlement.readCellValue(16, 1);
	String entitlementTypeName = entitlement.readCellValue(17, 1);
	String entitlementTypeDisplayName = entitlement.readCellValue(18, 1);
	String entitlementMetaDataName = entitlement.readCellValue(19, 1);
	String entitlementTypeNameUpdate = entitlement.readCellValue(20, 1);
	String entitlementTypeDisplayNameUpdate = entitlement.readCellValue(21, 1);
	String entitlementTypeDescription = entitlement.readCellValue(22, 1);
	//String externalUserNameForEntitlementApproval = excel.readCellValue(55, 1);
	//String externalUserPasswordForEntitlementApproval = excel.readCellValue(56, 1);

	// WorkFlow Details
	String SingleManagerWorkFlowName = workflow.readCellValue(0, 1);
	String TwoManagerWorkFlowName = workflow.readCellValue(1, 1);
	String TwoLevelSerialWorkFlowName = workflow.readCellValue(2, 1);
	String SecuritySystemSingleLevel = workflow.readCellValue(3, 1);
	String SecuritySystemTwoLevel = workflow.readCellValue(4, 1);
	String SecuritySystemTwoLevelSerial = workflow.readCellValue(5, 1);
	String accountNameOfAnUserWhileRequestingAccess = workflow.readCellValue(6, 1);
	String enableAccount = workflow.readCellValue(7, 1);
	String delegateReason = workflow.readCellValue(8, 1);
	String delegateDescription = workflow.readCellValue(9, 1);
	String delegateParentUser = workflow.readCellValue(10, 1);
	String delegateUser = workflow.readCellValue(11, 1);
	String delegateStartDate = workflow.readCellValue(12, 1);
	String delegateEndDate = workflow.readCellValue(13, 1);
	String inactiveUser = workflow.readCellValue(14, 1);
	String accountNameOfAnUserWhilerequestingAccessForManagerTermination = workflow.readCellValue(15, 1);
	String accountNameOfAnUserNeedToLock = workflow.readCellValue(16, 1);
	String lockAccount = workflow.readCellValue(17, 1);
	String unlockAccount = workflow.readCellValue(18, 1);
	String STA_Entitlement = workflow.readCellValue(19, 1);
	String EntitlementForTwoLevelSerialWorkflow = workflow.readCellValue(20, 1);
	String entitlementForInflightRequest= workflow.readCellValue(21, 1);

	// User LifeCycle Management
	String changeOfPositionCampaigName = userLifeCycleManagement.readCellValue(0, 1);
	String changeOfPositionCertificationName = userLifeCycleManagement.readCellValue(1, 1);
	String changeOfPositionUserName=userLifeCycleManagement.readCellValue(2, 1);
	String changeOfPositionTotalNumberOfAccountsUserIsPartOf=userLifeCycleManagement.readCellValue(3, 1);

	// certification
	String appOwnercampaignName = certification.readCellValue(0, 1);
	// String ceritificationName = certification.readCellValue(1, 1);
	String systemNameForCertifying= certification.readCellValue(1, 1);
	String eusername = certification.readCellValue(2, 1);
	String epassword = certification.readCellValue(3, 1);
	String commentForAddingSignature = certification.readCellValue(4, 1);
	String appOwnerCertificationName=certification.readCellValue(5, 1);
	String userManagerCampaignName=certification.readCellValue(6, 1);
	String userManagerCertificationName=certification.readCellValue(7, 1);
	String systemNameForCertifyingForQV=certification.readCellValue(8, 1);
	String roleOwnercampaignName = certification.readCellValue(9, 1);
	String roleOwnerCertificationName=certification.readCellValue(10, 1);

	// SOD
	//String UserForSODViolation = sodSheet.readCellValue(64, 1);
	//String UserFirstNameForSODViolation = sodSheet.readCellValue(65, 1);
	//String UserLastNameForSODViolation = sodSheet.readCellValue(66, 1);
	String Entitlement1ForSODViolation = sodSheet.readCellValue(0, 1);
	String Entitlement2ForSODViolation = sodSheet.readCellValue(1, 1);
	String accountNameOfAnUserWhileRequestingAccessForSOD=sodSheet.readCellValue(2, 1);
	String UserForSODViolationwhenSODActioned = sodSheet.readCellValue(69, 1);
	String UserFirstNameForSODViolationwhenSODActioned = sodSheet.readCellValue(70, 1);
	String UserLastNameForSODViolationwhenSODActioned = sodSheet.readCellValue(71, 1);
	String UserForPreventitiveSODViolation = sodSheet.readCellValue(72, 1);
	String UserFirstNameForPreventitiveSODViolation = sodSheet.readCellValue(73, 1);
	String UserLastNameForPreventiveSODViolation = sodSheet.readCellValue(74, 1);
	String user = firstName;
	String externalUserNameForEntitlementApproval=getValue("externalUserNameForSingleWorkFlow");
	String userWorkFlow = externalUserNameForEntitlementApproval;
	//String updateMiddleName = "Automation";
	//String updateLocation = "Hyderabad";

	/**
	 * * This method is for launching Saviynt URL.       
	 * * @param Property
	 * file with details of URL     updateRoleWithEntitlementDetails()
	 * 
	 */

	@Given("User launches saviynt tool")
	public void launch_saviynt_tool() throws InterruptedException {
		try {
			String url=getValue("url");
			/*
			FileReader reader = new FileReader(
					System.getProperty("user.dir") + "\\src\\test\\resources\\configs\\Saviynt_NewQA.properties");
			Properties p = new Properties();
			p.load(reader);
			String url = p.getProperty("url");
			 */
			log.info("Saviynt tool has been Launched");
			driver.manage().deleteAllCookies();
			driver.manage().window().maximize();
			driver.get(url);
			Thread.sleep(2000);
			if (driver.findElement(By.xpath("//img[@class='login-logo']")).isDisplayed())
				highLightElement(driver, driver.findElement(By.xpath("//img[@class='login-logo']")));
			else
				Assert.fail("User is not on saviynt login page");

		} catch (Exception e) {
			log.info("Property not found exception");
			Thread.sleep(1000);
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
			log.info(e);
		}

	}

	/**
	 ** This method is for admin login.       
	 * @param admin username      
	 * * @param admin password     
	 */

	@And("User logs in as admin")
	public void enterAdminCrednetials() {
		String AdminUserName=getValue("adminUserName");
		String AdminPassword=getValue("adminPassword");
		try {
			lp.setUserName(AdminUserName);
			lp.setPassword(AdminPassword);
			lp.clickSubmit();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}
	}

	/**
	 *        * This method is for manager login.       
	 * * @param manager username 
	 *      * @param manager password     
	 */

	@And("User logs in as Manager or role owner")
	public void enterManagerCrednetials() {
		String managerUserName=getValue("managerUserName");
		String managerPassword=getValue("managerPassword");
		try {
			lp.setUserName(managerUserName);
			lp.setPassword(managerPassword);
			lp.clickSubmit();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}
	}

	/**
	 *        * This method is for External user login for Entitlement.      
	 * * @param external username       * @param external password     
	 */
	@And("User logs in as External User for Entitlement")
	public void enterExternalUserCrednetialsForEntitlement() {
		String externalUserNameForEntitlementApproval=getValue("externalUserNameForEntitlementApproval");
		String externalUserPasswordForEntitlementApproval=getValue("externalUserPasswordForEntitlementApproval");
		try {
			lp.setUserName(externalUserNameForEntitlementApproval);
			lp.setPassword(externalUserPasswordForEntitlementApproval);
			lp.clickSubmit();
			Thread.sleep(2000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}

	}

	/**
	 *        * This method is for External user login for Single workflow.      
	 * * @param external username       * @param external password     
	 */
	@And("User logs in as External User for Single WorkFlow")
	public void enterExternalUserCrednetials() {
		String externalUserNameForSingleWorkFlow=getValue("externalUserNameForSingleWorkFlow");
		String externalPasswordForSingleWorkFlow=getValue("externalPasswordForSingleWorkFlow");

		try {
			lp.setUserName(externalUserNameForSingleWorkFlow);
			lp.setPassword(externalPasswordForSingleWorkFlow);
			lp.clickSubmit();
			Thread.sleep(2000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}

	}

	/**
	 *        * This method is for External user login for Two workflow.      
	 * * @param external username       * @param external password     
	 */

	@And("User logs in as External User for Two Level WorkFlow")
	public void enterExternalUserCrednetialsTwoLevelWorkFlow() {
		String externalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		String externalPasswordForTwoLevelWorkFlow=getValue("externalUserPasswordForTwoLevelWorkFlow");

		try {
			lp.setUserName(externalUserNameForTwoLevelWorkFlow);
			lp.setPassword(externalPasswordForTwoLevelWorkFlow);
			lp.clickSubmit();
			Thread.sleep(2000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}

	}

	/**
	 * * This method is for External user login for Two level Serial workflow.      
	 * * @param external username       
	 * * @param external password     
	 */
	@And("User logs in as External User for Two Level Serial WorkFlow")
	public void enterExternalUserCrednetialsTwoLevelSerialWorkFlow() {
		String externalUserNameForTwoLevelSerialWorkFlow=getValue("externalUserNameForTwoLevelSerialWorkFlow");
		String externalPasswordForTwoLevelSerialWorkFlow=getValue("externalPasswordForTwoLevelSerialWorkFlow");
		try {
			lp.setUserName(externalUserNameForTwoLevelSerialWorkFlow);
			lp.setPassword(externalPasswordForTwoLevelSerialWorkFlow);
			lp.clickSubmit();
			Thread.sleep(2000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}

	}

	/**
	 ** This method is for External user login SOD.      
	 * * @param external username      
	 *  * @param external password     
	 */

	@And("User logs in as External User for SOD")
	public void enterExternalUserSOD() {
		String externalUserNameSOD=getValue("externalUserNameSOD");
		String externalPasswordSOD=getValue("externalPasswordSOD");

		try {
			lp.setUserName(externalUserNameSOD);
			lp.setPassword(externalPasswordSOD);
			lp.clickSubmit();
			Thread.sleep(2000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}

	}

	/**
	 ** This method is  validate user has logged into Saviynt Application      
	 */

	@And("User login to saviynt tool successfully")
	public void user_login_to_saviynt_tool_successfully() {
		try {
			lp.loginCheck();
			highLightElement(driver, driver.findElement(By.xpath("//*[contains(text(), 'You are logged in')]")));
		} catch (Exception e) {
			log.info("User has not logged into the application successfully");
			e.printStackTrace();
		}

	}

	@Given("User navigates to create user request from User management")
	public void navigateToCreateUserRequest() throws Exception {
		try {
			log.info("navigating to create user request");
			uc.navigateToCreateUserRequest();
			takeSnapShot(driver, "CreateUserRequest");
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Given("User provides the detials of new user")
	public void detialsOfUser() throws Exception {
		try {
			log.info("providing the detials of new user");
			uc.provideUserDetails(firstName, lastName, fullName, jobTitle, managerName, hrEmployeeId, partnerAccess,
					partnerFirstName, partnerLastName, email);

		} catch (InterruptedException e) {
			log.info("Register element is not found.");
			throw (e);
		}

	}

	@Then("User submits the user request")
	public void submitRequest() throws Exception {
		try {
			log.info(" submit the user request");
			uc.submitCreateUserRequest();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Given("User navigates to upload user request from User management")
	public void navigateToUploadUserRequest() throws Exception {
		try {
			log.info("Navigate to Upload user request");
			uc.navigateToUploadUserRequest();
			highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));
			driver.navigate().refresh();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Given("User provides the file in .csv containing detials of new users")
	public void detialsOfUsers() throws Exception {
		log.info("providing the detials of new user");
		uc.provideCSV();

	}

	@Given("User Provides file other than .csv format containing details of new user")
	public void detialsOfUsersOtherThanCSV() throws Exception {
		log.info("providing the detials of new user");
		uc.provideFiletherThanCSV();

	}

	@Given("User provides file in .csv containing detials of update")
	public void detialsOfUsersUpdate() throws Exception {
		log.info("providing the detials of Update for an Existing User");
		uc.provideCSVWithUpdateDetails("UpdateUsersList.csv");

	}

	@Given("User provides file in .csv containing detials of termination")
	public void detialsOfUsersTermination() throws Exception {
		log.info("providing the detials of termination for an Existing User");
		uc.provideCSVWithTerminationDetails("TerminationUsersList.csv");

	}

	@Given("User provides the file in .csv containing detials of manager which status needs to be marked as inactive")
	public void detialsOfManagerTermination() throws Exception {
		log.info("providing the detials of manager's termination");
		uc.provideCSVWithManagerTerminationDetails();

	}

	@Given("User provides the file in .csv containing detials of manager which status needs to be marked as active from inactive")
	public void detialsOfManagerActivation() throws Exception {
		log.info("providing the detials of manager's activation");
		uc.provideCSVWithManagerActivationDetails();

	}

	@Then("User uploads the user request")
	public void uploadRequest() throws Exception {
		try {
			log.info("upload the user request");
			uc.uploadUserRequest();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Then("User uploads the user request with details of update")
	public void uploadRequestWithUpdateDetails() throws Exception {
		try {
			log.info("upload the user request with details of update");
			uc.uploadUserRequestWithUdateDetails();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Then("User uploads the user request with details of termination")
	public void uploadRequestWithTerminationDetails() throws Exception {
		try {
			log.info("upload the user request with details of termination");
			uc.uploadUserRequestWithTerminationDetails();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Then("User search for the username needs to be updated")
	public void SearchUserForUpdate() throws Exception {
		log.info(user);
		uc.searchUser(user);
	}

	@Then("Workflow User search for the username needs to be updated")
	public void SearchUserForUpdateWorkFlow() throws Exception {
		log.info("User needs to be updated for workflow:" + userWorkFlow);
		uc.searchUser(userWorkFlow);
	}

	@Then("User Validates if the request is created with correct details")
	public void validates_the_if_the_request_is_created_with_correct_details() throws Exception {
		log.info("Validating if the request is created with correct details");
		uc.searchUser(user);
		uc.validateUserDetails(firstName, lastName);
		uc.validateEmailGeneration();

	}

	@Then("User Validates if all the user requests in csv are created with correct details")
	public void validates_if_all_the_requests_are_created() throws Exception, FileNotFoundException {
		log.info("Validating if the request is created with correct details");
		Scanner scan = new Scanner(new File(
				"//C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//usersBulk.csv"));

		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1] + " , " + record[2] + " , " + record[3]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[1]);
				uc.validateUserDetails(record[1], record[2]);
				uc.validateEmailGeneration();
			}
		}
	}

	@Then("User Validates if all the users in csv are terminated")
	public void validates_if_all_the_users_are_terminated() throws Exception {
		log.info("Validating if all the users in CSV are terminated");

		Scanner scan = new Scanner(new File(
				"//C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//TerminationUsersList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1] + " , " + record[2] + " , " + record[3]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[1]);

				ut.checkStatus(record[1]);
				ut.validateStatus();
			}
		}

	}

	@Then("User Validates the manager is terminated")
	public void validates_manager_terminated() throws Exception {
		log.info("Validating if all the users in CSV are terminated");

		Scanner scan = new Scanner(new File(
				"//C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//TerminationManager.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1] + " , " + record[2] + " , " + record[3]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[1]);

				ut.checkStatus(record[1]);
				ut.validateStatus();
			}
		}
	}

	@Then("User Validates the manager is activation")
	public void validates_manager_activation() throws Exception {
		String managersManagerUserName=getValue("managersManagerUserName");
		String managersManagerPassword=getValue("managersManagerPassword");
		log.info("Validating if all the users in CSV are activated");
		uc.searchUser(managersManagerUserName);
		ut.checkStatus(managersManagerPassword);
		ut.validateStatus();
	}

	@Given("User navigates to Admin page")
	public void navigateToAdmin() throws Exception {
		log.info("Navigating to Admin page ");
		//driver.navigate().refresh();
		ap.navigateToAdminPage();
		highLightElement(driver, driver.findElement(By.xpath("//span[text()='Admin']")));
	}

	@Given("External User navigates to Manage My Access and validates updated entitlement is listed under My applications")
	public void navigateToManageMyAccessEXternalUser() throws Exception {
		log.info("Navigating to Manage My Access AS External User Login ");
		ap.navigateToManageMyAccessExternalUser();
		ep.validateUpdatedEntitlementListedAsExternalUser(securitySys, entitlementMetaDataName);

	}

	@Given("External User navigates to Manage My Access and request for enablement of Inactive entitlement")
	public void navigateToManageMyAccessEXternalUserForSuspendedEntitlement() throws Exception {
		log.info("Navigating to Manage My Access AS External User Login ");
		ap.navigateToManageMyAccessExternalUser();
		ep.enableSuspendedEntitlement(securitySys, accountNameOfAnUserWhileRequestingAccess, enableAccount);

	}

	@Given("External User navigates to Manage My Access and validate the account has been locked")
	public void navigateToManageMyAccessEXternalUserForAccountLock() throws Exception {
		log.info("Navigating to Manage My Access AS External User Login ");
		ap.navigateToManageMyAccessExternalUser();
		ep.validateAccountLock(securitySys, accountNameOfAnUserNeedToLock, lockAccount);

	}

	@Given("External User navigates to Manage My Access and validate the account has been unlocked")
	public void navigateToManageMyAccessEXternalUserForAccountunLock() throws Exception {
		log.info("Navigating to Manage My Access AS External User Login ");
		ap.navigateToManageMyAccessExternalUser();
		ep.validateAccountLock(securitySys, accountNameOfAnUserNeedToLock, unlockAccount);

	}

	@Given("User executes the SOD job")
	public void executeSODJob() throws Exception {
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='col-md-12']//h3")));
		log.info("Execute SOD Job");
		sod.executeSODViolationJob(SecuritySystemSingleLevel);

	}

	@Given("User Validates if disable account pending task is created and Approved")
	public void test() throws Exception {
		log.info("**********User validates pendingTask tab********");
		uc.searchUser(userWorkFlow);
		try {

			wf.validatePendignTaskHasManagerEntitlementAndApprove(userWorkFlow);
		} catch (Exception e) {
			log.info("User is failed to navigate to Admin page");
		}

	}

	@Given("User navigates to Users in Identity repository")
	public void navigateToIdentityRepository() throws Exception {
		log.info("navigating to Users page ");
		ap.navigateToUsersPage();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));

	}
	@Then("User Validates if all the user requests in csv doesnot have Birthright access")
	public void validateBirthrightAccessAfterDiscontinuation() throws Exception {
		Thread.sleep(1000);
		log.info("********** Validating Birthright access ********");
		try {
			Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\BirthRightAccessDiscontinue.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					uc.searchUser(record[0]);
					String securitySystems = "STA Disconnected,STA Disconnected 2,STA Disconnected 3";
					ba.validateAccountCreationAfterDiscontinuation(record[0], securitySystems);
				}
			}

		} catch (Exception e) {
			log.info("Validating Birthright access has failed");
		}


	}

	@Given("User navigates to WorkFlow tab")
	public void navigateToWorkFlowTab() throws Exception {
		log.info("navigating to WorkFlow tab ");
		ap.navigateToWorkFlowPage();
		Thread.sleep(1000);
		log.info("Title:" + driver.findElement(By.xpath("//i[@class='svicon2-workflow-list']")).getText());

	}

	@Given("User navigates to security system tab")
	public void navigateToSecuritySystem() throws Exception {
		log.info("navigating to secuirty system tab ");
		driver.navigate().refresh();
		Thread.sleep(2000);
		ap.navigateToSecuritySystem();
		Thread.sleep(1000);
		if (driver.findElement(By.xpath("(//div[@class='caption'])[1]")).getText().contains("Security System List")) {
			highLightElement(driver, driver.findElement(By.xpath("(//div[@class='caption'])[1]")));
		}

	}

	@And("User Validates the existing single level manager's approval workflow")
	public void validateSingleManagerWorkflow() throws Exception {
		log.info("Validation of single level Manager approval workflow ");
		wf.workflowSearch(SingleManagerWorkFlowName);
		wf.validateWorkFlowCreation(SingleManagerWorkFlowName);

	}

	@And("User Validates the existing Two level manager's approval workflow")
	public void validateTwoManagerWorkflow() throws Exception {
		log.info("Validation of Two level Manager approval workflow ");
		wf.workflowSearch(TwoManagerWorkFlowName);
		wf.validateWorkFlowCreation(TwoManagerWorkFlowName);

	}

	@And("User Validates the existing Two level Sequential approval workflow")
	public void validateTwoLevelSequentialWorkflow() throws Exception {
		log.info("Validation of Two level Sequential approval workflow ");
		wf.workflowSearch(TwoLevelSerialWorkFlowName);
		wf.validateWorkFlowCreation(TwoLevelSerialWorkFlowName);

	}

	@And("User Validates the existing security system")
	public void validateSecuritySystem() throws Exception {
		log.info("Validation of  existing security system");
		ss.SecuritySysSearch(SecuritySystemSingleLevel);
		ss.validateSecurityCreation(SecuritySystemSingleLevel);

	}

	@And("User Validates the existing security system with request in flight")
	public void validateSecuritySystemInFlight() throws Exception {
		log.info("Validation of  existing security system");
		ss.SecuritySysSearch(SecuritySystemTwoLevelSerial);
		ss.validateSecurityCreation(SecuritySystemTwoLevelSerial);

	}

	@And("User Validates the existing Two level security system")
	public void validateTwoLevelSecuritySystem() throws Exception {
		log.info("Validation of  existing Two level security system");
		ss.SecuritySysSearch(SecuritySystemTwoLevel);
		ss.validateSecurityCreation(SecuritySystemTwoLevel);

	}

	@And("User Validates the existing Two level Serial security system")
	public void validateTwoLevelSerialSecuritySystem() throws Exception {
		log.info("Validation of  existing Two level security system");
		ss.SecuritySysSearch(SecuritySystemTwoLevelSerial);
		ss.validateSecurityCreation(SecuritySystemTwoLevelSerial);

	}
	@Then("User clicks on Action")
	public void clickAction() throws Exception {
		log.info("User clicks on Action on Admin User page");
		ap.clickAction();
	}

	@Then("User clicks on createUser")

	public void createUser() throws Exception {
		log.info("User clicks on Create User");
		Thread.sleep(1000);
		ap.createUser();
	}

	@And("User provide user details for create user")

	public void provideUserDetails() {
		log.info("User details provided");
		try {
			ap.provideUserDetails(fullName, firstName, lastName, email);
		} catch (InterruptedException e) {

			log.info("Registered user details not found");
		}
	}

	@And("User clicks submit")
	public void clickSubmit() {
		log.info("User clicks on create button on admin page after entering user details");
		ap.submit();

	}

	@And("Validate user request has been created successfully")
	public void validateUserCreationRequest() {
		ap.createUserValidation();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='block'][2]")));
	}

	/*@Then("User updates required fields")
	public void updateUser() throws Exception {

		update.updateUser(updateMiddleName, updateLocation);

	}
	 */

	@Then("User search for the username that has been updated")
	public void ValidatesUserUpdates() throws Exception {
		uc.searchUser(user);

	}

	/*
	@Then("User Validates if the request is updated with correct details")
	public void validates_the_if_the_request_is_updated_with_correct_details() throws Exception {
		log.info("Validating if the request is _updated with correct details");
		update.validateUpdatedDetails(updateMiddleName, updateLocation);

	}
	 */

	@Then("User Validates if all the users in csv are updated")
	public void validates__if_all_the_requests_are_updated() throws Exception {
		log.info("Validating if the request is updated with correct details");

		Scanner scan = new Scanner(new File(
				"//C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//UpdateUsersList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1] + " , " + record[2] + "," + record[4] + " , "
					+ record[7]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[1]);
				update.validateUpdatedDetailsCity(record[7]);

			}
		}
	}

	@Given("User navigates to home page")
	public void navigateToHomePage() throws Exception {
		log.info("Navigating to home page");
		apps.navigateToHomePage();
	}

	@Given("User navigates to SOD page")
	public void navigateToSODPage() throws Exception {
		log.info("Navigating to SOD page");
		sod.navigateToSODPage();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='col-md-12']//h3")));
	}

	@Given("User validates SOD violation is created for Medium Risk")
	public void validateSODViolation() throws Exception {
		log.info("Validation of SOD Violation");
		try {
			Scanner scan = new Scanner(
					new File(System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\SODViolation.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					sod.searchUser(record[0]);
					sod.validateViolationCreation(record[0], SecuritySystemSingleLevel);

				}
			}

		} catch (Exception e) {
			log.info("Validation of SOD violation has failed");
		}

	}

	@Given("SOD Actioned User validates SOD violation is created")
	public void validateSODViolationWhenSODActioned() throws Exception {
		log.info("Validation of SOD Violation");
		try {
			Scanner scan = new Scanner(new File(System.getProperty("user.dir")
					+ "\\src\\test\\resources\\TestData\\SODViolationWhenSODActioned.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					sod.searchUser(record[0]);
					sod.validateViolationCreation(record[0], SecuritySystemSingleLevel);

				}
			}

		} catch (Exception e) {
			log.info("Validation of SOD violation has failed");
		}

	}

	@Given("User validates if SOD violation is created when SOD JOB is actioned Second Time")
	public void validateSODViolationAfterJOBRunSecondTime() throws Exception {
		log.info("Validation of SOD Violation Creation after SOD JOB is actioned second time");
		try {
			Scanner scan = new Scanner(new File(System.getProperty("user.dir")
					+ "\\src\\test\\resources\\TestData\\SODViolationWhenSODActioned.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					sod.searchUser(record[0]);
					sod.validateViolationCreationAfterJOBRunSecondTimeForSameUser(record[0], SecuritySystemSingleLevel);

				}
			}

		} catch (Exception e) {
			log.info("Validation of SOD violation has failed");
		}

	}

	@Given("User navigates to one click disable in User Management")
	public void navigateToOneClickDisable() throws Exception {
		log.info("Navigating to one click disable");
		ut.navigateToOneClickDsable();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));

	}

	@Given("User selects the details which need to be removed")
	public void selectTerminatingUser() throws Exception {
		log.info("Selecting User To Terminatet");
		ut.selectTerminatingUser(user);

	}

	@Then("User removes access for selected user")
	public void removeAccess() throws Exception {
		log.info("Removing Access of an User");
		ut.removeAccess();

	}

	@Then("User Validates the status of removed user")
	public void validatesStatus() throws Exception {
		log.info("Validate the status of user after termination");
		ut.checkStatus(user);
		ut.validateStatus();
	}

	@Then("User logs out of saviynt successfully")
	public void logout() throws Exception {
		log.info("Logging out of saviynt");
		logout.clickLogout();

	}

	@Then("Manager logs out of saviynt successfully")
	public void logoutManager() throws Exception {
		log.info("Logging out of saviynt");
		logout.clickLogoutAsManager();

	}

	@Given("User navigates to Roles in Identity repository")
	public void navigateToRolesinIdentityRepository() throws Exception {
		log.info("navigating to roles page ");
		rc.navigateToRolesPage();

		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));

	}

	@Given("User creates Role Enterprise with provided details")
	public void creatingRole1() throws Exception {
		log.info("creating Role Enterprise ");
		rc.createNewRole(role2, roleType2);
	}

	@And("User creates Role Emergency Access with provided details")
	public void creatingRole2() throws Exception {
		log.info("creating Role Emergency Access ");
		ap.navigateToAdminPage();
		rc.navigateToRolesPage();
		rc.createRoles(role3, roleType3);

	}

	@Given("User creates Role Application with provided details")
	public void creatingRole3() throws Exception {
		log.info("creating Role Application ");
		ap.navigateToAdminPage();
		rc.navigateToRolesPage();

		rc.createRoles(role2, roleType2);

	}

	@Then("User Validates if the Role Enterprise is created")
	public void validates_if_the_role1_is_created() throws Exception {
		log.info("Validates if the Role Enterprise is created");
		ap.navigateToAdminPage();
		highLightElement(driver, driver.findElement(By.xpath("//span[text()='Admin']")));
		rc.navigateToRolesPage();
		rc.searchRole(role2);
		rc.validateRoleCreation(role2);

	}

	@And("User creates Role Emergency Access with out providing timeframe details")
	public void creatingRole() throws Exception {
		log.info("creating Role Emergency Access ");
		ap.navigateToAdminPage();
		rc.navigateToRolesPage();
		rc.createEmergencyRoles(role3, roleType3);

	}

	@And("User verifies if creating role with out providing timeframe details fails with error")
	public void ValidateRole() throws Exception {
		log.info("Validating Role Emergency Access");
		rc.ValidateEmergencyRoles();

	}

	@Then("User Validates if Role Emergency Access is created")
	public void validates_if_the_role2_is_created() throws Exception {
		log.info("Validating if Role Emergency Access is created");
		ap.navigateToAdminPage();
		highLightElement(driver, driver.findElement(By.xpath("//span[text()='Admin']")));
		rc.navigateToRolesPage();
		rc.searchRole(role3);
		rc.validateRoleCreation(role3);

	}

	@Then("User Validates if the Role Application is created")
	public void validates_if_the_role3_is_created() throws Exception {
		log.info("Validating if the Role Application is created");
		ap.navigateToAdminPage();
		highLightElement(driver, driver.findElement(By.xpath("//span[text()='Admin']")));
		rc.navigateToRolesPage();
		rc.searchRole(role2);
		rc.validateRoleCreation(role2);

	}


	/*	@Given("Role Modification User navigates to role to be updated with Entitlement details")
	public void updateRolesWithEntitlementDetailsForRoleModification() throws Exception {
		log.info("Update Existing Role with Entitlement Details ");
		// ap.navigateToAdminPage();
		// rc.navigateToRolesPage();
		rc.searchRole(role2);
		rc.updateRolesWithEntitlement(role2, entitlementName);
	}
	 */
	@And("User Provides file other than .csv format containing LOA and LTD details of user")
	public void loaltdDetialsOfUsers() throws Exception {
		log.info("providing the detials of new user");
		//leaveStatus.provideCSVWithLOALTDDetails();
		selectFile.selectCSVWithDetails("UsersLeaveStatusList.csv");

	}

	@And("User Provides file other than .csv format containing new job code and Status details of user")
	public void DetialsOfManagerAndStatus() throws Exception {
		log.info("providing the detials of new user");
		changePositionCertification.provideCSVWithDetails();

	}

	@Then("User Validates if disable account pending task is created and discontinues it")
	public void discontinue_pending_task_()
			throws AWTException, InterruptedException, FileNotFoundException {
		// apps.navigateToHomePage();
		log.info("Validating if disable account pending task is created");
		Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\UsersLeaveStatusList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				leaveStatus.discontinuePendingTask(record[0], record[1]);

			}
		}

	}


	@Then("User uploads the user request with details of job code and Status")
	public void uploadDetials() throws Exception {
		try {
			log.info("upload the user request with details of manager and status");
			changePositionCertification.uploadUserRequestWithUdateDetails();
		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	@Then("User Validates updated job code")
	public void validates__if_manager_and_status_updated() throws Exception {
		log.info("Validating if the request is updated with correct details");

		Scanner scan = new Scanner(new File(
				"//C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//ChangeOfPositionUsersList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1] + " , " + record[2] + " , " + record[3] + " , "
					+ record[4] + " , " + record[5] + "," + record[6]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[1]);
				// takeSnapShot(driver, record[1]+"details");
				log.info("Validate user status update details");
				//update.validateUpdatedDetailsStatus(record[1],record[3]);
				//update.validateUpdatedDetailsManager(record[4]);
				update.validateJobCodeDetails(record[1],record[6]);

			}
		}

	}

	@And("User Provides file other than .csv format containing details of user")
	public void HIRDetialsOfUsers() throws Exception {
		log.info("providing the detials of new user");
		// wf.provideCSVWithHIRetails();

	}

	@Then("User uploads the user request with details of Leave")
	public void uploadLOALTDDetials() throws Exception {
		try {
			log.info("upload the user request with details of leave");
			leaveStatus.uploadLOALTDDetails();
			// takeSnapShot(driver, "UploadLeaveStatus.png");

		} catch (InterruptedException e) {

			e.printStackTrace();
		}

	}

	/*
	 * @Then("User uploads the user request") public void uploadHIRDetials() throws
	 * Exception { try { log.info("upload the user request with details of leave");
	 * wf.uploadHIRDetails(); // takeSnapShot(driver, "UploadLeaveStatus.png");
	 * 
	 * 
	 * 
	 * } catch (InterruptedException e) {
	 * 
	 * 
	 * 
	 * e.printStackTrace(); }
	 * 
	 * 
	 * 
	 * }
	 */

	@Then("User Validates if users Leave status is updated")
	public void user_validates_if_users_leave_status_is_updated()
			throws InterruptedException, FileNotFoundException, AWTException {
		log.info("Validating if users Leave status is updated");
		Scanner scan = new Scanner(new File("C:\\Users\\snigdha.ahmed\\Desktop\\UsersLeaveStatusList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				leaveStatus.validateLeaveStatus(record[0], record[1]);
				ap.navigateToAdminPage();
				ap.navigateToUsersPage();

			}
		}

	}

	@Then("WorkFlow User Validates if users Leave status is updated")
	public void workflow_user_validates_if_users_leave_status_is_updated()
			throws InterruptedException, FileNotFoundException, AWTException {
		log.info("Validating if users Leave status is updated");
		Scanner scan = new Scanner(new File("C:\\Users\\snigdha.ahmed\\Desktop\\WorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				wf.validateLeaveStatus(record[0], record[1]);
				// ap.navigateToAdminPage();
				// ap.navigateToUsersPage();

			}
		}

	}

	@Then("User Validates if disable account pending task is created")
	public void user_validates_if_disable_account_pending_task_is_created()
			throws AWTException, InterruptedException, FileNotFoundException {
		// apps.navigateToHomePage();
		log.info("Validating if disable account pending task is created");
		Scanner scan = new Scanner(new File("C:\\Users\\snigdha.ahmed\\Desktop\\UsersLeaveStatusList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				leaveStatus.validatePendingTask(record[0], record[1]);

			}
		}

	}

	@Then("Workflow User Validates if disable account pending task is created")
	public void workflow_user_validates_if_disable_account_pending_task_is_created()
			throws AWTException, InterruptedException, FileNotFoundException {
		// apps.navigateToHomePage();
		log.info("Validating if disable account pending task is created");
		Scanner scan = new Scanner(new File("C:\\Users\\snigdha.ahmed\\Desktop\\WorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				leaveStatus.validatePendingTask(record[0], record[1]);

			}
		}

	}

	@And("User navigates to pending tasks page")
	public void User_navigates_to_pendingtasks_page() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to Home page");
		driver.navigate().refresh();
		Thread.sleep(1000);
		apps.navigateToHomePage();
		log.info("Navigating to Pending Tasks");
		leaveStatus.navigateToPendingTasks();
		log.info("*********End of Pending taks navigation******");
	}
	@Then("User Validates if pending task is created and discontinues it")
	public void user_validates_if_pending_task_is_created_Discontinue()
			throws AWTException, InterruptedException, FileNotFoundException {
		driver.navigate ().refresh ();
		log.info("Validating if pending task is created");
		try	 {
			Scanner scan = new Scanner(new File( System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\BirthRightAccessDiscontinue.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("UserName")) {
					log.info(record[0]);
					uc.searchUser(record[0]); 
					String securitySystems = "STA Disconnected,STA Disconnected 2,STA Disconnected 3";
					ba.discontinuePendingTaskForBirthRight(record[0], securitySystems);


				}
			}

		} catch (Exception e) {
			log.info("Validating pending task has failed");
		}
	}

	@And("User navigates to pending Approval page")
	public void User_navigates_to_pendingApproval_page()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to Pending Approval");
		leaveStatus.navigateToPendingApproval();
		log.info("*********End of Pending Approval navigation******");
	}

	@And("User navigates to Request History page")
	public void User_navigates_to_request_history_page()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to Request History page");
		leaveStatus.navigateToRequestHistoryPage();
		log.info("*********End of Request History navigation******");
	}

	@And("User navigates to completed tasks page")
	public void User_navigates_to_completedtasks_page()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to Home page");
		apps.navigateToHomePage();
		log.info("Navigating to completed task");
		leaveStatus.navigateTocompletedTasks();
		log.info("*********End of completes task navigation******");
	}

	@Then("User approves disable account pending task")
	public void approvePendingTask() throws Exception {
		log.info("Approving pending task");
		leaveStatus.approvePendingTask();
		log.info("*****End of Approving pending task");

	}

	@Then("User Validates if disable account task is approved")
	public void user_validates_if_disable_account_task_is_approved()
			throws AWTException, InterruptedException, FileNotFoundException {

		log.info("Validating if disable account pending task is approved");
		Scanner scan = new Scanner(new File(
				"\\C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\UsersLeaveStatusList.csv"));

		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				leaveStatus.validateCompletedTask(record[0]);

			}
		}

	}

	@Then("User Validates if account of disabled user is suspended")
	public void user_validates_if_account_of_disabled_user_is_suspended()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"\\C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\UsersLeaveStatusList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				leaveStatus.validateAccountStatus(record[0]);

			}
		}

	}

	@Then("User Validates if account of  user is Provisioned under Single wokrflow Security system")
	public void user_validates_if_account_of_user_is_provisioned()
			throws AWTException, InterruptedException, FileNotFoundException {
		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\WorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				wf.validateAccountCreation(record[0], SecuritySystemSingleLevel,
						accountNameOfAnUserWhileRequestingAccess);

			}
		}

	}

	@Then("Admin Validates if account of  user is Provisioned under Single workflow Security system")
	public void admin_validates_if_account_of_user_is_provisioned()
			throws AWTException, InterruptedException, FileNotFoundException {
		
		uc.searchUser(externalUserNameForEntitlementApproval);
		wf.validateAccountCreation(externalUserNameForEntitlementApproval, SecuritySystemSingleLevel,
				accountNameOfAnUserWhileRequestingAccess);

	}

	@Then("Admin Validates if account of  user is Provisioned under Two level workflow Security system")
	public void admin_validates_if_account_of_user_is_provisioned_Two_Level_Workflow()
			throws AWTException, InterruptedException, FileNotFoundException {
		String ExternalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		uc.searchUser(ExternalUserNameForTwoLevelWorkFlow);
		wf.validateAccountCreation(ExternalUserNameForTwoLevelWorkFlow, SecuritySystemTwoLevel,
				accountNameOfAnUserWhileRequestingAccess);

	}
	@Then("Admin Validates if account of  user is Provisioned under Two level Serial workflow Security system")
	public void admin_validates_if_account_of_user_is_provisioned_Two_Level_Serial_Workflow()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\TwoLevelSerialWorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				wf.validateAccountCreation(record[0], SecuritySystemTwoLevelSerial,
						accountNameOfAnUserWhileRequestingAccess);

			}
		}

	}

	@Then("Admin Validates if account of  user is Locked")
	public void admin_validates_if_account_of_user_is_locked()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\WorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				wf.validateAccountLock(record[0], SecuritySystemSingleLevel);

			}
		}

	}

	@Then("Admin Validates if account of  user for the Target System has been manually suspended")
	public void admin_validates_if_account_of_user_is_suspended()
			throws AWTException, InterruptedException, FileNotFoundException {
		uc.searchUser(externalUserNameForEntitlementApproval);
		wf.validateAccountSuspension(externalUserNameForEntitlementApproval, SecuritySystemSingleLevel,
				accountNameOfAnUserWhileRequestingAccess);

	}

	@Then("Admin Validates if account of  user for the Target System has been manually suspended for Two Phase")
	public void admin_validates_if_account_of_user_is_suspended_Two_Phase_workFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		String ExternalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		uc.searchUser(ExternalUserNameForTwoLevelWorkFlow);
		wf.validateAccountSuspension(ExternalUserNameForTwoLevelWorkFlow, SecuritySystemTwoLevel,
				accountNameOfAnUserWhileRequestingAccess);

	}

	@Then("Admin Validates if account of  user is Provisioned under Two wokrflow Security system")
	public void admin_validates_if_account_of_user_is_provisioned_TwoLevel()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\TwoLevelWorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				wf.validateAccountCreation(record[0], SecuritySystemSingleLevel,
						accountNameOfAnUserWhileRequestingAccess);

			}
		}

	}

	@Then("Workflow User Validates if disable account task is approved")
	public void user_validates_if_new_account_task_is_approved()
			throws AWTException, InterruptedException, FileNotFoundException {

		log.info("Validating if new account pending task is approved");
		Scanner scan = new Scanner(new File("C:\\Users\\snigdha.ahmed\\Desktop\\WorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				wf.validateCompletedTask(record[0]);

			}
		}
	}

	/*
	@Then("WorkFlow User Validates if the request is created with correct details")
	public void validates_createdUserForWorkFlow() throws Exception {
		log.info("Validating if the user is created with correct details for workflow");
		uc.searchUser(WorkFlowUserName);
		uc.validateUserDetails(WorkFlowFirstName, WorkFlowLastName);

	}
	*/

	@Then("SOD Violation User Validates if the request is created with correct details")
	public void validates_createdUserForSODViolation() throws Exception {
		log.info("Validating if the request is created with correct details");
		Scanner scan = new Scanner(new File(
				"//C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//SODViolation.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1] + " , " + record[2] + " , " + record[3]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[1]);
				log.info("Validating if the user is created with correct details for SOD Violation");
				uc.searchUser(record[0]);
				uc.validateUserDetails(record[1], record[2]);

			}
		}
	}

	@Then("User Validates if the user is created with correct details for Preventive SOD violation")
	public void validates_createdUserForPreventiveSODViolation() throws Exception {
		log.info("Validating if the user is created with correct details for Preventive SOD Violation ");
		uc.searchUser(UserForPreventitiveSODViolation);
		uc.validateUserDetails(UserFirstNameForPreventitiveSODViolation, UserLastNameForPreventiveSODViolation);

	}

	@Then("SOD Actioned SOD Violation User Validates if the request is created with correct details")
	public void validates_createdUserForSODViolationWhenSODActioned() throws Exception {
		log.info("Validating if the user is created with correct details for SOD Violation When SOD Actioned");
		uc.searchUser(UserForSODViolationwhenSODActioned);
		uc.validateUserDetails(UserFirstNameForSODViolationwhenSODActioned, UserLastNameForSODViolationwhenSODActioned);

	}

	@Given("User provides the file in .csv containing detials of new users to request access for endpoints")
	public void detialsOfUsersForWorkFlow() throws Exception {
		log.info("providing the detials of new user in .csv for workflow");
		uc.provideCSVForWorkFlow();

	}

	@Given("User provides the file in .csv containing detials of new users to request access for endpoints for two level workflow")
	public void detialsOfUsersForTwoLevelWorkFlow() throws Exception {
		log.info("providing the detials of new user in .csv for workflow");
		uc.provideCSVForTwoLevelWorkFlow();

	}

	@Then("User uploads the user request with details of endpoints")
	public void uploadRequestWithEndpointDetails() throws Exception {
		try {
			log.info("uploads the user request");
			wf.uploadDetails();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@And("User navigates to request access for others page")
	public void User_navigates_to_RequestAccess_for_Others_page()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to Request Access for Others page");
		wf.navigateToRequestAccessforOthers();
		driver.navigate().refresh();

	}

	@And("User navigates to request access As External User")
	public void User_navigates_to_RequestAccess() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to Request Access As an external user");
		wf.navigateToRequestAccessExternalUser();
		//driver.navigate().refresh();

	}

	@And("User requests access for required end point and Validates if  access request for endpoint is created")
	public void User_RequestAccess_for_Endpoint() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(1000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage Access For Team']")));
		wf.searchUserToRequestAccess(userWorkFlow);
		wf.searchEndpointToRequestAccess(SecuritySystemSingleLevel, accountNameOfAnUserWhileRequestingAccess,
				STA_Entitlement);
		// String[] splited = RequestIdFetch.split("\\s+");
		// log.info("****RequestID created: " + splited[1]);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[text()='Request History']")).click();
		log.info("User is on Request History page");
		log.info("Navigating to pending approvals page");
		// driver.navigate().refresh();
		ap.navigateToAdminPage();
		apps.navigateToHomePage();
		wf.navigateToPendingApprovalsPage();
		log.info("Validating if the access for endpoint request is created");
		// apps.navigateToHomePage();
		// driver.navigate().refresh();
		wf.searchRequestId(wf.requestID);

		// log.info("Request Id :" +RequestId.split(" "));
		// wf.requestAccessToEndpoint();
	}

	@And("User search an User under All Employees and validate entitlement listed")
	public void Search_User_NavigateToManageAccess() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Search User and Clicks on Manage");
		Thread.sleep(1000);
		// highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage
		// Access For Team']")));
		wf.searchUserToRequestAccess(userForInactiveEntitlement);
		wf.modifyRequestAccess(SecuritySystemSingleLevel, EntitmentForInactiveValidation);
	}

	@And("User navigates to an already existing application and validates entitlement listed")
	public void user_navigates_Existing_application() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Click on Manage and modify exiting entitlment, validate list of entitlement preset");
		Thread.sleep(1000);
		// highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage
		// Access For Team']")));
		wf.modifyRequestAccess(SecuritySystemSingleLevel, entitlementName);
	}

	/*@And("User requests access for required two level end point and Validates if  access request for endpoint is created")
	public void User_RequestAccess_for_TwoLevel_Endpoint()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(1000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage Access For Team']")));
		wf.searchUserToRequestAccess(WorkFlowUserName);
		wf.searchEndpointToRequestAccess(SecuritySystemTwoLevel, accountNameOfAnUserWhileRequestingAccess,
				STA_Entitlement);
		// String[] splited = RequestIdFetch.split("\\s+");
		// log.info("****RequestID created: " + splited[1]);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[text()='Request History']")).click();
		log.info("User is on Request History page");
		log.info("Navigating to pending approvals page");
		// driver.navigate().refresh();
		ap.navigateToAdminPage();
		apps.navigateToHomePage();
		wf.navigateToPendingApprovalsPage();
		log.info("Validating if the access for endpoint request is created");
		// apps.navigateToHomePage();
		// driver.navigate().refresh();
		wf.searchRequestId(wf.requestID);

		// log.info("Request Id :" +RequestId.split(" "));
		// wf.requestAccessToEndpoint();
	}
*/
	/**
	 *        * This method is to login to Saviynt.       * @param managerUserName 
	 *      * @param managerPassword      
	 */
	@And("User login to saviynt tool successfully as manager")
	public void enterManagerCredentials() {
		String managerUserName=getValue("managerUserName");
		String managerPassword=getValue("managerPassword");
		try {
			lp.setManagerUserName(managerUserName);
			lp.setManagerPassword(managerPassword);
			lp.clickSubmit();

		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}
	}

	@And("User login to saviynt tool successfully as managers manager")
	public void enterManagersManagerCredentials() {
		String managersManagerUserName=getValue("managersManagerUserName");
		String managersManagerPassword=getValue("managersManagerPassword");

		try {
			lp.setManagerUserName(managersManagerUserName);
			lp.setManagerPassword(managersManagerPassword);
			lp.clickSubmit();

		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}
	}

	@And("User login to saviynt tool successfully as Entitlement Owner")
	public void enterEntitlementOwnerCredentials() {
		String managersManagerUserName=getValue("managersManagerUserName");
		String managersManagerPassword=getValue("managersManagerPassword");
		try {
			lp.setManagerUserName(managersManagerUserName);
			lp.setManagerPassword(managersManagerPassword);
			lp.clickSubmit();

		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}
	}

	@And("User navigates to pending approvals page in home")
	public void User_navigates_to_pending_approvals_page()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to pending approvals page");
		// apps.navigateToHomePage();
		wf.navigateToPendingApprovalsPage();
	}

/*	@Then("User Validates if the access for endpoint request is created")
	public void User_validated_if_request_is_created()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validating if the access for endpoint request is created");
		// apps.navigateToHomePage();
		wf.searchRequestId(WorkFlowUserName);
	}
	*/

	/*@And("Search User and click on View Pending Approval Page")
	public void searchUserPendingApprovalPage() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Searching User on Pending Approval Page");
		sod.searchUserPendingApprovalPage(ExternalUserNameForSingleWorkFlow);

	}
*/
	@And("Search User and click on View Pending Approval Page for Single Level")
	public void searchUserPendingApprovalPageForSingleLevelWorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Searching User on Pending Approval Page");
		String externalUserNameForSingleWorkFlow=getValue("externalUserNameForSingleWorkFlow");
		sod.searchUserPendingApprovalPage(externalUserNameForSingleWorkFlow);

	}

	@And("Search requestID and click on View Pending Approval Page for Single Level")
	public void searchRequestIdPendingApprovalPageForSingleLevelWorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Searching requestID on Pending Approval Page" + wf.requestID);
		wf.searchRequestIdPendingApprovalPage(wf.requestID);
		//wf.searchRequestIdPendingApprovalPage("1283924");

	}

	@And("Validate preventive SOD violations are created")
	public void validatePreventiveSOD()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validate preventive SODs are created");
		//wf.searchRequestIdPendingApprovalPage(sod.requestID);
		sod.validatePreventiveSOD(Entitlement1ForSODViolation,Entitlement2ForSODViolation);

	}

/*	@And("Search User on Request approval page")
	public void searchUserRequestApprovalPage() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Searching User on Pending Approval Page");
		sod.searchUserPendingApprovalPage(ExternalUserNameForSingleWorkFlow);

	}
	*/

/*	@And("Search User and click on View on Request History Page")
	public void searchUserRequestHistoryPage() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Searching User on Request History Page");
		sod.searchUserRequestHistoryPage(ExternalUserNameForSingleWorkFlow);

	}
	*/

	@And("Search requestID and click on View Pending Approval Page for Two Level")
	public void searchUserPendingApprovalPageForTwoLevelWorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Searching requestID on Pending Approval Page" + wf.requestID);
		wf.searchRequestIdPendingApprovalPage(wf.requestID);

	}

	@And("Search User and click on View Pending Approval Page for Two Level Serial workflow")
	public void searchUserPendingApprovalPageForTwoLevelSerialWorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		String externalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		log.info("Searching User on Pending Approval Page");
		sod.searchUserPendingApprovalPage(externalUserNameForTwoLevelWorkFlow);

	}

	@And("Search User and validate no pending approval has been created")
	public void searchUserPendingApprovalPageForLevelTwo()
			throws AWTException, InterruptedException, FileNotFoundException {
		String externalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		log.info("Searching User on Pending Approval Page");
		sod.validateNoPendingApprovalCreated(externalUserNameForTwoLevelWorkFlow);

	}

	@And("User approves the request")
	public void User_approves_request() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("approving request");
		sod.approveRequest();
	}

	@And("Manager approves the request")
	public void admin_approves_request() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("approving request");
		wf.approveRequestAsManagerForWorkFlow();
	}

	@And("Manager approves the request from Request Approval page")
	public void manager_approves_request() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("approving request");
		wf.approveRequestAsManagerFromRequestApprovalPage();
	}

	@And("Manager Reject the request")
	public void admin_reject_request() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Rejecting request");
		// sod.searchUserPendingApprovalPage(ExternalUserName);
		wf.rejectRequestAsManagerForWorkFlow();
		// driver.navigate().refresh();
	}

	@And("User approves the request for Preventive SOD Violation")
	public void User_approves_request_Preventive_SODViolation()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("approving request ");
		sod.approveRequestForPreventiveSODViolation();
		// driver.navigate().refresh();
	}

	@And("User login to saviynt tool successfully as Admin")
	public void enterAdminCredentials() {
		String adminUserName=getValue("adminUserName");
		String adminPassword=getValue("adminPassword");
		try {
			lp.setAmdinName(adminUserName);
			lp.setAmdinPassword(adminPassword);
			lp.clickSubmit();

		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}
	}

	@Then("User Validates if pending task is created")
	public void user_validates_if_disable_account_pending_task_is_created1()
			throws AWTException, InterruptedException, FileNotFoundException {

		log.info("Validating if disable account pending task is created");
		Scanner scan = new Scanner(new File("C:\\Users\\snigdha.ahmed\\Desktop\\UsersLeaveStatusList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				wf.validatePendingTask(record[0], record[1]);

			}
		}

	}

	@Then("Role Modification User Validates if pending task is created and approves it")
	public void user_validates_if_Entitlement_pending_task_is_created()
			throws AWTException, InterruptedException, FileNotFoundException {

		log.info("Validating if user pending task is created");
		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\RoleUpdate.csv"));

		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				wf.validatePendingTaskForRoleUpdate(record[0]);

			}
		}

	}

	@Then("WorkFlow User Validates if pending task is created and approves it")
	public void user_validates_if_new_account_pending_task_is_created1()
			throws AWTException, InterruptedException, FileNotFoundException {

		log.info("Validating if the new account pending task is created");
		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\WorkflowUserList.csv"));

		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);
				wf.validatePendingTask(record[0], record[1]);

			}
		}

	}
	@Then("Admin Validates if pending task is created and approves it")
	public void admin_validates_if_new_account_pending_task_is_created1()
			throws AWTException, InterruptedException, FileNotFoundException {
		String externalUserNameForEntitlementApproval=getValue("externalUserNameForSingleWorkFlow");
		log.info("Validating if the new account pending task is created");
		wf.searchRequestIDPendingTask(externalUserNameForEntitlementApproval);
		wf.validatePendingTask(externalUserNameForEntitlementApproval, SecuritySystemSingleLevel);

	}

	@Then("Admin Validates if pending task is created for removing user certification")
	public void admin_validates_pending_task_is_created_for_removal_user()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validating the pending task created for the user certification removal");
		Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "//src//test//resources//TestData//ApplicationOwnerCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("user : " + record[0] + " , " + record[1]);
			if ((!record[0].equalsIgnoreCase("UsersForCertify")) && (!record[1].equalsIgnoreCase("UsersForRevoke"))) {
				log.info("searching user under pending approval" + record[1]);
				wf.searchRequestIDPendingTaskForAccessRemoval(record[1],systemNameForCertifying);
			}
		}
	}


	@Then("Admin Validates if pending task is created for removing user manager certification")
	public void admin_validates_pending_task_is_created_for_removal_user_user_manager()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validating the pending task created for the user certification removal");
		Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "//src//test//resources//TestData//QuarterlyCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("user : " + record[0] + " , " + record[1]);
			if ((!record[0].equalsIgnoreCase("Username")) && (!record[2].equalsIgnoreCase("EmploymentStatus"))) {
				log.info("searching user under pending approval" + record[0]);
				wf.searchRequestIDPendingTaskForAccessRemoval(record[0],systemNameForCertifying);
			}
		}
	}


	@Then("Admin Validates if pending task is created and approves it for Two Phase approval")
	public void admin_validates_if_new_account_pending_task_is_createdForTwoPhaseApproval()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validating if the new account pending task is created");
		String externalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		uc.searchUser(externalUserNameForTwoLevelWorkFlow);
		wf.validatePendingTask(externalUserNameForTwoLevelWorkFlow, SecuritySystemTwoLevel);

	}


	@Then("Admin Validates if pending task is created and approves it for Two Phase Serial approval")
	public void admin_validates_if_new_account_pending_task_is_createdForTwoPhaseSerialApproval()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validating if the new account pending task is created");
		String externalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		uc.searchUser(externalUserNameForTwoLevelWorkFlow);
		wf.validatePendingTask(externalUserNameForTwoLevelWorkFlow, SecuritySystemTwoLevelSerial);

	}

	@Then("Admin Validates if pending task is created for Access Removal and approves it")
	public void admin_validates_if_removal_account_pending_task_is_created1()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validating if the new account pending task is created for account removal");
		driver.navigate().refresh();
		uc.searchUser(externalUserNameForEntitlementApproval);
		wf.validatePendingTaskForAccessRemoval(externalUserNameForEntitlementApproval, SecuritySystemSingleLevel);

	}

	@Then("Admin Validates if pending task is created for Access Removal and approves it Two Phase")
	public void admin_validates_if_removal_account_pending_task_is_created_Two_Phase()
			throws AWTException, InterruptedException, FileNotFoundException {

		log.info("Validating if the new account pending task is created for account removal");
		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\TwoLevelWorkflowUserList.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				driver.navigate().refresh();
				uc.searchUser(record[0]);
				wf.validatePendingTaskForAccessRemoval(record[0], record[1]);

			}
		}

	}

	@Then("Admin Validates if pending task is created for a rejected approval")
	public void admin_validates_if_new_account_pending_task_is_created_afterReject()
			throws AWTException, InterruptedException, FileNotFoundException {
		uc.searchUser(externalUserNameForEntitlementApproval);
		wf.validatePendingTaskForRejectAccess(externalUserNameForEntitlementApproval, SecuritySystemSingleLevel);

	}


	@Then("Two Level Workflow Admin Validates if pending task is created for a rejected approval")
	public void admin_validates_if_new_account_pending_task_is_created_afterRejectForTwoLEvelWorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Validating if the new account pending task is created");
		String externalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		uc.searchUser(externalUserNameForTwoLevelWorkFlow);
		wf.validatePendingTaskForRejectAccess(externalUserNameForTwoLevelWorkFlow, SecuritySystemTwoLevel);

	}

	@Then("User approves new account pending task")
	public void approveTask() throws Exception {
		log.info("Approving task");
		wf.approveTask();

	}

	@And("User Validates if account is created for required endpoint")
	public void User_validates_if_account_Is_created()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("");
		wf.validateAccountCreation(user, SecuritySystemSingleLevel, accountNameOfAnUserWhileRequestingAccess);

	}

	@Given("User navigates to Create New Entitlement page")
	public void navigateToCreateNewEntitlement() throws Exception {
		log.info("navigating to create  New Entitlement");
		ep.navigateToCreateNewEntitlement();
	}

	@Given("User navigates to Create Delegate page")
	public void navigateToCreateDelegate() throws Exception {
		log.info("navigating to create Delegate");
		delegate.navigateToCreateDelegate();
	}

	@Given("User navigates to Manage Delegate page")
	public void navigateToManageDelegate() throws Exception {
		log.info("navigating to manage Delegate");
		delegate.navigateToManageDelegate();
	}

	@Given("User navigates to Create New Entitlement Type page")
	public void navigateToCreateNewEntitlementType() throws Exception {
		log.info("Navigating to create  New Entitlement Type");
		ep.navigateToCreateNewEntitlementType();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));
	}

	@Given("User navigates to Update Entitlement Type page")
	public void navigateToUpdateEntitlementType() throws Exception {
		log.info("Navigating to update an Entitlement Type");
		ep.navigateToUpdateEntitlementType();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));

	}

	@Given("Validate End user doesn’t have permission for creation or update of an Entitlement")
	public void navigateToCreateNewEntitlementForEndUser() throws Exception {
		log.info("navigating to create  New Entitlement");
		ep.validateManageEntitlementAsEndUser(manageEntitlementTab);
	}

	@Then("Validate End user doesn’t have permission to update Entitlement")
	public void navigateToUpdateEntitlementForEndUser() throws Exception {
		log.info("navigating to Update Existing Entitlement");
		ep.navigateToUpdateExistingEntitlement();
	}

	@And("User creates Entitlement with provided details")
	public void userCreatesNewEntitlement() throws Exception {
		log.info("creating New Entitlement");
		ep.createEntitlement(entitlementName, securitySys, endPointValue, entitlementTypeValue);
	}

	@And("User Validates if the Entitlement Type created is getting listed while Entitlement creation")
	public void userValidateEntitlementTypeWhileCreationNewEntitlement() throws Exception {
		log.info("Validating Newly created Entitlement Type is available while creation of an Entitlement");
		ep.validatesEntitlementTypeWhileEntitlementCreation(entitlementName, securitySys, endPointValue,
				entitlementTypeName);
	}

	@And("User Validates the update Entitlement Type is getting listed while Entitlement creation")
	public void userValidateUpdatedEntitlementTypeWhileCreationNewEntitlement() throws Exception {
		log.info("Validating updated Entitlement Type is available while creation of an Entitlement");
		ep.validatesUpdatedEntitlementTypeWhileEntitlementCreation(entitlementName, securitySys, endPointValue,
				entitlementTypeNameUpdate);
	}

	@And("User validates Entitlement creation without mandatory details and create entitlement with all mandatory details")
	public void userCreatesNewEntitlementWithOutMandatoryDetails() throws Exception {
		log.info("creating New Entitlement with entering mandatory details");
		ep.createEntitlementWithMandatoryDetails(entitlementName, securitySys, endPointValue, entitlementTypeValue);
	}

	@And("User validates Entitlement Type creation without mandatory details and create entitlement Type with all mandatory details")
	public void userCreatesNewEntitlementTypeWithOutMandatoryDetails() throws Exception {
		log.info("creating New Entitlement Type with entering mandatory details");
		ep.createEntitlementTypeWithMandatoryDetails(entitlementTypeName, entitlementTypeDisplayName, securitySys);
	}

	@And("User Updates Entitlement Type")
	public void updateEntitlementType() throws Exception {
		log.info("Update an existing Entitlement Type");
		ep.updateEntitlementType(entitlementTypeName, entitlementTypeNameUpdate, entitlementTypeDisplayNameUpdate,
				entitlementTypeDescription, securitySys);
	}

	@And("User validates delete existing Entitlement Type")
	public void deleteEntitlementType() throws Exception {
		log.info("Delete an existing Entitlement Type");
		ep.deleteEntitlementType(entitlementTypeNameUpdate);
	}

	@And("User navigates to Entitlements in Identity repository")
	public void navigateToEntitlementsInIdentityRepository() throws Exception {
		log.info("Navigating to Entitlements page ");
		ep.navigateToEntitlementsInIdentityRepo();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));

	}

	@Then("User Validates if the Entitlement is created with correct details")
	public void ValidateNewEntitlement() throws Exception {
		log.info("Validate New Entitlement");
		ep.searchEntitlement(entitlementName);
		ep.validateEntitlement(securitySys, endPointValue, entitlementTypeValue);
	}

	@Then("User Validates if the Entitlement is updated with correct details")
	public void ValidateUpdatedEntitlement() throws Exception {
		log.info("Validate Updated Entitlement");
		ep.searchEntitlement(entitlementName);
		ep.validateUpdatedEntitlement(entitlementDescription, entitlementOwner, associateEntitlement);
	}

	@Then("User Validates if the Entitlement is updated with correct details for metaData validation")
	public void ValidateUpdatedEntitlementForMetaDataValidation() throws Exception {
		log.info("Validate MetaData Updated Entitlement");
		ep.searchEntitlement(entitlementMetaDataName);
		ep.validateUpdatedEntitlement(entitlementDescription, entitlementOwner, associateEntitlement);
	}

	@Then("User Validates if the Entitlement is updated with correct role details")
	public void ValidateUpdatedEntitlementWithRole() throws Exception {
		log.info("Validate Entitlement is updated with correct role details");
		ep.searchEntitlement(entitlementName);
		ep.validateUpdatedEntitlementWithRole(entitlementName, EntitlementRoleName);
	}

	@Then("User Validates if the Entitlement is updated with correct entitlement Map details")
	public void ValidateUpdatedEntitlementWithEntitlementMap() throws Exception {
		log.info("Validate Entitlement is updated with correct entitlement map details");
		ep.searchEntitlement(entitlementName);
		ep.validateUpdatedEntitlementWithEntitlementMap(entitlementName, EntilementMap);
	}

	@Then("User Validates if the Entitlement doesn't have any of the removed details")
	public void ValidateEntitlementWithoutRemovedDetails() throws Exception {
		log.info("Validate Entitlement has no removed details");
		ep.searchEntitlement(entitlementName);
		ep.validateUpdatedEntitlementWithoutRemovedDetails(entitlementDescription, entitlementOwner);
	}

	@Then("User Validates if the Entitlement is inactive")
	public void ValidateEntitlementInactive() throws Exception {
		log.info("Validate Entitlement is in Inactive status");
		ep.searchEntitlement(EntitmentForInactiveValidation);
		ep.validateInactiveEntitlement(entitlementStatus);
	}

	@Then("User Validates if the Entitlement is updated with account details")
	public void ValidateAccountAddedForEntitlement() throws Exception {
		String externalUserNameForSingleWorkFlow=getValue("externalUserNameForSingleWorkFlow");
		log.info("Validate User account added for Entitlement");
		ep.searchEntitlement(entitlementName);
		ep.validateAccountForEntitlement(externalUserNameForSingleWorkFlow, SecuritySystemSingleLevel);
	}

	@And("user enters username and password for entitlement MetaData Validation")
	public void enterCrednetialsForEntitlementMetaDataValidation() {
		String entitlementMetaDataUserName=getValue("entitlementMetaDataUserName");
		String entitlementMetaDataPassword=getValue("entitlementMetaDataPassword");
		try {
			lp.setUserName(entitlementMetaDataUserName);
			lp.setPassword(entitlementMetaDataPassword);
			lp.clickSubmit();
			Thread.sleep(1000);

		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}

	}

	@Given("User navigates to Update Existing Entitlement page")
	public void navigateToUpdateExistingEntitlement() throws Exception {
		log.info("navigating to Update Existing Entitlement");
		ep.navigateToUpdateExistingEntitlement();
	}

	@And("User updates Entitlement with provided details")
	public void updateExistingEntitlement() throws Exception {
		log.info("Updating Existing Entitlement");
		ep.searchEntitlement(entitlementName);
		ep.clickSearchedEntitlement();
		ep.updateEntitlement(entitlementDescription, entitlementOwner, associateEntitlement, securitySys, endPointValue,
				entitlementTypeValue);

	}

	@And("User adds role to an existing entitlement")
	public void addRoleToExistingEntitlement() throws Exception {
		log.info("Add role to an Existing Entitlement");
		ep.searchEntitlement(entitlementName);
		ep.clickSearchedEntitlement();
		ep.addRoleToEntitlement(EntitlementRoleName);
		// ep.updateEntitlementOwner(entitlementOwner);
	}

	@And("User adds entitlement map to an existing entitlement")
	public void addEntitlementMapToExistingEntitlement() throws Exception {
		log.info("Add entitlement map to an Existing Entitlement");
		ep.searchEntitlement(entitlementName);
		ep.clickSearchedEntitlement();
		ep.addEntitlementMapToEntitlement(EntilementMap);
		// ep.updateEntitlementOwner(entitlementOwner);
	}

	@And("User validates mandatory fields while updating Entitlement")
	public void updateExistingEntitlementValidateMadatoryFields() throws Exception {
		log.info("Validate Madatory Fields while updating an Entitlement");
		ep.searchEntitlement(entitlementName);
		ep.clickSearchedEntitlement();
		ep.validateMandatoryFieldsUpdateEntitlement();
		// ep.updateEntitlementOwner(entitlementOwner);
	}

	@And("User updates Entitlement by removing existing details")
	public void updateExistingEntitlementByRemovingExistingDetails() throws Exception {
		log.info("Updating Existing Entitlement by removing existing details");
		ep.searchEntitlement(entitlementName);
		ep.clickSearchedEntitlement();
		ep.updateEntitlementByRemovingExistingDetails(entitlementDescription, entitlementOwner);
		// ep.updateEntitlementOwner(entitlementOwner);
	}

	@And("User updates Entitlement by making status Inactive From Active")
	public void updateExistingEntitlementByInactivating() throws Exception {
		log.info("Updating Existing Entitlement by inactivating");
		ep.searchEntitlement(EntitmentForInactiveValidation);
		ep.clickSearchedEntitlement();
		ep.updateEntitlementByMakingIactive(entitlementStatus);
		// ep.updateEntitlementOwner(entitlementOwner);
	}

	@And("User updates Entitlement with provided details for Meta Data Validation")
	public void updateExistingEntitlementWithMetaData() throws Exception {
		log.info("Updating Existing Entitlement");
		ep.searchEntitlement(entitlementMetaDataName);
		ep.clickSearchedEntitlement();
		ep.updateEntitlementWithMetaData(securitySys, endPointValue, entitlementTypeValue, entitlementDescription,
				entitlementOwner, associateEntitlement);

	}

	@Then("User validates the updated details for Entitlement")
	public void ValidateUpdatedEntitlementDetailsAsAnotherUser() throws Exception {
		String entitlementMetaDataUserName=getValue("entitlementMetaDataUserName");
		log.info("Validate Updated Entitlement as another user" + entitlementMetaDataUserName);
		ep.searchEntitlement(entitlementName);
		ep.validateUpdatedEntitlementAsAnotherUSer(soxCriticalValue, SyscriticalValue, RiskValue,
				entitlementDescription, entitlementOwner);
	}

	@And("User navigates to Campaign page")
	public void user_navigates_to_campaign_page() throws AWTException, InterruptedException {
		log.info("Navigating to Home page");
		cp.navigateToCampaign();
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));

	}

	/*
	 * @And("User search for the certification to validate") public void
	 * user_search_for_the_certification_to_validate() throws InterruptedException {
	 * log.info("Searching for certification"); cp.searchCertification(
	 * "STA_Annual_Manager_Campaign_Reconfigure-snigdha-01102023 - snigdha.ahmed (Snigdha Ahmed)"
	 * );
	 * 
	 * }
	 */

	/*	@And("User search for the quaterly campaign to validate")
	public void user_search_for_the_quaterly_campaign_to_validate() throws InterruptedException {
		log.info("Searching for campaign");
		cp.searchCampaign(quarterlyCampaign);
		cp.clickCampaign(quarterlyCampaign);

	}
	 */
	/*

	@And("User search for the quarterly certification to validate")
	public void user_search_for_the_quarterly_certification_to_validate() throws InterruptedException {
		log.info("Searching for certification");
		cp.searchCertification(quarterlyCertification);

	}
	 */

	@And("User activates certification")
	public void user_activates_certification() throws InterruptedException {
		log.info("Activating certification");
		cp.activatequarterlyCertification();

	}

	@And("User validates if the employee works for him for User Manager certification")
	public void user_validates_if_the_employee_works_for_him_for_User_Manager_certification() throws InterruptedException, FileNotFoundException {
		//cp.searchCertification(annualCertification);
		log.info("Validating if employee works for him");
		Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "//src//test//resources//TestData//QuarterlyCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[20];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				log.info("searching user " + record[0]);
				cp.searchUser(record[0]);
				log.info("select Employment Status of " + record[0] + " as " + record[1]);
				//log.info("Records: " + record[0]+ record[1]+ record[2]+ record[3]+ record[4]+ record[5]+record[6]);
				cp.selectEmploymentStatus(record[0],record[2],record[3],record[4],record[5],record[6]);


			}
		}

		log.info("Validating if employee works for him has done");


	}
	/*
	@And("User selects the user to be certified")
	public void user_selects_the_user_to_certify() throws InterruptedException {
		log.info("Searching for certification");
		cp.searchUser(employAnnual);

	}
	 */

	/*
	@And("User selects the user to be quaterly certified")
	public void user_selects_the_user_to_qauteryly_certify() throws InterruptedException {
		log.info("Searching for certification");
		cp.searchUser(employQuaterly);

	}
	 */
	/*
	@And("User validates if the employee works for him")
	public void user_validates_if_the_employee_works_for_him() throws InterruptedException, FileNotFoundException {
		// cp.searchCertification(annualCertification);

		log.info("Validating if employee works for him");
		Scanner scan = new Scanner(new File(
				System.getProperty("user.dir") + "//src//test//resources//TestData//AnnualCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				log.info("searching user " + record[0]);
				cp.searchUser(record[0]);

				log.info("select Employment Status of " + record[0] + " as " + record[1]);
				cp.selectEmploymentStatus(record[0], record[1], record[2], record[3], record[4], record[5], record[6]);

			}
		}
	}
	 */

	@And("User adds esignature while completing app owner certification")
	public void user_adds_esignature_for_appowner_certification() throws InterruptedException, FileNotFoundException {

		log.info("Adding signature to finish certification");
		cp.addSignature(eusername, epassword,commentForAddingSignature);
		cp.completeCertification();

	}

	@And("User verifies if application owner certification is completed")
	public void user_verifies_if_application_owner_certification_is_completed() throws InterruptedException, AWTException {
		Thread.sleep(4000);
		log.info("Wait for certification to reflect status as completed");
		Thread.sleep(4000);
		log.info("Searching for certification");
		Thread.sleep(3000);
		log.info("Searching for certification");
		cp.searchCertification(appOwnerCertificationName);
		//cp.searchCertification(roleOwnerCertification);
		Thread.sleep(3000);
		cp.checkCompleteValidation();
	}

	@And("User verifies if user manager certification is completed")
	public void user_verifies_if_user_manager_certification_is_completed() throws InterruptedException, AWTException {
		Thread.sleep(4000);
		log.info("Wait for certification to reflect status as completed");
		Thread.sleep(4000);
		log.info("Searching for certification");
		Thread.sleep(3000);
		log.info("Searching for certification");
		cp.searchCertification(userManagerCertificationName);
		//cp.searchCertification(roleOwnerCertification);
		Thread.sleep(3000);
		cp.checkCompleteValidation();
	}



	@And("User certifies or revokes the certification")
	public void user_certifies_or_revokes_the_certification() throws InterruptedException {

	}

	@And("User verifies if certification is completed")
	public void user_verifies_if_certification_is_completed() throws InterruptedException, AWTException {
		Thread.sleep(4000);
		log.info("Searching for certification");
		Thread.sleep(3000);
		cp.searchCertification(userManagerCertificationName);
		Thread.sleep(4000);
		cp.checkCompleteValidation();
	}

	@And("User Validates if campaign is launched")
	public void user_validates_campaignLaunch_changeOfPosition() {
		try {
			log.info("Campaign Name: " + changeOfPositionCampaigName);
			cp.searchclickCampaign(changeOfPositionCampaigName);
		} catch (InterruptedException e) {
			log.info("Campaign validation failed");

		}

	}
	@And("User search for the User Manager campaign to validate")
	public void user_search_for_the_campaign_to_validate() throws InterruptedException {
		log.info("Searching for campaign");
		cp.searchCampaign(userManagerCampaignName);


	}
	@And("User Search and click on the campaign for user revoke")
	public void user_search_clicks_campaign_user_revoke() {
		try {
			log.info("Campaign Name for user revoke: " + appOwnercampaignName);
			cp.searchclickCampaign(appOwnercampaignName);
		} catch (InterruptedException e) {
			log.info("Campaign validation failed");

		}

	}

	@And("User completes app owner certification")
	public void user_completes_appwner_certification() throws InterruptedException, FileNotFoundException {
		log.info("finishing certification");
		cp.finishAppOwnerCertification();


	}

	@And("Ceritifier Validates the user access")
	public void certifier_validates_user_access_changeOfPosition() {
		try {
			log.info("Start the Ceritification: "+changeOfPositionCertificationName);
			cp.activateCertification();
			cp.searchUser(changeOfPositionUserName);
			cp.validateTotalNumberOfAccountUserPartOf(changeOfPositionUserName,changeOfPositionTotalNumberOfAccountsUserIsPartOf);
			//cp.updateUserEmploymentStatus(changeOfPositionUserName);
		} catch (InterruptedException e) {

		}

	}
	@And("User search for the User Manager certification to validate")
	public void user_search_for_the_User_Manager_certification_to_validate() throws InterruptedException {
		cp.clickCampaign(userManagerCampaignName);cp.clickCampaign(userManagerCampaignName);
		log.info("Searching for certification");
		cp.searchCertification(userManagerCertificationName);

	}

	@And("User validates User Manager certification")
	public void user_validates_User_Manager_certification() throws InterruptedException, FileNotFoundException {
		log.info("Navigating to Certification Page");
		cp.validateCertificationPage();
		log.info("User validates certification");
		Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "//src//test//resources//TestData//QuarterlyCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]+ " , " + record[7]+ " , " + record[8]);
			if ((!record[0].equalsIgnoreCase("Username")) && (!record[1].equalsIgnoreCase("EmploymentStatus"))) {
				//log.info("searching user " + record[0]);
				if(record[7].equalsIgnoreCase("Yes")) {
					log.info("Search user to certify"+record[1]);
					//cp.searchUserToCertify(record[0]);
					//log.info("User validating certification");
					//cp.validateCertification(record[7],record[8]);
					cp.searchUserAndCertifyFromFilters(record[1]);
				}else if (record[8].equalsIgnoreCase("Yes")){
					log.info("Search user to remove"+record[1]);
					cp.searchUserAndRevokeFromFilters(record[1]);

				}


			}




		}
	}


	@Given("User executes Job under control panel")
	public void executeJob() throws Exception {
		Thread.sleep(1000);
		log.info("**********User execute job********");
		try {
			ap.executeJob();

		} catch (Exception e) {
			log.info("Job execution has failed");
		}

	}

	@And("User provides the file in .csv containing detials of new users for birthright access validation")
	public void detialsOfUsersinCsv() throws Exception {
		log.info("providing the detials of new user");
		//ba.provideCSV();
		selectFile.selectCSVWithDetails("BirthRightAccess.csv");

	}

	@And("User provides the file in .csv containing detials of new users for SOD violation validation")
	public void detialsOfUsersinCsvForSOD() throws Exception {
		log.info("providing the detials of new user");
		sod.provideCSV();

	}

	@And("User provides the file in .csv containing detials of new users for SOD violation validation When SOD Actioned")
	public void detialsOfUsersinCsvForSODWhenSODActioned() throws Exception {
		log.info("providing the detials of new user");
		sod.provideCSVWhenSODActioned();

	}

	@And("User provides the file in .csv containing detials of new users for preventive SOD violation")
	public void detialsOfUsersinCsvForPreventiveSODViolation() throws Exception {
		log.info("providing the detials of new user");
		sod.provideCSVForPreventiveSODViolation();

	}

	@Then("User Validates if pending task is created and approves it")
	public void user_validates_if_pending_task_is_created()
			throws AWTException, InterruptedException, FileNotFoundException {
		driver.navigate().refresh();
		log.info("Validating if pending task is created");
		try {
			Scanner scan = new Scanner(new File(
					System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\BirthRightAccess.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					uc.searchUser(record[0]);
					String securitySystems = "STA Disconnected,STA Disconnected 2,STA Disconnected 3";
					// {"STA Disconnected","STA Disconnected 2","STA Disconnected 3"};
					// "STADisconnected,STADisconnected2,STADisconnected3";
					ba.validateAccountCreationForBirthRight(record[0], securitySystems);

				}
			}

		} catch (Exception e) {
			log.info("Validating pending task has failed");
		}
	}

	@Then("User Validates if pending task is created and approves it for SOD Violation")
	public void user_validates_if_pending_task_is_created_SOD_Violation()
			throws AWTException, InterruptedException, FileNotFoundException {
		driver.navigate().refresh();
		log.info("Validating if pending task is created for SOD Violation");
		try {
			Scanner scan = new Scanner(
					new File(System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\SODViolation.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					uc.searchUser(record[0]);

					sod.validateAccountCreationForSODViolation(record[0], SecuritySystemSingleLevel);

				}
			}

		} catch (Exception e) {
			log.info("Validating pending task has failed");
		}
	}

	@Then("User Validates if pending task is created and approves it for SOD Violation when SOD actioned")
	public void user_validates_if_pending_task_is_created_SOD_ViolationWhenSODACtioned()
			throws AWTException, InterruptedException, FileNotFoundException {
		driver.navigate().refresh();
		log.info("Validating if pending task is created for SOD Violation");
		try {
			Scanner scan = new Scanner(new File(System.getProperty("user.dir")
					+ "\\src\\test\\resources\\TestData\\SODViolationWhenSODActioned.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					uc.searchUser(record[0]);

					sod.validateAccountCreationForSODViolation(record[0], SecuritySystemSingleLevel);

				}
			}

		} catch (Exception e) {
			log.info("Validating pending task has failed");
		}
	}

	@Then("User Validates if pending task is created and approves it for Preventive SOD Violation")
	public void user_validates_if_pending_task_is_created_Preventive_SOD_Violation()
			throws AWTException, InterruptedException, FileNotFoundException {
		driver.navigate().refresh();
		log.info("Validating if pending task is created for Preventive SOD Violation");
		try {
			Scanner scan = new Scanner(new File(
					System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\PreventiveSODViolation.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					uc.searchUser(record[0]);

					sod.validateAccountCreationForPreventiveSODViolation(record[0], SecuritySystemSingleLevel);

				}
			}

		} catch (Exception e) {
			log.info("Validating pending task has failed");
		}
	}

	@Then("User uploads the users list")
	public void uploadFile() throws Exception {
		try {
			log.info("upload the user request");
			sod.uploadUserRequest();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	@Then("User Validates if all the user requests in csv has Birthright access")
	public void validateBirthrightAccess() throws Exception {
		Thread.sleep(1000);
		log.info("********** Validating Birthright access ********");
		try {
			Scanner scan = new Scanner(new File(
					System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\BirthRightAccess.csv"));
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[10];
			while (scan.hasNext()) {
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("records " + record[0] + " , " + record[1]);
				if (!record[0].equalsIgnoreCase("Username")) {
					log.info(record[0]);
					uc.searchUser(record[0]);
					String securitySystems = "STA Disconnected,STA Disconnected 2,STA Disconnected 3";
					ba.validateAccountCreation(record[0], securitySystems);
				}
			}

		} catch (Exception e) {
			log.info("Validating Birthright access has failed");
		}

	}

	@And("User requests access for required target system and Validates if  access request for endpoint is created for SOD violation")
	public void User_RequestAccess_for_TargetSystem() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(6000);		
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		sod.searchEndpointToRequestAccess(SecuritySystemSingleLevel,Entitlement1ForSODViolation,Entitlement2ForSODViolation,accountNameOfAnUserWhileRequestingAccessForSOD);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);

	}

	@And("User requests access for required target system and Validates if  access request for endpoint is created for Entitlement with Associate Entitlement")
	public void User_RequestAccess_for_TargetSystem_AndEntitlement_AssociateEntitlmet()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint and entitlement with associate entitlement");
		Thread.sleep(2000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		String RequestIdFetch = sod.searchEndpointToRequestAccessForEntitlementWithAssociateEntitlemnt(
				EntitmentWithAssociateEntitlement, SecuritySystemSingleLevel);
		String[] splited = RequestIdFetch.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[text()='Request History']")).click();
		log.info("User is on Request History page");

	}

	@And("User requests access for required target system and Validates next approver is the Delegated User")
	public void User_RequestAccess_for_TargetSystem_Delegate()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint and validating next approver");
		Thread.sleep(6000);
		// wf.searchUserToRequestAccess(userWorkFlow);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		String RequestIdFetch = wf.searchEndpointToRequestAccessDelegate(delegateUser, SecuritySystemSingleLevel,
				accountNameOfAnUserWhileRequestingAccess);
		String[] splited = RequestIdFetch.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("User requests access for required target system and Validates if  access request for endpoint is created for Single WorkFlow as an External User")
	public void User_RequestAccess_for_TargetSystem_WorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(6000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		wf.searchEndpointToRequestAccess(SecuritySystemSingleLevel, accountNameOfAnUserWhileRequestingAccess,
				STA_Entitlement);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("User requests access for required target system and Validates if  access request for validation of Manager Termination flow")
	public void User_RequestAccess_for_TargetSystem_WorkFlow_ManagerTErmination()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		String managersManagerUserName=getValue("managersManagerUserName");
		Thread.sleep(6000);
		//highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		wf.searchEndpointToRequestAccess(SecuritySystemSingleLevel,
				accountNameOfAnUserWhilerequestingAccessForManagerTermination, STA_Entitlement);
		// String[] splited = RequestIdFetch.split("\\s+");
		// log.info("****RequestID created: " + splited[1]);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		sod.searchUserRequestHistoryPage(wf.requestID);
		Thread.sleep(1000);
		wf.User_validates_pendingApprovalWithManagerManager_whenManagerTerminated(managersManagerUserName,
				SecuritySystemSingleLevel);
	}

	@And("User requests access for required target system with inflight checked and Validates access request is created for the endpoint")
	public void User_RequestAccess_for_TargetSystem_Inflight()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(6000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		wf.searchEndpointToRequestAccessInFlight(SecuritySystemTwoLevelSerial,
				accountNameOfAnUserWhileRequestingAccess,entitlementForInflightRequest);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("User requests access for required target system with inflight checked and Validates proper message gets displayed")
	public void validate_Request_Access_TargetSystem_Inflight()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint with inflight checked");
		Thread.sleep(6000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		wf.validateRequestAccessInFlight(SecuritySystemTwoLevelSerial);
		driver.findElement(By.xpath("//*[@class='MuiButtonBase-root MuiIconButton-root']")).click();
		Thread.sleep(1000);
	}



	@And("Search User for whom access request needs to be removed and validate access removal")
	public void User_remove_Access_for_TargetSystem_WorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Removing Access for endpoint");
		String externalUserNameForSingleWorkFlow=getValue("externalUserNameForSingleWorkFlow");
		Thread.sleep(6000);
		wf.searchUserToRequestAccess(externalUserNameForSingleWorkFlow);
		wf.searchEndpointToRemoveAccess(accountNameOfAnUserWhileRequestingAccess, securitySys);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("Search User for whom account needs to be locked and create request to lock the account")
	public void User_account_locked() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Search user and account needs to be locked");
		String externalUserNameForSingleWorkFlow=getValue("externalUserNameForSingleWorkFlow");
		Thread.sleep(6000);
		wf.searchUserToRequestAccess(externalUserNameForSingleWorkFlow);
		wf.searchEndpointToLock(accountNameOfAnUserNeedToLock, securitySys);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("Search User for whom account needs to be unlocked and create request to unlock the account")
	public void User_account_unlocked() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Search user and account needs to be unlocked");
		String externalUserNameForSingleWorkFlow=getValue("externalUserNameForSingleWorkFlow");
		Thread.sleep(6000);
		wf.searchUserToRequestAccess(externalUserNameForSingleWorkFlow);
		wf.searchEndpointToLock(accountNameOfAnUserNeedToLock, securitySys);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("Search User for whom access request needs to be removed and validate access removal for Two Phase")
	public void User_remove_Access_for_TargetSystem_Two_phase_WorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Removing Access for an endpoint");
		String externalUserNameForTwoLevelWorkFlow=getValue("externalUserNameForTwoLevelWorkFlow");
		Thread.sleep(6000);
		wf.searchUserToRequestAccess(externalUserNameForTwoLevelWorkFlow);
		wf.searchEndpointToRemoveAccess(accountNameOfAnUserWhileRequestingAccess, SecuritySystemTwoLevel);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("User requests access for required target system and Validates if  access request for endpoint is created for Single WorkFlow as an External User for Reject")
	public void User_RequestAccess_for_TargetSystem_WorkFlow_Reject_Validation()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint for Validating Reject Flow");
		Thread.sleep(6000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		wf.searchEndpointToRequestAccessForRejectValidation(SecuritySystemSingleLevel, STA_Entitlement);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);
	}

	@And("User requests access for required target system and Validates if  access request for endpoint is created for Two Level WorkFlow as an External User")
	public void User_RequestAccess_for_TargetSystem_Two_Level_WorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");

		driver.navigate().refresh();
		Thread.sleep(6000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		wf.searchEndpointToRequestAccessForExternalUser(accountNameOfAnUserWhileRequestingAccess,
				SecuritySystemTwoLevel);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);

	}

	@And("User requests access for required target system and Validates if  access request for endpoint is created for Two Level Serial WorkFlow as an External User")
	public void User_RequestAccess_for_TargetSystem_Two_Level_Serial_WorkFlow()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		driver.navigate().refresh();
		Thread.sleep(6000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Request New Access']")));
		String RequestIdFetch = wf.searchEndpointToRequestAccessForExternalUserForEntitlement(
				accountNameOfAnUserWhileRequestingAccess, SecuritySystemTwoLevelSerial,
				EntitlementForTwoLevelSerialWorkflow);
		String[] splited = RequestIdFetch.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		driver.findElement(By.xpath("//*[@class='anchorButton link']")).click();
		Thread.sleep(1000);

	}

	/*@And("User requests access for required target system and Validates if  access request for endpoint is created for SOD violation when SOD is actioned")
	public void User_RequestAccess_for_TargetSystemWhenSODActioned()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(2000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage Access For Team']")));
		wf.searchUserToRequestAccess(UserForSODViolationwhenSODActioned);
		String RequestIdFetch = sod.searchEndpointToRequestAccess(Entitlement1ForSODViolation,
				Entitlement2ForSODViolation, SecuritySystemSingleLevel,accountNameOfAnUserWhileRequestingAccessForSOD);
		String[] splited = RequestIdFetch.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[text()='Request History']")).click();
		log.info("User is on Request History page");
		log.info("Navigating to pending approvals page");
		// driver.navigate().refresh();
		ap.navigateToAdminPage();
		apps.navigateToHomePage();
		wf.navigateToPendingApprovalsPage();
		log.info("Validating if the access for endpoint request is created");
		wf.searchRequestId(splited[1]);
	}
	 */
	@And("User requests access for required target system and Validates if  access request for endpoint is created for Preventive SOD violation")
	public void User_RequestAccess_for_TargetSystemForPreventiveSODViolation()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(2000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage Access For Team']")));
		wf.searchUserToRequestAccess(UserForPreventitiveSODViolation);
		String RequestIdFetch = sod.searchEndpointToRequestAccessForPreventiveViolation(Entitlement1ForSODViolation,
				Entitlement2ForSODViolation, SecuritySystemSingleLevel);
		String[] splited = RequestIdFetch.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[text()='Request History']")).click();
		log.info("User is on Request History page");
		log.info("Navigating to pending approvals page");
		// driver.navigate().refresh();
		ap.navigateToAdminPage();
		apps.navigateToHomePage();
		wf.navigateToPendingApprovalsPage();
		log.info("Validating if the access for endpoint request is created");
		wf.searchRequestId(splited[1]);

	}

	@And("User requests access for required target system and Validates if  access request for endpoint is created for Preventive SOD violation ExternalUser")
	public void User_RequestAccess_for_TargetSystemForPreventiveSODViolationExternalUser()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for endpoint");
		Thread.sleep(2000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage Access For Team']")));
		wf.searchUserToRequestAccess(UserForPreventitiveSODViolation);
		String RequestIdFetch = sod.searchEndpointToRequestAccessForPreventiveViolation(Entitlement1ForSODViolation,
				Entitlement2ForSODViolation, SecuritySystemSingleLevel);
		String[] splited = RequestIdFetch.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[text()='Request History']")).click();
		log.info("User is on Request History page");
		// log.info("Navigating to pending approvals page");
		// driver.navigate().refresh();
		// ap.navigateToAdminPage();
		// apps.navigateToHomePage();
		// wf.navigateToPendingApprovalsPage();
		// log.info("Validating if the access for endpoint request is created");
		// apps.navigateToHomePage();
		// driver.navigate().refresh();
		// wf.searchRequestId(splited[1]);

		// log.info("Request Id :" +RequestId.split(" "));
		// wf.requestAccessToEndpoint();
	}

	@And("User validates if application allows the user to be part of second entitlement of an existing request")
	public void User_RequestAccess_for_SecondTargetSystemForPreventiveSODViolation()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Update an existing request for access to second entitlement");
		Thread.sleep(2000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage Access For Team']")));
		wf.searchUserToRequestAccess(UserForPreventitiveSODViolation);

		sod.searchEndpointToRequestAccessForSecondEntitlementPreventiveViolation(Entitlement1ForSODViolation,
				Entitlement2ForSODViolation, SecuritySystemSingleLevel);

	}

	@Then("User validates if user is added to the Entitlement")
	public void user_validates_if_account_of_user_hasEntitlementAdded()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\SODViolation.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				sod.validateAccountCreation(record[0], SecuritySystemSingleLevel);

			}
		}

	}

	@Then("User validates if user is added to the Entitlement and also associate entitment")
	public void user_validates_if_account_of_user_hasEntitlementWithAssociateEntitlementAdded()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\UserForEntitlementWithAssociateEntitlement.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				sod.validateAccountCreation(record[0], SecuritySystemSingleLevel);

			}
		}

	}

	@Then("User validates if user is added to the Entitlement for Preventive SOD violation")
	public void user_validates_if_account_of_user_hasEntitlementAddedForPreventiveSODViolation()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\PreventiveSODViolation.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				sod.validateAccountCreation(record[0], SecuritySystemSingleLevel);

			}
		}

	}

	@Then("SOD Actioned User validates if user is added to the Entitlement")
	public void user_validates_if_account_of_user_hasEntitlementAddedWhenSODActioned()
			throws AWTException, InterruptedException, FileNotFoundException {

		Scanner scan = new Scanner(new File(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\SODViolationWhenSODActioned.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				uc.searchUser(record[0]);

				sod.validateAccountCreation(record[0], SecuritySystemSingleLevel);

			}
		}

	}

	/*
	@And("User Validates the approval is pending with the manager's manager when the manager is terminated")
	public void User_validates_pendingApprovalWithManagerManager_whenManagerTerminated()
			throws AWTException, InterruptedException, FileNotFoundException {
		log.info("");
		wf.User_validates_pendingApprovalWithManagerManager_whenManagerTerminated(UserTypeForLogin,
				SecuritySystemSingleLevel);
		highLightElement(driver, driver.findElement(By.xpath("(//*[@class='d-flex flex-column  pl-3  '])[1]")));
	}
	*/

	@And("User validates Delegate creation without mandatory details and create Delegate with all mandatory details")
	public void userCreatesDelegate() throws Exception {
		log.info("creation of Delegates with mandatory details");
		delegate.createDelegateWithMandatoryDetails(delegateReason, delegateDescription, delegateParentUser,
				delegateUser, delegateStartDate, delegateEndDate);
		highLightElement(driver, driver.findElement(By.xpath("(//*[@class='page-title']")));
	}

	@And("User validates inactive user is not listed under delegate User List")
	public void validateInactiveUserNotDelegate() throws Exception {
		log.info("Validation inactive user is not listed under Delegate User List");
		delegate.inActiveUserNotDelegate(inactiveUser, delegateReason, delegateDescription, delegateParentUser,
				delegateUser, delegateStartDate, delegateEndDate);
		highLightElement(driver, driver.findElement(By.xpath("//*[@class='page-title']")));
	}

	@And("User Validates delegate is created with correct details")
	public void uservalidatesDelegate() throws Exception {
		log.info("Validation of Created Delegates with correct details");
		delegate.createDelegateWithMandatoryDetails(delegateReason, delegateDescription, delegateParentUser,
				delegateUser, delegateStartDate, delegateEndDate);
		highLightElement(driver, driver.findElement(By.xpath("(//*[@class='page-title']")));
	}

	@And("User validates if the employee works for him for quarterly certification")
	public void user_validates_if_the_employee_works_for_him_for_quarterly_certification()
			throws InterruptedException, FileNotFoundException {
		// cp.searchCertification(annualCertification);

		log.info("Validating if employee works for him");
		Scanner scan = new Scanner(new File(
				System.getProperty("user.dir") + "//src//test//resources//TestData//QuarterlyCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("Username")) {
				log.info("searching user " + record[0]);
				cp.searchUser(record[0]);
				log.info("select Employment Status of " + record[0] + " as " + record[1]);

				cp.selectEmploymentStatus(record[0],record[2], record[3], record[4], record[5], record[6]);

			}
		}

		log.info("Validating if employee works for him has done");

	}

	/*
	@And("User validates quarterly certification")
	public void user_validates_quarterlycertification() throws InterruptedException, FileNotFoundException {
		log.info("Navigating to Certification Page");
		cp.validateCertificationPage();
		log.info("User validates certification");
		Scanner scan = new Scanner(new File(
				System.getProperty("user.dir") + "//src//test//resources//TestData//QuarterlyCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if ((!record[0].equalsIgnoreCase("Username")) && (!record[1].equalsIgnoreCase("Terminated"))) {
				log.info("searching user " + record[0]);
				cp.searchUserToCertify(record[0]);
				log.info("User validating certification");
				cp.validateCertification(systemNameForCertifying);

			}
		}

	}
	 */

	@And("User completes certification")
	public void user_completes_certification() throws InterruptedException, FileNotFoundException {

		log.info("finishing certification");
		cp.finishCertification();

	}

	@And("User adds esignature while completing certification")
	public void user_adds_esignature_for_certification() throws InterruptedException, FileNotFoundException {

		log.info("Adding signature to finish certification");
		cp.addSignature(eusername, epassword, commentForAddingSignature);

	}

	@And("user enters default reassignee username and password")
	public void enterDefaultReassigneeCrednetials() {
		try {
			lp.setUserName("testusername2");

			lp.setPassword("Test@1234");

			lp.clickSubmit();
			Thread.sleep(1000);

		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}

	}

	@And("User validates if the employee works for him for reassigned quarterly certification")
	public void user_validates_if_the_employee_works_for_him_for_reassigned_quarterly_certification()
			throws InterruptedException, FileNotFoundException {
		// cp.searchCertification(annualCertification);

		log.info("Validating if employee works for him");
		Scanner scan = new Scanner(new File(
				System.getProperty("user.dir") + "//src//test//resources//TestData//QuarterlyCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!(record[0].equalsIgnoreCase("Username")) && record[1].equalsIgnoreCase("Does Not Work For Me")
					&& record[5].equals("Yes") && record[6].equals("Default")) {
				log.info("searching user " + record[0]);
				cp.searchUser(record[0]);
				log.info("select Employment Status of " + record[0] + " as " + record[1]);
				cp.selectReassinedEmploymentStatus(record[0], record[1], record[2], record[3], record[4], record[5],
						record[6]);

			}
		}

		log.info("Validating if employee works for him has done");

	}


	@And("User validates reassigned quarterly certification")
	public void user_validates_reassigned_quarterlycertification() throws InterruptedException, FileNotFoundException {
		log.info("Navigating to Certification Page");
		cp.validateCertificationPage();
		log.info("User validates certification");
		Scanner scan = new Scanner(new File(
				System.getProperty("user.dir") + "//src//test//resources//TestData//QuarterlyCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!(record[0].equalsIgnoreCase("Username")) && record[1].equalsIgnoreCase("Does Not Work For Me")
					&& record[5].equals("Yes") && record[6].equals("Default")) {
				log.info("searching user " + record[0]);
				cp.searchUserToCertify(record[0]);
				log.info("User validating certification");
				cp.validateCertification(systemNameForCertifying);

			}
		}
	}

	/*
	 * log.info("finishing certification"); cp.finishCertification();
	 * log.info("Adding signature to finish certification");
	 * cp.addSignature("testusername2", "Test@1234",commentForAddingSignature);
	 */

	//} 

	@And("User adds esignature while completing reassigned quarterly certification")
	public void user_adds_esignature_for_reassignedquarterlycertification() throws InterruptedException {

		log.info("Adding signature to finish certification");
		cp.addSignature("testusername2", "Test@1234", commentForAddingSignature);

	}

	@And("User verifies if reassigned quarterly certification is completed")
	public void user_verifies_if_reassigned_quarterly_certification_is_completed()
			throws InterruptedException, AWTException {
		Thread.sleep(4000);
		log.info("Wait for certification to reflect status as completed");
		Thread.sleep(4000);
		log.info("Searching for certification");
		Thread.sleep(3000);

		log.info("Searching for certification");
		cp.searchCertification(appOwnercampaignName);
		Thread.sleep(3000);
		cp.checkCompleteValidation();
	}

	@And("User search for the Role owner campaign to validate")
	public void user_search_for_the_annual_campaign_to_validate() throws InterruptedException {
		log.info("Searching for campaign");
		cp.searchCampaign(appOwnercampaignName);
		cp.clickCampaign(appOwnercampaignName);

	}

	@And("User search for the Role owner certification to validate")
	public void user_search_for_the_annual_certification_to_validate() throws InterruptedException {

		log.info("Searching for certification");
		cp.searchCertification(roleOwnerCertificationName);
		// cp.clickCertification(annualCertification);

	}

	
	@And("User completes Role owner certification")
	public void user_completes_roleowner_certification() throws InterruptedException, FileNotFoundException {

		log.info("finishing certification");
		cp.finishRoleOwnerCertification();

	}

	@And("User search for the Application owner campaign to validate")
	public void user_search_for_the_Application_campaign_to_validate() throws InterruptedException {
		log.info("Searching for Application campaign");
		cp.searchCampaign(appOwnercampaignName);
		cp.clickCampaign(appOwnercampaignName);

	}

	@And("User search for change of position user manager campaign to validate")
	public void user_search_for_the_change_of_postion_campaign() throws InterruptedException {
		log.info("Searching for Change of position campaign");
		cp.searchCampaign(changeOfPositionCampaigName);
		cp.clickCampaign(changeOfPositionCampaigName);

	}

	@And("User search for the Application owner certification to validate")
	public void user_search_for_the_Application_certification_to_validate() throws InterruptedException {

		log.info("Searching for certification");
		cp.searchCertification(appOwnerCertificationName);
		// cp.clickCertification(annualCertification);

	}

	@And("User search for the change of position certification to validate")
	public void user_search_for_the_change_position() throws InterruptedException {
		log.info("Searching for certification");
		cp.searchCertification(changeOfPositionCertificationName);
		cp.clickCertification(changeOfPositionCertificationName);

	}
	@And("User validates Application owner certification")
	public void user_validates_Application_owner_certification() throws InterruptedException, FileNotFoundException {
		log.info("Navigating to Certification Page");
		try {
			Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "//src//test//resources//TestData//ApplicationOwnerCertificationUsers.csv"));
			log.info("*********scanner**********");
			ArrayList<String[]> records = new ArrayList<String[]>();
			String[] record = new String[30];
			log.info("*************Array list is created*********");
			while (scan.hasNext()) {
				log.info("Scanning begins");
				record = scan.nextLine().split(",");
				records.add(record);
				log.info("user : " + record[0] + " , " + record[1]);
				if ((!record[0].equalsIgnoreCase("UsersForCertify")) && (!record[1].equalsIgnoreCase("UsersForRevoke"))) {
					cp.searchUserAndCertifyFromFilters(record[0]);
					cp.searchUserAndRevokeFromFilters(record[1]);

				}
			}
		}catch(Exception e) {
			log.info(e);
		}

	}

	@And("User creates Role without providing role name")
	public void creatingRoleWithoutName() throws Exception {
		log.info("creating Role with null value for role name ");

		rc.createNewRoleWithoutRolename();

	}

	@Then("User verifies if creating role without role name fails with error")
	public void ValidateCreatingRoleWithoutName() throws Exception {
		log.info("creating Role with null value for role name ");
		rc.ValidateCreatingNewRoles();
	}

	@And("User creates Role with already existing role name")
	public void creatingRoleWithalreadyexistingName() throws Exception {
		log.info("creating Role with null value for role name ");
		rc.createNewRoleWithAlreadyExistingRolename(existingRoleName);
	}

	@Then("User verifies if creating role with already existing role name fails with error")
	public void ValidateCreatingRoleWithalreadyexistingName() throws Exception {
		log.info("creating Role with null value for role name ");
		rc.ValidateCreatingNewRoles();
	}

	@And("user enters endusers username and password")
	public void enterRoleEndusersCrednetials() {
		String externalUserNameForRole=getValue("externalUserNameForRole");;
		String externalUserPasswordForRole=getValue("externalUserPasswordForRole");
		try {
			lp.setUserName(externalUserNameForRole);
			lp.setPassword(externalUserPasswordForRole);
			lp.clickSubmit();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.info("Username or Password  not found");
			((JavascriptExecutor) driver).executeScript("window.stop;");
			driver.quit();
		}
	}
	@And("User provides the file in .csv containing detials of new users for birthright access Discontinue validation")
	public void detialsOfUserstoDiscontinue() throws Exception {
		log.info("providing the detials of new user");
		selectFile.selectCSVWithDetails("BirthRightAccessDiscontinue.csv");

	}


	@Then("User verifies that create new role page cannot be accessed")
	public void validateEnduserCannotAccesscreateRolesPage() throws InterruptedException {
		rc.validateEndUsersAccessToCreateNewRole();
	}

	@And("User navigates to manage roles page in home")
	public void User_navigates_to_manage_roles_page() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Navigating to Manage Roles page");
		rc.navigateToManageRolesPage();
	}

	@Then("User verifies that manage roles page cannot be accessed")
	public void validateEnduserCannotAccessManageRolesPage() throws InterruptedException {
		rc.validateNoAccessForEndUser();

	}

	@And("User search for Role to be modified")
	public void searchRoletobemodified() throws Exception {
		log.info("Search for role which needs modification ");
		rc.searchRole(role2);

	}
	@And("User modifies existing role with provided details")
	public void modifyRoleDetails() throws Exception {
		log.info("User modifies existing role with provided details ");
		rc.editRole();
		rc.updateRoleDetails(roleDisplay,roleDescription);

	}
	@And("User navigates to version tab")
	public void navigateToVersionTab() throws Exception {
		apps.navigateToHomePage();
		ap.navigateToAdminPage();
		rc.navigateToRolesPage();
		log.info("Search for role ");
		rc.searchRole(role2);
		rc.editRole();
		log.info("User navigating to Version tab ");
		rc.navigateToVersion();

	}
	@And("User Discontinues the created version")
	public void discontinueVersion() throws Exception {
		log.info("User Discontinuing version created version");
		rc.discontinueVersion();
		log.info("User validating status of version");
		rc.validateDiscontinueStatus();

	}
	@And("User verifies that role is not updated with provided details after discontinuing version")
	public void verifiesTheRoleIsNotUpdated() throws Exception {
		log.info("User verifies that role is not updated with provided details");
		rc.validateThatRoleIsNotModified(roleDisplay, roleDescription);
	}
	@And("Send the final execution report")
	public void sentExectionReport() throws Exception {
		String[] toMailId=getValues("toMailIds"); 
		String FromMailId=getValue("fromMailId");
		String encryptedKey=getValue("encryptedKey");
		String subjectLine=getValue("subjectForMail");
		String mailBody=getValue("bodyOfMail");
		String attachementDesc=getValue("attachementDesc");
		String smtpHostName=getValue("smtpHostName");
		int smtpPortNumber=getIntValue("smtpPort");
		log.info("Get the latest Report from from Test output folder");
		commonFunctionUtil.getLatestReportFolders();
		log.info("Send out the final execution report to the specified mail id");
		commonFunction.sendEmail(smtpHostName,smtpPortNumber,attachementDesc,toMailId,FromMailId,encryptedKey,subjectLine,mailBody);
		log.info("**********Sent Report*********");

	}


	@And("User verifies if revoked users doesnot have access to role")
	public void user_validates_Roleowner_certificationRevoe() throws InterruptedException, FileNotFoundException {

		log.info("User validates certification after revoke");
		Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "//src//test//resources//TestData//RoleOwnerCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("RoleName")&& !record[1].equalsIgnoreCase("RoleStatus") && !record[2].equalsIgnoreCase("UsersToCertify")&& !record[3].equalsIgnoreCase("UsersToReject")
					&& !record[4].equalsIgnoreCase("AssociatedEntitlement")) {
				log.info("searching Role " + record[0]);
				cp.validateAccessToRoleAfterRevoke(record[0], record[3]);


			}
		}


	}

	@And("User modifies role with provided details")
	public void modifyRole() throws Exception {
		log.info("User modifies existing role with provided details ");
		rc.editRole();
		rc.updateRoleDetails(roleDisplay,roleDescription);

	}
	@And("User sends created version for approval")
	public void sendForApproval() throws Exception {
		log.info("User sends created version for approval");
		rc.sendVersionForApproval();

	}

	@And("User search for request id created")
	public void searchRequestId() throws Exception {

		log.info("User searching request");
		String rid = rc.taskId;
		log.info(rid);
		wf.searchRequestId(rid);

	}
	@And("User approves request for version created")
	public void approveRequest() throws Exception {

		log.info("User appproves request");
		rc.approveRequest();

	}

	@And("User verifies that role is updated with provided details")
	public void verifiesTheRoleIsUpdated() throws Exception {
		log.info("User verifies that role is updated with provided details");
		rc.editRole();
		rc.validateRoleModification(roleDisplay,roleDescription);
	}

	@Given("User navigates to role to be updated with provided details")
	public void updateRolesWithprovidedDetails() throws Exception {
		log.info("Update Existing Role with Onwer Details ");
		// ap.navigateToAdminPage();
		// rc.navigateToRolesPage();
		rc.searchRole(roleName);//firstName
	}

	@And("User adds role owner details")
	public void addOwnerDetails() throws Exception {

		rc.editRole();
		rc.updateRolesWithOwner(roleName, roleOwner,"add");

	}

	@And("User rejects request for version created")
	public void rejectsRequest() throws Exception {
		log.info("User rejects request");
		rc.rejectRequest();
	}
	@And("User navigates to role updated with provided details")
	public void rolesWithOwnerDetails() throws Exception {
		log.info("Role with Onwer Details ");
		rc.searchRole(roleName);
		rc.editRole();

	}
	@And("User verifies that role is not updated with provided owner details")
	public void validateRolesOwnerDetaialsRejection() throws Exception {
		log.info(" Verify Role Onwer Details ");
		rc.validateRoleOwnerUpdate(roleOwner,"add","reject");
	}

	@And("User verifies if role is updated with provided owner details")
	public void validateRolesOwnerDetailsApproval() throws Exception {
		log.info(" Verify Role Onwer Details ");
		rc.validateRoleOwnerUpdate(roleOwner,"add","approve");
	}
	@And("User removes role owner details")
	public void removesOwnerDetails() throws Exception {

		rc.editRole();
		rc.updateRolesWithOwner(roleName, roleOwner,"Removal");

	}

	@And("User verifies that role owner is not removed")
	public void validateRolesOwnerRemovalRejection() throws Exception {
		log.info(" Verify Role Onwer Details ");
		rc.validateRoleOwnerUpdate(roleOwner,"remove","reject");
	}

	@And("User verifies that role owner is removed")
	public void validateRolesOwnerRemovalApproval() throws Exception {
		log.info(" Verify Role Onwer Details ");
		rc.validateRoleOwnerUpdate(roleOwner,"remove","approve");
	}
	@And("User adds Entitlement details to role")
	public void updateRolesWithEntitlementDetails() throws Exception {
		rc.editRole();
		log.info("Update Existing Role with Entitlement Details ");
		rc.updateRolesWithEntitlement(roleName, roleEntitlementName);
	}

	@Given("Role Modification User navigates to role to be updated with Entitlement details")
	public void updateRoleWithEntitlementDetails() throws Exception {
		log.info("Update Existing Role with Entitlement Details ");
		// ap.navigateToAdminPage();
		// rc.navigateToRolesPage();
		//rc.searchRole(Role1);
		rc.updateRolesWithEntitlement(roleName, roleEntitlementName);
	}
	@And("User verifies that role is not updated with provided Entitlement details")
	public void validateEntitlementDetailsUpdate() throws Exception {
		log.info(" Verify Role Onwer Details ");
		rc.validateEntitlementUpdate(roleEntitlementName, "add","reject");
	}

	@And("User verifies that role is updated with provided Entitlement details")
	public void validateEntitlementDetails() throws Exception {
		log.info(" Verify Role Onwer Details ");
		rc.validateEntitlementUpdate(roleEntitlementName, "add","approve");
	}

	@And("User removes Entitlement details to role")
	public void removeEntitlementDetails() throws Exception {
		log.info("Update Existing Role with Entitlement Details ");
		rc.editRole();
		rc.removeEntitlement(roleEntitlementName);
	}
	@And("User verifies that Entitlement is not removed")
	public void validateEntitlementisNotRemoved() throws Exception {
		log.info(" Verify Entitlement Details ");
		rc.validateEntitlementUpdate(roleEntitlementName, "Removal","reject");
	}

	@And("User verifies that Entitlement is removed")
	public void validateEntitlementisRemoved() throws Exception {
		log.info(" Verify Entitlement Details ");
		rc.validateEntitlementUpdate(roleEntitlementName, "Removal","approve");
	}
	@And("User adds provided group details to role")
	public void updateRolesWithGroupDetails() throws Exception {
		log.info("Update Existing Role with child role Details ");
		rc.editRole();
		rc.updateRolesWithGroup("Child Role");
	}

	@And("User verifies if role is updated with provided group details")
	public void validateChildRoleDetails() throws Exception {
		log.info(" Verify child role Details ");
		rc.validateChildRoleUpdate("Child Role", "add","approve");

	}
	@And("User verifies if role is not updated with provided group details")
	public void validateChildRoleDetailsNotUpdated() throws Exception {
		log.info(" Verify child role Details ");
		rc.validateChildRoleUpdate("Child Role", "add","reject");
	}
	@And("User removes provided group details to role")
	public void removeGroupDetails() throws Exception {
		log.info("Update Existing Role with  child role Details  ");
		rc.editRole();
		rc.removeGroup("Child Role");
	}

	@And("User verifies that child role is not removed from role")
	public void validateChildRoleRemovalRejection() throws Exception {
		log.info(" Verify child role Details ");
		rc.validateChildRoleUpdate("Child Role", "Removal","reject");

	}
	@And("User verifies that child role is removed from role")
	public void validateChildRoleRemoval() throws Exception {
		log.info(" Verify child role Details ");
		rc.validateChildRoleUpdate("Child Role", "Removal","approve");

	}

	@And("User requests access for required role and Validates if  access request for role is created")
	public void User_RequestAccess_for_Role() throws AWTException, InterruptedException, FileNotFoundException {
		log.info("Requesting Access for Role");
		Thread.sleep(1000);
		highLightElement(driver, driver.findElement(By.xpath(" //*[text()='Manage Access For Team']")));
		/**
		 * Searching user to request for access 
		 */
		log.info("roleAccessToUser:"+roleAccessToUser);
		wf.searchUserToRequestAccess(roleAccessToUser);
		String RequestIdFetch = rc.searchEndpointToRequestAccessForRole(roleToRequestAccess);
		String[] splited = RequestIdFetch.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[text()='Request History']")).click();
		log.info("User is on Request History page");
		log.info("Navigating to pending approvals page");
		
	}

	@Then("User Validates if role access is Provisioned")
	public void user_validates_if_role_acceses_is_provisioned()
			throws AWTException, InterruptedException, FileNotFoundException {
		uc.searchUser(roleAccessToUser);
		rc.validateRoleAccess(roleAccessToUser, roleToRequestAccess);

	}

	@Given("User navigates to role to be deactivated")
	public void removeRole() throws Exception {
		log.info("User navigates to role to be deactivated");
		rc.searchRole(role3);
	}
	@Given("User deletes the role")
	public void deleteRole() throws Exception {
		log.info("removing role ");
		rc.removeRole();
	}
	@And("User verifies if role is deactivated successfully")
	public void ValidateRoleRemoval() throws Exception {
		log.info("Role with Onwer Details ");
		rc.searchRole(role3+"_deleted");
		rc.validateRoleDeactivation();
	}

	@And("Validates the message when user tries to create user with already existing name")
	public void provideAlreadyExistingName() throws InterruptedException {
		log.info("User details provided");
		ap.provideExistingUserDetails("testusername107", lastName, email);

	}

	@And("Validates the message when user tries to provide end date lesser than current date")
	public void provideEndDateDetails() throws InterruptedException {
		log.info("User details provided");
		ap.provideEndDateDetails(firstName, lastName);

	}
	@And("User search for request id created for new account")
	public void searchUserRequestId() throws Exception {
		log.info("User searching request");
		String rid = AdminPage.reqId;//rc.searchRequestId();
		log.info(rid);
		wf.searchRequestId(rid);
	}
	@And("User approves request created for new account")
	public void approveNewRequest() throws Exception {
		log.info("User appproves request");
		uc.approveRequest();
	}

	@Given("User Provides empty csv file without any user details")
	public void emptyCSVFileWithoutUserDetails() throws Exception {
		log.info("Providing Empty .CSV file as input to upload user page ");
		selectFile.selectCSVWithDetails("UsersNoRecords.csv");
		uc.uploadUserRequestForEmptyFile();
	}

	@Then("User Validates if add access account pending task is created")
	public void user_validates_if_add_access_account_pending_task_is_created()
			throws AWTException, InterruptedException, FileNotFoundException {
		// apps.navigateToHomePage();
		log.info("Validating if disable account pending task is created");
				leaveStatus.validatePendingTask1(roleAccessToUser);
	}
	
	@And("User validates Role owner certification")
	public void user_validates_Roleowner_certification() throws InterruptedException, FileNotFoundException {
		log.info("Navigating to Certification Page");
		// cp.validateCertificationPage();
		//cp.validateCertificationPage();
		log.info("User validates certification");
		cp.searchRole("Enterprise Role9");
		/*cp.searchRole("Enterprise Role9");
		cp.selectStatusOfRole("Enterprise Role9");
		cp. navigateToUsers();
		cp.validateRoleOwnerCertification("testusername1");*/
		Scanner scan = new Scanner(new File(System.getProperty("user.dir") + "//src//test//resources//TestData//RoleOwnerCertificationUsers.csv"));
		ArrayList<String[]> records = new ArrayList<String[]>();
		String[] record = new String[10];
		while (scan.hasNext()) {
			record = scan.nextLine().split(",");
			records.add(record);
			log.info("records " + record[0] + " , " + record[1]);
			if (!record[0].equalsIgnoreCase("RoleName")&& !record[1].equalsIgnoreCase("RoleStatus") && !record[2].equalsIgnoreCase("UsersToCertify")&& !record[3].equalsIgnoreCase("UsersToReject")
					 && !record[4].equalsIgnoreCase("AssociatedEntitlement")) {
				log.info("searching Role " + record[0]);
				cp.searchRole(record[0]);
				cp.selectStatusOfRole(record[1]);
				cp. navigateToUsers();
				cp.validateUsersRoleAccess(record[2], record[3]);
				cp.validateAssociatedEntitlement(record[4]);
			}
		}

	}


}