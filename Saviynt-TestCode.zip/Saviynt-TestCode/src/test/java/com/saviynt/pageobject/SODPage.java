package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mortbay.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.junit.Assert;

public class SODPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();
	public static String requestID = "";
	public SODPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
////Element Repository with element locators////
	@FindBy(xpath = "//button[@title='Applications']")
	public WebElement app;
	@FindBy(xpath = "//*[@class='buttonAlignmt']")
	public WebElement selectFile;
	@FindBy(xpath = "//label[1]//ins[@class='iCheck-helper']")
	public List<WebElement> yesRadioBtn;
	@FindBy(xpath = "//*[@class='btn blue']")
	public WebElement upload;
	@FindBy(xpath = "//div[@id='userImportTable']//th")
	public List<WebElement> header;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement searchDropdwn;
	@FindBy(xpath = "//*[@id='importBtn']/a[1]")
	public WebElement importBtn;
	@FindBy(xpath = "//div[text()='SOD']")
	public WebElement sodTab;
	@FindBy(xpath = "//*[@class='col-md-12']//h3")
	public WebElement sobPageTitle;
	@FindBy(xpath = "//*[@class='col-md-12']//h3")
	public WebElement sobControlPageTitle;
	@FindBy(xpath = "//*[@id='myTab']//li[6]//a")
	public WebElement sobJobLink;
	@FindBy(xpath = "//*[@class='select2-container form-control input-xsmall']//span[2]")
	public WebElement showListOnSODViolationPage;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement showListTextFieldOnSODViolationPage;

	@FindBy(xpath = "//*[@id='accordion5_null']//div[3]//div[1]//h4")
	public WebElement riskSODEvaluationJob;
	@FindBy(xpath = "//*[@class='btn-group pull-right']")
	public WebElement riskSODEvaluationJobAction;
	@FindBy(xpath = "//*[@id='gritter-without-image2']")
	public WebElement riskSODEvaluationJobStart;
	@FindBy(xpath = "//*[@id='s2id_secsystemkey']")
	public WebElement systemDropDownOnEnterDetailsPage;
	@FindBy(xpath = "//*[@id='select2-drop']//input")
	public WebElement systemDropDownSearchOnEnterDetailsPage;
	@FindBy(xpath = "//*[@id='filebutt']")
	public WebElement jobSubmitButton;
	@FindBy(xpath = "//*[@id='select2-drop']//span[text()='STA Disconnected']")
	public WebElement systemDropDownSelectedOnEnterDetailsPage;

	@FindBy(xpath = "//*[@class='btn dark btn-default']//span")
	public WebElement openSODViolationCount;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement userCount;
	@FindBy(xpath = "//div[@class='tsk-success']")
	public WebElement pendingTaskType;
	@FindBy(xpath = "//a[@id='arsPendingTaskAction']")
	public WebElement pendingTaskAction;
	@FindBy(xpath = "//a[@id='completeSelectedTask']")
	public WebElement completeSelectedTask;
	@FindBy(xpath = "//a[@class='btn btn-xs default']")
	public WebElement taskactions;
	@FindBy(xpath = "//*[@class='dropdown-menu']//li[3]")
	public WebElement complete;
	@FindBy(xpath = "//*[@class='modal-title' and text()='Comments']")
	public WebElement completeTaskPopUp;
	@FindBy(xpath = "//*[@id='coments']")
	public WebElement comments;
	@FindBy(xpath = "//button[@id='yui-gen0-button']")
	public WebElement submit;
	@FindBy(xpath = "//*[@class='control-label col-md-12']")
	public WebElement countOfTasksMessageOnCommentsTab;
	@FindBy(xpath = "//*[@class='control-label col-md-12']//input")
	public WebElement countOfTasksMessageOnCommentsTabCheckBox;

	@FindBy(xpath = "//a[@class='tooltip1']")
	public WebElement userLink;
	@FindBy(xpath = "//a[contains(text(),'Accounts')]")
	public WebElement accountsTab;
	@FindBy(id = "dtsearch_SODMapped")
	public WebElement search_user;
	@FindBy(xpath = "//*[@id='search_SODMapped']//i")
	public WebElement searchButton;
	@FindBy(xpath = "//span[text()='Add New Access']")
	public WebElement addNewAccess;
	@FindBy(xpath = "//input[@id='outlined-adornment-password']")
	public WebElement appSearchBox;
	@FindBy(xpath = "//*[text()='Request New Account']")
	public WebElement requestNewAccess;
	@FindBy(xpath = "//*[@class='row']//input")
	public WebElement accountNameInputTextField;
	@FindBy(xpath = "//*[@id='panel1a-header']//span[text()='Add']")
	public WebElement addEntitlementOption;
	@FindBy(xpath = "//*[@class='entitlement-list']//input")
	public WebElement searchEntitlement;
	@FindBy(xpath = "//*[@class='divTableCell add']//button")
	public WebElement addEntitlementButton;
	@FindBy(xpath = "(//*[@class='MuiButton-label' or text()='Done'])[4]")
	public WebElement doneButton;
	@FindBy(xpath = "//*[@class='divTableHead customCheck']//input")
	public WebElement selectAllCheckBox;

	@FindBy(xpath = "//*[text()='Select Access']")
	public WebElement selectAccess;
	@FindBy(xpath = "//*[text()='Modify Access']")
	public WebElement modifyAccessPageTitle;
	@FindBy(xpath = "//*[@id='modify-account-name']")
	public WebElement accountName1;
	@FindBy(xpath = "//*[text()='Review & Submit']")
	public WebElement reviewAndSubmit;
	@FindBy(xpath = "//*[text()='Review']")
	public WebElement reviewHeader;
	@FindBy(xpath = "//*[@class='MuiIconButton-label']//input")
	public WebElement checkBox;
	@FindBy(xpath = "//span[text()='Submit']")
	public WebElement submitFinal;
	@FindBy(xpath = "//*[text()='Request Approvals']")
	public WebElement requestApproval;
	@FindBy(xpath = "//h5[@class='mt-3']")
	public WebElement requestConfirmationMessage;
	@FindBy(xpath = "//*[text()='Request History']")
	public WebElement requestHistoryLink;
	@FindBy(xpath = "//*[text()='Approve']")
	public WebElement approve;
	@FindBy(xpath = "//*[@class='defaultApproveIcon ']")
	public WebElement approveEntitlement;
	@FindBy(xpath = "//*[@class='RequestedEndpoint_headerText__1lBk7']")
	public WebElement countOfEntitlement;
	@FindBy(xpath = "//*[@class='RequestedEndpoint_selectEnt__3mIAY']")
	public WebElement selectAllEntitlement;
	@FindBy(xpath = "(//*[@class='RequestedEndpoint_snackbarapprovetext___MD4v'])[1]")
	public WebElement entitlementSelectedConfirmation;

	@FindBy(xpath = "//span[text()='Confirm']")
	public WebElement confirm;
	@FindBy(xpath = "//input[@id='Business Justification']")
	public WebElement businessJustification;
	@FindBy(xpath = "//*[@class='ant-upload']//textarea")
	public WebElement commentsFinalApproval;

	@FindBy(xpath = "//span[text()='Final Confirmation']")
	public WebElement finalConfirmation;
	@FindBy(xpath = "//*[@class='discontinue-subtitle approvereject']")
	public WebElement successMessage;
	@FindBy(xpath = "//span[text()='Back to All Request Approvals']")
	public WebElement backToRequestHistory;
	@FindBy(xpath = "//*[@class='btnbox']//span[text()='Modify']")
	public WebElement modifyAccess;
	@FindBy(xpath = "//*[@class='container']//h5[text()='STA Disconnected']")
	public WebElement modifyAccessTitle;
	@FindBy(xpath = "(//*[@id='root']//span[2])[1]")
	public WebElement countOfRecordForUserPendingApproval;
	@FindBy(xpath = "//*[contains(@class,'MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary') and contains(@tabindex,'2')]")
	public WebElement view;
	@FindBy(xpath = "//input[@type='text']")
	public WebElement searchFieldPendingApproval;
	@FindBy(xpath = "(//*[@class='MuiButton-label' and text()='Add'])[1]")
	public WebElement addSTAEntitlement;
	@FindBy(xpath = "//*[@class='entitlement-list']//input")
	public WebElement searchUnderSTAEntitlement;
	@FindBy(xpath = "//*[@class='divTableCell add']//button")
	public WebElement addSelectedSTAEntitlement;
	@FindBy(xpath = "//*[@class='MuiButton-label' and text()='Done'] ")
	public WebElement doneSearchEntitlementPage;

	///////mitigate SOD///////////
	@FindBy(xpath = "//*[text()='Mitigate SOD']")
	public WebElement mitigateSOD;
	@FindBy(xpath = "//*[@class='carousal_title']//span")
	public WebElement countOfViolations;
	@FindBy(xpath = "//*[@class='carousal-item-container']")
	public WebElement countOfViolationsContainer;
	@FindBy(xpath = "//*[@class='MuiButtonBase-root MuiIconButton-root']")
	public WebElement closeRequestApproval;

	/** 
	     * This method is to navigate to SOD page
	    
	     */

	public void navigateToSODPage() throws AWTException, InterruptedException {
		try {
			Thread.sleep(1000);
			app.click();
			Thread.sleep(3000);
			sodTab.click();
			Thread.sleep(4000);
			log.info("Title of the page:" + sobPageTitle.getText());
			if (sobPageTitle.getText().contains("SOD Violations")) {
				log.info("Successfully Navigated to SOD Violation page");
				Thread.sleep(1000);
				selectShow100OnSODViolationPage();
				Thread.sleep(3000);
			}

			else
				log.info("Failed to Navigate to SOD Violation page");
		} catch (NoSuchElementException e) {
			log.info("Element not found");

		}

	}

	/** 
	     * This method is to select 100 SOD violations page
	     */
	public void selectShow100OnSODViolationPage() throws InterruptedException {

		try {
			log.info("Select show 100 entries on SOD Violation page");
			Thread.sleep(3000);
			showListOnSODViolationPage.click();
			showListTextFieldOnSODViolationPage.sendKeys("100");
			Robot rb;
			rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {

			e.printStackTrace();
			log.info(e);
			// Assert.fail("Select Show All ON SOD Violation Selection to 100 entries has
			// failed");
		}

	}

	/** 
	     * This method is to execute SOD violation job
	     * @param securitySystem
	     */
	public void executeSODViolationJob(String securitySystem) throws AWTException, InterruptedException {
		try {
			Thread.sleep(2000);
			if (sobControlPageTitle.getText().contains(" Job Control Panel"))
				log.info("****Title of the page for Job execution****:" + sobControlPageTitle.getText());
			log.info("User is on Job Control page");
			Thread.sleep(1000);
			sobJobLink.click();
			Thread.sleep(1000);
			riskSODEvaluationJob.click();
			Thread.sleep(1000);
			riskSODEvaluationJobAction.click();
			riskSODEvaluationJobStart.click();
			Thread.sleep(1000);
			systemDropDownOnEnterDetailsPage.click();
			Thread.sleep(1000);
			systemDropDownSearchOnEnterDetailsPage.sendKeys(securitySystem);
			systemDropDownSelectedOnEnterDetailsPage.click();
			Thread.sleep(2000);
			jobSubmitButton.click();
			Thread.sleep(5000);

		} catch (NoSuchElementException e) {
			log.info("Element not found");
			// Assert.fail("Job Exection has failed " + "RiskSODEvaluationJob");

		}

	}

	/** 
	     * This method is to provide csv files with user details for SOD violations
	     */
	public void provideCSV() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(7000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\SODViolation.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	/** 
	     * This method is to provide csv files with user details for SOD Actioned
	     */
	public void provideCSVWhenSODActioned() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(7000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\SODViolationWhenSODActioned.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	/** 
	     * This method is to provide csv files with user details for preventive SOD violation
	     */
	public void provideCSVForPreventiveSODViolation() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(7000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\PreventiveSODViolation.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	/** 
	     * This method is to upload user request in upload user page in Saviynt
	     */
	public void uploadUserRequest() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();
		Thread.sleep(2000);
		yesRadioBtn.get(4).click();
		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);
		header.get(1).click();
		searchDropdwn.sendKeys("FIRSTNAME");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(2).click();
		searchDropdwn.sendKeys("LASTNAME");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(3).click();
		searchDropdwn.sendKeys("STATUSKEY");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		importBtn.click();
		Thread.sleep(2000);
		driver.navigate().refresh();

	}

	/** 
	     * This method is to validate account creation for SOD violations
	     */
	public void validateAccountCreationForSODViolation(String user, String securitySys)
			throws InterruptedException, AWTException {
		try {
			Thread.sleep(1000);
			log.info("********message********: " + userCount.getText());
			String entries = userCount.getText().substring(17);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			log.info("********ROWs*******" + rows);
			if (userCount.getText().contains("0 entries"))
				Assert.fail("No accounts are found for following user" + user);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,1000)");
			for (int i = 1; i <= rows; i++) {
				log.info(i);
				log.info("Before For loop");
				String secsys = driver.findElement(By.xpath("//*[@id='usersList']//tbody/tr[" + i + "]//td[9]"))
						.getText();
				log.info("Xpath of security system on Pending tasks tab:" + "//*[@id='usersList']//tbody/tr[" + i
						+ "]//td[9]");
				log.info("Name of security system: " + secsys);
				if (pendingTaskType.getText().contains("New Account") && secsys.contains(securitySys))
					log.info("pending task has been found for following user: " + user);
				else if (userCount.getText().contains("0 entries"))
					Assert.fail("No pending task found for following user" + user);

				/** 
				     * call Approve pending method
				     */
				approvePendingTask();
				break;

			}

		} catch (NoSuchElementException e) {
			// Assert.fail("Validate account creation has failed");
			log.info(e);

		}

		Thread.sleep(1000);
	}

	/** 
	     * This method to search user in pending approval page. 

	     **/


	public void searchUserPendingApprovalPage(String user) throws InterruptedException {
		try {
			Thread.sleep(4000);
			//driver.navigate().refresh();
			if (requestApproval.getText().contains("Request Approvals")) {
				Thread.sleep(4000);
				log.info("******Begining of Search******" + user);
				//driver.navigate().refresh();
				searchFieldPendingApproval.sendKeys(user);
				Thread.sleep(2000);
				log.info("****End of Search*******");
				Robot rb = new Robot();

				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				log.info("countOfRecordForUserPendingApproval" + countOfRecordForUserPendingApproval.getText());
				if (countOfRecordForUserPendingApproval.getText().contains("1")) {
					Thread.sleep(1000);
					if (view.getAttribute("innerHTML").contains("View")) {
						log.info("Clicking View Approval button");
						Thread.sleep(10000);
						view.click();
					}
				}
			}

			log.info("Search user has been completed successfully on Pending Approval Page");
		} catch (Exception e) {
			//Assert.fail("Search user has failed on Pending Approval Page" );
			log.info("Search user has failed on Pending Approval Page");

		}

	}


	public void validateNoPendingApprovalCreated(String user) throws InterruptedException {
		try {
			Thread.sleep(4000);

			if (requestApproval.getText().contains("Request Approvals")) {
				Thread.sleep(4000);
				log.info("******Begining of Search******" + user);
				searchFieldPendingApproval.sendKeys(user);
				log.info("****End of Search*******");
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				log.info("countOfRecordForUserPendingApproval" + countOfRecordForUserPendingApproval.getText());
				if (countOfRecordForUserPendingApproval.getText().contains(" 0 of 0")) {
					Thread.sleep(1000);
					log.info("Pending Approval is not created for the user: "+user);
				}
			}else {
				Assert.fail("Pending Approval is created for the user: "+user);
			}

		} catch (Exception e) {
			// Assert.fail("Search user has failed on Pending Approval Page");
			log.info("Search user has failed on Pending Approval Page");

		}

	}
	public void searchUserRequestHistoryPage(String requestID) throws InterruptedException {
		try {
			Thread.sleep(4000);

			if (requestHistoryLink.getText().contains("Request History")) {
				Thread.sleep(4000);
				log.info("******Begining of Search******" + requestID);
				//driver.navigate().refresh();
				searchFieldPendingApproval.sendKeys(requestID);
				log.info("****End of Search*******");
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(2000);
				log.info("countOfRecordForUserPendingApproval" + countOfRecordForUserPendingApproval.getText());
				if (!countOfRecordForUserPendingApproval.getText().contains("0")) {
					Thread.sleep(2000);
					if (view.getAttribute("innerHTML").contains("View")) {
						Thread.sleep(1000);
						log.info("Clicking View Approval button");
						Thread.sleep(10000);
						view.click();
						Thread.sleep(10000);
					}
				}
			}

			log.info("Search requestID has been completed successfully on Pending Approval Page");
		} catch (Exception e) {
			// Assert.fail("Search user has failed on Pending Approval Page");
			log.info("Search requestID has failed on Pending Approval Page");

		}

	}

	public void validateAccountCreationForPreventiveSODViolation(String user, String securitySys)
			throws InterruptedException, AWTException {
		try {
			Thread.sleep(1000);
			log.info("********message********: " + userCount.getText());
			String entries = userCount.getText().substring(17);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);
			if (userCount.getText().contains("0 entries"))
				Assert.fail("No accounts are found for following user" + user);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,1000)");
			for (int i = 1; i <= rows; i++) {
				log.info(i);
				log.info("Before For loop");
				String secsys = driver.findElement(By.xpath("//*[@id='usersList']//tbody/tr[" + i + "]//td[9]"))
						.getText();
				log.info("Xpath of security system on Pending tasks tab:" + "//*[@id='usersList']//tbody/tr[" + i
						+ "]//td[9]");
				log.info("Name of security system: " + secsys);
				if (pendingTaskType.getText().contains("New Account") && secsys.contains(securitySys))
					log.info("pending task has been found for following user: " + user);

				else if (userCount.getText().contains("0 entries"))
					Assert.fail("No pending task found for following user" + user);
				// log.info("Approve the pending taks of the user: " + user);
				approvePendingTaskForPreventiveSODViolation();
				break;

			}

		} catch (NoSuchElementException e) {
			// Assert.fail("Validate account creation has failed");
			log.info(e);

		}

		Thread.sleep(1000);
	}

	/** 
	     * This method is to approve pending task as Admin
	     */
	public void approvePendingTask() throws InterruptedException, AWTException {

		try {
			log.info("Approving pending Task");
			taskactions.click();
			Thread.sleep(1000);
			System.out.println("*****Before clicking on complete task*******");
			complete.click();
			System.out.println("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			if (completeTaskPopUp.getText().contains("Comments")) {
				Thread.sleep(5000);
				log.info("adding comments");
				comments.sendKeys("for test automation");
				log.info("added comments");
			}
			log.info("countOfTasksMessageOnCommentsTab: " + countOfTasksMessageOnCommentsTab.getText());
			if (countOfTasksMessageOnCommentsTab.isDisplayed() && countOfTasksMessageOnCommentsTab.getText()
					.contains("There are 2more task with this request. Would you like to include all of them?")) {
				countOfTasksMessageOnCommentsTabCheckBox.click();
			}
			Thread.sleep(1000);
			submit.click();
			log.info("selected pending Task has been approved successfully");
			Thread.sleep(15000);

		} catch (Exception e) {

			// Assert.fail("Pending Tasks hasn't been approved");
			log.info(e);
		}

	}

	/** 
	     * This method is to approve pending task for preventive SOD violation
	     */
	public void approvePendingTaskForPreventiveSODViolation() throws InterruptedException, AWTException {

		try {
			log.info("Approving pending Task");
			taskactions.click();
			Thread.sleep(1000);
			System.out.println("*****Before clicking on complete task*******");
			complete.click();
			System.out.println("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			if (completeTaskPopUp.getText().contains("Comments")) {
				Thread.sleep(5000);
				log.info("adding comments");
				comments.sendKeys("for test automation");
				log.info("added comments");
			}
			log.info("countOfTasksMessageOnCommentsTab: " + countOfTasksMessageOnCommentsTab.getText());
			if (countOfTasksMessageOnCommentsTab.isDisplayed() && countOfTasksMessageOnCommentsTab.getText()
					.contains("There are 1more task with this request. Would you like to include all of them?")) {
				Thread.sleep(1000);
				countOfTasksMessageOnCommentsTabCheckBox.click();
			}
			Thread.sleep(1000);
			submit.click();
			log.info("selected pending Task has been approved successfully");
			Thread.sleep(15000);

		} catch (Exception e) {

			// Assert.fail("Pending Tasks hasn't been approved");
			log.info(e);
		}

	}

	/** 
	     * This method is to validate User Account creation for the Target System
	     */
	public void validateAccountCreation(String user, String securitySys) throws InterruptedException {
		try {

			userLink.click();
			accountsTab.click();
			Thread.sleep(3000);
			if (driver.findElement(By.xpath("//*[text()='" + securitySys + "']")).getText().contains(securitySys))
				log.info("New Account has been successfully for the user: " + user + " And to the security system: "
						+ securitySys);
			else if (userCount.getText().contains("0 entries"))
				Assert.fail("New Account hasn't been successfully for the user: " + user
						+ " And to the security system: " + securitySys);
			// log.info("Approve the pending tasks of the user: " + user);
			// secSys.getText();
		} catch (NoSuchElementException e) {
			Assert.fail("Validate account creation has failed");

		}

		Thread.sleep(1000);
	}

	/** 
	     * This method is to search user
	     */
	public void searchUser(String user) throws InterruptedException {
		try {
			search_user.clear();
			search_user.sendKeys(user);
			Thread.sleep(1000);
			searchButton.click();
			Thread.sleep(2000);

			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}

	/** 
	     * This method is to validate SOD violation creation
	     */
	public void validateViolationCreation(String user, String securitySys) throws InterruptedException {
		try {

			if (driver.findElement(By.xpath("//*[@id='SODMapped']//tbody//td[9]")).getText().contains(securitySys))
				log.info("SOD Violation has been successfully Created For The user: " + user
						+ " and for the End Point: " + securitySys);
			else if (userCount.getText().contains("0 entries"))
				Assert.fail("SOD Violation hasn't been Created For The user: " + user + " And to the security system: "
						+ securitySys);

		} catch (NoSuchElementException e) {
			// Assert.fail("SOD Violation Creation has failed");
			log.info("SOD Violation Validation has failed");

		}

		Thread.sleep(1000);
	}

	/** 
		     * This method is to validate SOD violation creation after SOD job is executed second time
		     */
	public void validateViolationCreationAfterJOBRunSecondTimeForSameUser(String user, String securitySys)
			throws InterruptedException {
		try {

			/*
			 * if
			 * (driver.findElement(By.xpath("//*[@id='SODMapped']//tbody//td[9]")).getText()
			 * .contains(securitySys))
			 * log.info("SOD Violation has been successfully Created For The user: " + user
			 * + " and for the End Point: " + securitySys);
			 */
			log.info("User Count on SOD Violation Page: " + userCount.getText());
			if (userCount.getText().contains("2 entries")) {
				Assert.fail("SOD Violation is Created For The Same User twice when the JOB is triggerd second time: "
						+ user + " And to the security system: " + securitySys);
			}
			if (userCount.getText().contains("1 entries")) {
				log.info("SOD Violation is not Created For The Same User twice when the JOB is triggerd second time: "
						+ user + " And to the security system: " + securitySys);
			}
			if (userCount.getText().contains("0 entries")) {
				Assert.fail("No SOD Violation is found when the JOB is triggerd second time: " + user
						+ " And to the security system: " + securitySys);
			}

		} catch (NoSuchElementException e) {
			// Assert.fail("SOD Violation Creation has failed");
			log.info("SOD Violation Validation has failed");

		}

		Thread.sleep(1000);
	}

	/** 
		     * This method is to search the end point and create an access request for the same
		     */
	public void searchEndpointToRequestAccess(String securitySys,String entitlement1, String entitlement2, String userAccountName)
			throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			Thread.sleep(2000);
			log.info("before Search by security system: " + securitySys);
			appSearchBox.sendKeys(securitySys);
			log.info("after Search by security system: " + securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase("STA Disconnected")) {
					links.get(j).click();
					Thread.sleep(1000);
					Thread.sleep(2000);
					requestNewAccess.click();
					Thread.sleep(2000);
					accountNameInputTextField.clear();
					log.info("Before Entering the account Name");
					Thread.sleep(2000);
					accountNameInputTextField.sendKeys(userAccountName);
					log.info("After Entering the account Name");
					Thread.sleep(4000);
					//}
					// Add STA Entitlement
					log.info("Add STA entitlement");
					addSTAEntitlement.click();
					Thread.sleep(2000);
					searchUnderSTAEntitlement.sendKeys(entitlement1);
					Thread.sleep(2000);
					addSelectedSTAEntitlement.click();
					Thread.sleep(1000);
					searchUnderSTAEntitlement.clear();
					Thread.sleep(2000);
					searchUnderSTAEntitlement.sendKeys(entitlement2);
					Thread.sleep(4000);
					addSelectedSTAEntitlement.click();
					Thread.sleep(2000);
					doneSearchEntitlementPage.click();
					Thread.sleep(2000);
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						reviewAndSubmit.click();
						Thread.sleep(2000);
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							submitFinal.click();
							log.info("User submits the access request with all details");
							Thread.sleep(5000);
							if (requestConfirmationMessage.getText().contains("Confirmation")) {
								log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
								log.info("Request New access for the user is completed: " + securitySys);
								Thread.sleep(1000);

							}

						}
					}
				}

			}

		} catch (Exception e) {
			Assert.fail("Creation of New Request failed ");

		}
		String requestDetails = requestConfirmationMessage.getText();
		String[] splitedRequestId = requestDetails.split("\\s+");
		requestID = splitedRequestId[1];
		log.info("Request ID created for Access Request:" + requestID);

	}

	/** 
	     * This method is to search the end point and create an access request for an entitlement with associate entitlement
	     */
	public String searchEndpointToRequestAccessForEntitlementWithAssociateEntitlemnt(String entitlement, String securitySys)
			throws InterruptedException {
		try {
			log.info("New access Request for entitlement having associate entitlement for the user ");
			// addNewAccess.click();
			Thread.sleep(2000);
			appSearchBox.sendKeys(securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(securitySys)) {
					links.get(j).click();
					Thread.sleep(1000);
					requestNewAccess.click();

					log.info("Adding the user to Entitlements");
					Thread.sleep(4000);
					addEntitlementOption.click();
					searchEntitlement.clear();
					searchEntitlement.sendKeys(entitlement);
					Thread.sleep(2000);
					addEntitlementButton.click();
					Thread.sleep(2000);
					doneButton.click();
					Thread.sleep(3000);
					log.info("********Scroll Begins******");
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript("window.scrollBy(0,5000)", "");
					// js.executeScript("arguments[0].scrollIntoView();", selectAllCheckBox);
					log.info("********Scroll End******");
					selectAllCheckBox.click();
					Thread.sleep(2000);
					log.info("Validate if both the Entitlment are added");
					if (driver.findElement(By.xpath("//*[@class='MuiSnackbarContent-message']//div[1]")).getText()
							.contains("2")) {
						log.info("Both Entitlement" + entitlement  + "added successfully");
					}

					// System.out.println("Select access "+selectAccess.getText());
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						reviewAndSubmit.click();
						Thread.sleep(1000);
						// System.out.println("Review Header"+reviewHeader.getText());
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							submitFinal.click();
							log.info("User submits the access request with all details");
							Thread.sleep(5000);

							if (requestConfirmationMessage.getText().contains("Confirmation")) {
								log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
								log.info("Request New access for the user is completed: " + securitySys);

							}

						}
					}

				}

			}

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestIdDetails = requestConfirmationMessage.getText();
		return requestIdDetails;

	}

	/** 
	     * This method is to search the end point and create an access request for an inactive entitlement  */
	public String searchEndpointToRequestAccessForInactiveEntitlement(String entitlement,String securitySys)
			throws InterruptedException {
		try {
			log.info("New access Request for Inactive Entitlement");
			// addNewAccess.click();
			Thread.sleep(2000);
			appSearchBox.sendKeys(securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(securitySys)) {
					links.get(j).click();
					Thread.sleep(1000);
					requestNewAccess.click();
					log.info("Adding the user to Entitlements");
					Thread.sleep(4000);
					addEntitlementOption.click();
					searchEntitlement.clear();
					searchEntitlement.sendKeys(entitlement);
					Thread.sleep(2000);
				}

			} 

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestIdDetails = requestConfirmationMessage.getText();
		return requestIdDetails;

	}

	/** 
	     * This method is to search the end point and create an access request for preventive SOD violation
	     */
	public String searchEndpointToRequestAccessForPreventiveViolation(String entitlement1, String entitlement2,
			String securitySys) throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			addNewAccess.click();
			Thread.sleep(2000);
			appSearchBox.sendKeys(securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(securitySys)) {
					links.get(j).click();
					Thread.sleep(1000);
					requestNewAccess.click();

					log.info("Adding the user to Entitlements");
					Thread.sleep(4000);
					addEntitlementOption.click();
					searchEntitlement.clear();
					searchEntitlement.sendKeys(entitlement1);
					Thread.sleep(2000);
					addEntitlementButton.click();
					doneButton.click();
					Thread.sleep(3000);
					log.info("********Scroll Begins******");
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript("window.scrollBy(0,5000)", "");
					log.info("********Scroll End******");
					selectAllCheckBox.click();
					Thread.sleep(2000);
					log.info("Validate if the Entitlment is added");
					if (driver.findElement(By.xpath("//*[@class='MuiSnackbarContent-message']//div[1]")).getText()
							.contains("1")) {
						log.info("Entitlement" + entitlement1 + "added successfully");
					}

					// System.out.println("Select access "+selectAccess.getText());
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						reviewAndSubmit.click();
						Thread.sleep(1000);
						// System.out.println("Review Header"+reviewHeader.getText());
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							submitFinal.click();
							log.info("User submits the access request with all details");
							Thread.sleep(5000);

							if (requestConfirmationMessage.getText().contains("Confirmation")) {
								log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
								log.info("Request New access for the user is completed: " + securitySys);

							}
						}
					}

				}

			}

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestIdDetails = requestConfirmationMessage.getText();
		return requestIdDetails;

	}

	/** 
	     * This method is to search the end point and create an access request for second entitlement with preventive SOD violation
	     */
	public void searchEndpointToRequestAccessForSecondEntitlementPreventiveViolation(String entitlement1,
			String entitlement2, String securitySys) throws InterruptedException {
		try {
			log.info("Update an Existing Request to add Second Entitlement");
			modifyAccess.click();
			Thread.sleep(2000);
			if (modifyAccessTitle.getText().contains(securitySys))
				log.info("Adding the user to second Entitlement");
			Thread.sleep(4000);
			addEntitlementOption.click();
			searchEntitlement.clear();
			searchEntitlement.sendKeys(entitlement2);
			Thread.sleep(2000);
			addEntitlementButton.click();
			Thread.sleep(2000);
			doneButton.click();
			Thread.sleep(3000);
			log.info("********Scroll Begins******");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,5000)", "");
			// js.executeScript("arguments[0].scrollIntoView();", selectAllCheckBox);
			log.info("********Scroll End******");
			selectAllCheckBox.click();
			Thread.sleep(2000);
			log.info("Validate if the Entitlment is added");
			if (driver.findElement(By.xpath("//*[@class='MuiSnackbarContent-message']//div[1]")).getText()
					.contains("1")) {
				log.info("Entitlement" + entitlement2 + "added successfully");
			}

			// System.out.println("Select access "+selectAccess.getText());
			if (modifyAccessPageTitle.getText().contains("Modify Access")) {
				log.info("User is on the Modify Access page with details of end points");
				reviewAndSubmit.click();
				Thread.sleep(1000);
				// System.out.println("Review Header"+reviewHeader.getText());
				if (reviewHeader.getText().contains("Review")) {
					log.info("User is on the Review page with details of end points");
					Thread.sleep(1000);
					checkBox.click();
					Thread.sleep(1000);
					log.info("User submits the access request with all details");
					submitFinal.click();
					Thread.sleep(5000);

					if (requestConfirmationMessage.getText().contains("Confirmation")) {
						log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
						Assert.fail("Request New access for the user is completed: " + securitySys);

					}

				}
			}

		} catch (Exception e) {
			log.error("Modification of Existing Request failed ");

		}

	}

	/** 
	     * This method is to approve request
	     */
	public void approveRequest() throws InterruptedException {
		try {
			Thread.sleep(1000);
			log.info("Approve the New account Access Request");
			approve.click();
			if (countOfEntitlement.getText().contains("2")) {
				log.info("There are two entitments for Approval");
				selectAllEntitlement.click();
				log.info("Confirm the Approval for both the Entitlements");
				entitlementSelectedConfirmation.click();
				log.info("Confirmed the Approval for both the Entitlements");

			}

			confirm.click();
			businessJustification.sendKeys("for test automation");
			Thread.sleep(1000);
			commentsFinalApproval.sendKeys("for test automation");
			finalConfirmation.click();
			Thread.sleep(3000);
			successMessage.getText();
			if (successMessage.getText().contains("1 items approved and 0 items rejected.")) {
				log.info("Final approval is successful");
			}
			backToRequestHistory.click();
			Thread.sleep(4000);
		} catch (Exception e) {
			Assert.fail("Final Approval of the New Access Request has failed");

		}
	}

	/** 
	     * This method is to pending approval request for preventive SOD violation
	     */
	public void approveRequestForPreventiveSODViolation() throws InterruptedException {
		try {

			Thread.sleep(1000);
			log.info("Approve the New account Access Request");
			approve.click();
			if (countOfEntitlement.getText().contains("1")) {
				log.info("There are one entitments for Approval");
				selectAllEntitlement.click();
				log.info("Confirm the Approval for both the Entitlements");
				entitlementSelectedConfirmation.click();
				log.info("Confirmed the Approval for both the Entitlements");

			}

			confirm.click();
			businessJustification.sendKeys("for test automation");
			Thread.sleep(1000);
			commentsFinalApproval.sendKeys("for test automation");
			finalConfirmation.click();
			Thread.sleep(3000);
			successMessage.getText();
			if (successMessage.getText().contains("1 items approved and 0 items rejected.")) {
				log.info("Final approval is successful");
			}
			backToRequestHistory.click();
			Thread.sleep(4000);
		} catch (Exception e) {
			Assert.fail("Final Approval of the New Access Request has failed");

		}
	}

	/** 
	     * This method is to Search by the request ID
	*/
	public void searchRequestId(String RequestIdFetch) throws InterruptedException {
		Thread.sleep(8000);

		try {

			if (requestApproval.getText().contains("Request Approvals")) {
				Thread.sleep(4000);
				searchFieldPendingApproval.sendKeys(RequestIdFetch);
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(2000);
				System.out.println("***Label***" + driver.findElement(By.xpath(
						"//*[@class='MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary']/.//span[contains(@class,'MuiButton-label')]"))
				.getAttribute("innerHTML"));

			}

		} catch (Exception e) {
			log.error("Request Id is not found");

		}
	}

	/** 
	     * This method is to validate preventive SOD violation
	     */
	public void validatePreventiveSOD(String entitment1ForSODViolation, String entitment2ForSODViolation ) throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(5000);
			if( mitigateSOD.isDisplayed()) {
				Thread.sleep(3000);
				mitigateSOD.click();
				if (countOfViolations.getText().contains("2")) {
					Thread.sleep(2000);
					List<WebElement> links = driver.findElements(By.xpath("//*[@class='function-name-layout']//div[2]"));
					int i = links.size();
					log.info("size:" +i);
					for (int j = 0; j < i; j++) {
						log.info("Violation Name:"+links.get(j).getText());
						if(links.get(j).getText().contains(entitment1ForSODViolation) || 
								links.get(j).getText().contains(entitment2ForSODViolation)) {
							log.info("Preventive SOD violation is created :"+links.get(j).getText());
						}else {
							Assert.fail("Preventive Violation is not created as Expected");
							//log.info("Preventive SOD Violation Creation has failed"+links.get(j).getText());
						}

					}
				}
			}
		}catch(Exception e) {
			log.info("Validation of SOD violation is failed");

		}
       // Click on close link on request approval page
		closeRequestApproval.click();
		Thread.sleep(5000);

	}
}
