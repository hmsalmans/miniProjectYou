package com.saviynt.pageobject;

import java.awt.AWTException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mortbay.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class AdminPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();
	public static String reqId="";
	public AdminPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

////	Element Repository with element locators////
	@FindBy(xpath = "//button[@title='Applications']")
	public WebElement app;
	@FindBy(xpath = "//div[text()='Admin']")
	public WebElement admin;
	@FindBy(xpath = "//span[text()='Admin']")
	public WebElement adminTitle;
	@FindBy(xpath = "//span[text() = 'Users']")
	public WebElement users;
	@FindBy(xpath = "//span[text() = 'Accounts']")
	public WebElement accounts;
	@FindBy(xpath = "//span[text() = 'Entitlements']")
	public WebElement entitlements;
	@FindBy(xpath = "//span[text() = 'Roles']")
	public WebElement roles;
	@FindBy(xpath = "//span[text() = 'User Groups']")
	public WebElement userGroups;

	@FindBy(xpath = "//span[text() = 'Security System']")
	public WebElement securitySystem;
	@FindBy(xpath = "//span[text() = 'Connections']")
	public WebElement connections;
	@FindBy(xpath = "//span[text() = 'Password Policies']")
	public WebElement passwordPolicies;
	@FindBy(xpath = "//span[text() = 'Organizations']")
	public WebElement organizations;
	@FindBy(xpath = "//span[text() = 'Dataset']")
	public WebElement dataset;
	@FindBy(xpath = "//span[text() = 'Job Control Panel']")
	public WebElement jobControlPanel;
	@FindBy(id = "dtsearch_usersList")
	public WebElement search_usersList;
	@FindBy(xpath = "//button[@class= 'btn default  searchButt']")
	public WebElement searchList;
	@FindBy(xpath = "//span[text() = 'Select Job Type']")
	public WebElement SelectJob;
	@FindBy(xpath = "//div[@class = 'select2-drop select2-display-none select2-with-searchbox select2-drop-active']//ul//li//div//span")
	public WebElement jobtypes;
	@FindBy(xpath = "//*[@class = 'MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@placeholder ='Search']")
	public WebElement search;
	@FindBy(xpath = "//*[@class='btn btn-primary']")
	public WebElement action;
	@FindBy(xpath = "//*[@class='icon-edit']")
	public WebElement createUser;
	@FindBy(xpath = "//*[@id=\"username\"]")
	public WebElement userN;
	@FindBy(xpath = "//*[@id=\"firstname\"]")
	public WebElement firstN;
	@FindBy(xpath = "//*[@id=\"lastname\"]")
	public WebElement lastN;
	@FindBy(xpath = "//*[@id=\"email\"]")
	public WebElement email;
	@FindBy(xpath = "//*[@class=\"btn green\"]")
	public WebElement create;
	@FindBy(xpath = "//*[@class='block'][2]")
	public WebElement requestCreationMessage;
	@FindBy(xpath = "//*[@class='page-title']")
	public WebElement UsersTitle;
	@FindBy(xpath = "//span[text()='Workflow List']")
	public WebElement workFlowList;
	@FindBy(xpath = "//span[text()='Workflow Approval']")
	public WebElement workFlowApproval;
	@FindBy(xpath = "//*[@id='dtsearch_flatViewJobControlDatatable']")
	public WebElement searchJob;
	@FindBy(xpath = "//*[@class='icon-search']")
	public WebElement clickSearchedJob;
	@FindBy(xpath = "//*[@class='icon-play svblue tooltips']")
	public WebElement runJob;
	///////////////////////end date valoidation////////////////////////////
	@FindBy(xpath = "//input[@id='enddate']")
	public WebElement endDate;
	@FindBy(xpath = "//input[@id='startdate']")
	public WebElement startDate;
	@FindBy(xpath = "//span[@id='enddateblank']")
	public WebElement endDateError;
	@FindBy(xpath = "//span[@id='startdateblank']")
	public WebElement startDateError;
	///////////////////////
	@FindBy(xpath = "//div[@class='bootbox-body']")
	public WebElement message;
	@FindBy(xpath = "//button[@class='btn default closebutton']")
	public WebElement close;
	////////////////////////////////////////
	@FindBy(xpath = "//a[contains(text(),'Attestation')]")
	public WebElement attestation;
	@FindBy(xpath = "//*[contains(text(),'Launch Certification from Rule Job')]")
	public WebElement job;
	@FindBy(xpath = "//a[contains(text(),'Action')]")
	public WebElement jobAction;
	@FindBy(xpath = "//*[@id='gritter-without-image2']")
	public WebElement start;
	@FindBy(xpath = "//span[text()='Manage My Access']")
	public WebElement manageMyAccess;
	
	/**
	 ** This method is to Navigate to Adming page.      
	 */
	public void navigateToAdminPage() throws AWTException, InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(4000);
		app.click();		
		Thread.sleep(3000);
		admin.click();
		Thread.sleep(2000);
		driver.navigate().refresh();
		Thread.sleep(4000);
		if (adminTitle.getText().contains("Admin"))
			log.info("User is on Admin Page");

		else
			Assert.fail("User is not able to navigate to Admin Page");

	}

	/**
	 ** This method is to Users page
	 */
	public void navigateToUsersPage() throws AWTException, InterruptedException {
		try {
			menu.click();
			search.sendKeys("Users");
			Thread.sleep(2000);
			users.click();
		}catch(Exception e) {

			Assert.fail("Navigation to User page has failed");

		}

	}
	
	/**
	 ** This method is to navigate to workFlow page     
	 */

	public void navigateToWorkFlowPage() throws AWTException, InterruptedException {

		menu.click();
		search.sendKeys("Workflow");
		Thread.sleep(2000);
		workFlowList.click();

	}
	
	/**
	 ** This method is to navigate to Security System tab
	    
	 */

	public void navigateToSecuritySystem() throws AWTException, InterruptedException {

		menu.click();
		search.sendKeys("Security System");
		Thread.sleep(2000);
		securitySystem.click();

	}

	/**
	 ** This method is to click on action button        
	 */

	public void clickAction() {
		try {
			Thread.sleep(1000);
			action.click();
		} catch (InterruptedException e) {

			log.info("Action Element not found");
		}

	}
	
	/**
	 ** This method is to click on create user button    
	 
	 */

	public void createUser() {
		try {
			Thread.sleep(1000);
			createUser.click();
		} catch (InterruptedException e) {

			log.info("createUser Element not found");
		}

	}

	/**
	 ** This method is to click on submit button
	*/
	public void submit() {

		try {
			create.click();
			Thread.sleep(15000);
			reqId=	driver.findElement(By.xpath("//tr[1]//td[1]")).getText().trim();
			log.info(reqId);
		} catch (InterruptedException e) {
			log.info("Subit user has failed");
		}
	}

	/**
	 ** This method is to provide user details
	 * * @param username
	 *  * @param firstname
	 *  * @param lastname
	 *  * @param  mailid
	 */
	public void provideUserDetails(String username, String firstName, String lastName, String mailid)
			throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(1000);
			userN.clear();
			userN.sendKeys(username);
			firstN.clear();
			firstN.sendKeys(firstName);
			lastN.clear();
			lastN.sendKeys(lastName);
			email.sendKeys(mailid);

		} catch (InterruptedException e1) {
			log.error("element is not found.");
			throw (e1);
		}

	}
	
	/**
	 ** This method is to provide existing user detail
	 *  * @param firstname
	 *  * @param lastname
	 *  * @param  mailid
	 */
	public void provideExistingUserDetails(String firstName, String lastName, String mailid)
			throws InterruptedException {
		try {
			Thread.sleep(1000);
			userN.sendKeys(firstName);
			create.click();
			Thread.sleep(3000);
			if(message.isDisplayed()) {
				log.info(message.getText() + " " + firstName );

			}


		} catch (InterruptedException e1) {
			log.error("Register element is not found.");
			throw (e1);
		}

	}

	/**
	 ** This method is to provide current end date details
	 *  * @param firstname
	 *  * @param lastname
	 */
	public void provideCurrentEndDateDetails(String firstName, String lastName)
			throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(1000);
			userN.clear();
			userN.sendKeys(firstName);
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
			System.out.println("Today's date is "+dateFormat.format(cal.getTime()));
			endDate.clear();
			endDate.sendKeys(dateFormat.format(cal.getTime()));
			create.click();
			if(endDateError.isDisplayed())
			{
				Thread.sleep(4000);
				log.info(endDateError.getText());
			}

		} catch (InterruptedException e1) {
			log.error("element is not found.");
			throw (e1);
		}

	}
	
	/**
	 ** This method is to provide end date details
	 *  * @param firstname
	 *  * @param lastname
	 */
	public void provideEndDateDetails(String firstName, String lastName)
			throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(1000);
			userN.clear();
			userN.sendKeys(firstName);
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");

			cal.add(Calendar.DATE, -1);
			System.out.println("Yesterday's date was "+dateFormat.format(cal.getTime()));
			endDate.clear();

			endDate.sendKeys(dateFormat.format(cal.getTime()));
			create.click();
			if(endDateError.isDisplayed())
			{Thread.sleep(4000);
			log.info(endDateError.getText());
			}
		} catch (InterruptedException e1) {
			log.error("Register element is not found.");
			throw (e1);
		}

	}
	
	/**
	 ** This method is to provide start date details
	 *  * @param lastname
	 */
	
	public void providestartDateDetails(String firstName, String lastName)
			throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(1000);
			userN.clear();
			userN.sendKeys(firstName);
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");
			cal.add(Calendar.DATE, -2);
			System.out.println("Yesterday's date was "+dateFormat.format(cal.getTime()));
			startDate.clear();
			startDate.sendKeys(dateFormat.format(cal.getTime()));
			create.click();
			if(startDateError.isDisplayed())
			{Thread.sleep(4000);
			log.info(startDateError.getText());
			}
			Thread.sleep(4000);
		} catch (InterruptedException e1) {
			log.error(" element is not found.");
			throw (e1);
		}

	}

	/**
	 ** This method is to provide user details for workflow
	 * * @param username
	 *  * @param firstname
	 *  * @param lastname
	 */
	public void provideUserDetailsWorkFlow(String username, String firstName, String lastName)
			throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(1000);
			userN.clear();
			userN.sendKeys(username);
			firstN.sendKeys(firstName);
			lastN.sendKeys(lastName);
			Calendar calendar=Calendar.getInstance();
			System.out.println(calendar.getTime());
			//	endDate.sendKeys();

		} catch (InterruptedException e1) {
			log.error("Register element is not found.");
			throw (e1);
		}

	}

	/**
	 ** This method is to validate user creation
	 */
	public void createUserValidation() {
		try {
			Thread.sleep(1000);
			requestCreationMessage.getText();
			Assert.assertEquals(requestCreationMessage.getText(), "Your request has been submitted");
			log.info("User has been successfully created");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.info("User hasn't been successfully created");
		}

	}

	/**
	 ** This method is to execute a job under job control panel
	 */
	public void executeJob() throws AWTException, InterruptedException {
		Thread.sleep(3000);
		attestation.click();
		Thread.sleep(3000);
		job.click();
		Thread.sleep(3000);
		jobAction.click();
		Thread.sleep(3000);
		start.click();
		Thread.sleep(3000);

	}

	/**
	 ** This method is to navigate to Manage My access an an External user
	 */
	public void navigateToManageMyAccessExternalUser() {
		try {
			Thread.sleep(2000);
			menu.click();
			search.sendKeys("Manage My Access");
			Thread.sleep(1000);
			manageMyAccess.click();
			Thread.sleep(1000);
			log.info("User is on Request Access Page");

		} catch (Exception e) {
			Assert.fail("Navigation has failed to Request Access Page as as External User");

		}
		
	}

}