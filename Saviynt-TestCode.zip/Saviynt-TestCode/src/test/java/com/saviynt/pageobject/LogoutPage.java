package com.saviynt.pageobject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LogoutPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();

	public LogoutPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

////Element Repository with element locators////
	@FindBy(xpath = "//*[@class='user-image']")
	public WebElement userProfile;
	@FindBy(xpath = "//*[@class='dropdownHeader']")
	public WebElement userProfileLogout;

	@FindBy(xpath = "//*[text()='Log Out']")
	public WebElement logOut;


	/** 
	     * This method is to logout from Saviynt Application. 
	     */

	public void clickLogout() throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(1000);
			userProfile.click();
			Thread.sleep(1000);
			logOut.click();

		} catch (NoSuchElementException e) {
			log.info("Element is not found" + e);
		}
	}

	/** 
		     * This method is for a Manager logout from Saviynt Application as the user profile locator differs based on manager or admin login. 
		     */

	public void clickLogoutAsManager() throws InterruptedException {
		try {
			userProfileLogout.click();
			Thread.sleep(1000);
			logOut.click();

		} catch (NoSuchElementException e) {
			log.info("Element is not found" + e);
		}
	}
}
