package com.saviynt.pageobject;

import static org.junit.Assert.fail;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.utils.commonFunctionUtil;

import org.junit.Assert;

public class EntitlementPage extends commonFunctionUtil {
	WebDriver driver;
	private static Logger log = LogManager.getLogger("EntitlementPage");

	public EntitlementPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	JavascriptExecutor js;

	////Element Repository with element locators////
	@FindBy(xpath = "//*[@class = 'MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//*[@class = 'saviynt-logo-size']")
	public WebElement saviyntLogo;
	@FindBy(xpath = "//input[@placeholder ='Search']")
	public WebElement search;
	@FindBy(xpath = "//span[normalize-space(text())='Create New Entitlement']")
	public WebElement newEntitlement;
	@FindBy(xpath = "//span[normalize-space(text())='Create New Entitlement Type']")
	public WebElement newEntitlementType;
	@FindBy(xpath = "//span[normalize-space(text())='Update Existing Entitlement Type']")
	public WebElement updateEntitlementType;
	@FindBy(xpath = "//span[normalize-space(text())='Update Existing Entitlement']")
	public WebElement updateEntitlement;
	@FindBy(xpath = "//input[@id='entitlement_value']")
	public WebElement entitlementValue;
	@FindBy(xpath = "//span[normalize-space(text())='Select Security System']")
	public WebElement securitySystem;
	@FindBy(xpath = "//span[normalize-space(text())='Select Endpoint']")
	public WebElement endPoint;
	@FindBy(xpath = "//span[normalize-space(text())='Select Entitlement Type']")
	public WebElement entitlementType;
	@FindBy(xpath = "//*[@id='select2-drop']//input")
	public WebElement entitlementTypeSearch;
	@FindBy(xpath = "//*[@class='select2-no-results' and text()='No matches found']")
	public WebElement entitlementTypeNoSearchResultMessage;

	@FindBy(xpath = "//a[@href='javascript:;' or text()='Create']")
	public WebElement create;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li//div")
	public List<WebElement> securityDropdown;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li//div")
	public List<WebElement> endPointDropdown;
	@FindBy(xpath = "//*[@id='s2id_entitlementtypekey']//a//span")
	public List<WebElement> entitlementTypeDropdown;
	@FindBy(xpath = "//input[@id='dtsearch_EntitlementValueList']")
	public WebElement entitlementSearch;
	@FindBy(xpath = "//tr[1]//td[1]")
	public WebElement entitlement;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement entitlementCount;
	@FindBy(xpath = "//input[@name='description' and @class='form-control']")
	public WebElement description;
	@FindBy(xpath = "//*[@class='btn green readonlyrolebuttonupdate']")
	public WebElement update;
	@FindBy(xpath = "//*[@id='owner']/a")
	public WebElement ownerTab;
	@FindBy(xpath = "//*[@id='associatedentitlement']")
	public WebElement associateEntitlementTab;

	@FindBy(xpath = "//*[@id='accounts']")
	public WebElement accountsTab;
	@FindBy(xpath = "//*[@id='otherentitlementdetails']")
	public WebElement otherEntitlementTab;
	@FindBy(xpath = "//*[@class='popovers']//a[text()='  Roles']")
	public WebElement rolesLink;
	@FindBy(xpath = "//a[contains(@href,'#addRole')]")
	public WebElement addRole;
	@FindBy(xpath = "//*[@id='dtsearch_myDataTableAddRole']")
	public WebElement searchRole;
	@FindBy(xpath = "(//input[@name='rolekey' and @type='checkbox'])[4]")
	public WebElement checkBoxRole;
	@FindBy(xpath = "//*[@id='myDataTableEntShowRoles_info']")
	public WebElement countOfRoles;
	@FindBy(xpath = "//*[@class='active']//a[contains(@href,'#tab_4-4')]")
	public WebElement entitlementMapLink;
	@FindBy(xpath = "(//*[text()=' Actions '])[2]")
	public WebElement entitlementMapActions;
	@FindBy(xpath = "//a[contains(@href,'#addEntMap')]")
	public WebElement addEntitlementMap;
	@FindBy(xpath = "//*[@id='dtsearch_entitlementmap']")
	public WebElement searchEntitlement;
	@FindBy(xpath = "//*[@id='entitlementmap_info']")
	public WebElement countOfEntitlement;
	@FindBy(xpath = "(//input[@name='newrolekey' and @type='checkbox'])[1]")
	public WebElement checkBoxEntitlement;
	@FindBy(xpath = "//*[@id='associatedentitlement']/a")
	public WebElement associateOwnersTab;
	@FindBy(xpath = "(//*[text()=' Actions '])[1]")
	public WebElement actions;
	@FindBy(xpath = "(//i[@class='icon-plus'])[1]")
	public WebElement addOwner;
	@FindBy(xpath = "(//*[@class='icon-plus'])[1]")
	public WebElement addAssociateEntitlement;
	@FindBy(xpath = "//*[@name='sysytemname']//option")
	public List<WebElement> systemNameAssociate;
	@FindBy(xpath = "//*[@name='endpoint']//option")
	public List<WebElement> endPointAssociate;
	@FindBy(xpath = "//*[@id='entitlementbyendpoint']")
	public WebElement entitlementTypeAssociate;

	@FindBy(xpath = "//input[@id='dtsearch_allusersofloggedmanager']")
	public WebElement searchOwner;
	@FindBy(xpath = "//div[@id='allusersofloggedmanager_info']")
	public WebElement ownerCount;
	@FindBy(xpath = "//input[@name='bpowner' and @type='checkbox']")
	public WebElement checkBox;
	@FindBy(xpath = "(//*[@class='btn green']//i[@class='icon-save'])[3]")
	public WebElement save;
	@FindBy(xpath = "//button[@class='btn default closebutton']")
	public WebElement close;
	@FindBy(xpath = "//input[@id='entitlementtypekey']")
	public WebElement entitlementTypeKey;
	@FindBy(xpath = "//input[@id='secsys']")
	public WebElement secsys;
	@FindBy(xpath = "//input[@id='endpnt']")
	public WebElement endpoint;
	@FindBy(xpath = "//*[text()='Entitlements']")
	public WebElement entitlementLink;
	@FindBy(xpath = "//tr[@class='odd']")
	public WebElement ownerName;
	@FindBy(xpath = "//*[@id='securitysystems1']")
	public WebElement addChildEntitlementSecuritySysName;
	@FindBy(xpath = "//*[@id='endpoint']")
	public WebElement addChildEntitlementSecuritySysEndPoint;
	@FindBy(xpath = "//*[@id='s2id_autogen122']")
	public WebElement addChildEntitlementType;
	@FindBy(xpath = "//*[@id='entvalforsystemendpoint1']")
	public WebElement addChildEntitlementScroller;
	@FindBy(xpath = "//*[@class='m-icon-swapright m-icon-white']")
	public WebElement addChildEntitlementSave;
	@FindBy(xpath = "//*[@id='s2id_Sox_Critical_label']")
	public WebElement soxCriticalDropDown;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement soxCriticalDropDownValue;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li[2]")
	public WebElement soxCriticalDropDownValueSelected;
	@FindBy(xpath = "//*[@id='s2id_SysCritical_label_ID']")
	public WebElement sysCriticalDropDown;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement sysCriticalDropDownValue;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li[2]")
	public WebElement sysCriticalDropDownValueSelected;
	@FindBy(xpath = "//*[@id='s2id_RISK_ID']")
	public WebElement riskDropDownValue;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement riskDropDownValueSelected;
	@FindBy(xpath = "//*[@id='select2-drop']/ul/li[2]")
	public WebElement riskValueSelected;
	@FindBy(xpath = "//*[@id='s2id_Sox_Critical_label']//span[text()='Low']")
	public WebElement soxCriticalValueFromUi;
	@FindBy(xpath = "//*[@id='s2id_SysCritical_label_ID']//span[text()='Low']")
	public WebElement sysCriticalValueFromUi;
	@FindBy(xpath = "//*[@id='s2id_RISK_ID']//span[text()='Low']")
	public WebElement riskValueFromUi;
	@FindBy(xpath = "//*[@class='modal fade in']")
	public WebElement saviyntSecurityManagerPopUp;
	@FindBy(xpath = "//*[@class='bootbox-body']")
	public WebElement saviyntSecurityManagerPopUpMessage;
	@FindBy(xpath = "//*[@class='btn default closebutton']")
	public WebElement saviyntSecurityManagerPopUpClose;
	@FindBy(xpath = "//*[@id='myDataTableOwners_info']")
	public WebElement countOfitemsOnOwnersPage;
	@FindBy(xpath = "//*[@id='s2id_Status_label_1']")
	public WebElement statusDropDown;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement statusDropDownSearch;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li[2]")
	public WebElement statusDropDownSearchSelected;
	@FindBy(xpath = "//*[@name='entitlementname']")
	public WebElement entitlementTypeNameInput;
	@FindBy(xpath = "//*[@name='displayName']")
	public WebElement entitlementTypeDisplayNameInput;
	@FindBy(xpath = "//*[@id='ENTITLEMENTDESCRIPTION']")
	public WebElement entitlementDescriptionNameInput;

	@FindBy(xpath = "//*[@class='btn green']")
	public WebElement entitlementTypeCreate;
	@FindBy(xpath = "//*[@id='blankEntitlementType']")
	public WebElement entitlementTypeNameBlankErrorMessage;
	@FindBy(xpath = "//*[@id='blankEntitlementTypedisplayname']")
	public WebElement entitlementTypeDisplayNameBlankErrorMessage;
	@FindBy(xpath = "//*[@class='select2-chosen' and text()='Privileged_Account']")
	public WebElement endPointDropDownInput;
	@FindBy(xpath = "(//*[@class='select2-search'])[2]")
	public WebElement endPointSearch;
	@FindBy(xpath = "(//*[@class='select2-results']//li)[1]")
	public WebElement endPointSelected;
	@FindBy(xpath = "//*[@class='page-title']")
	public WebElement myApplicationListsTitleAsExternalUser;
	@FindBy(xpath = "//*[@class='d-flex account-name']")
	public WebElement applicationNameUnderApplicationsExternalUser;
	@FindBy(xpath = "(//*[@class='MuiInputBase-root searchBox MuiInputBase-marginDense']//input)[1]")
	public WebElement searchApplicationUnderMyAccessExternalUser;
	@FindBy(xpath = "//*[@class='icon-section']")
	public WebElement iconsectionApplication;
	@FindBy(xpath = "//*[@class='MuiList-root MuiMenu-list']//li[text()='enable']")
	public WebElement iconsectionEnableApplication;
	@FindBy(xpath = "///*[@class='MuiList-root MuiMenu-list']//li[text()='lock']")
	public WebElement iconsectionLockApplication;
	@FindBy(xpath = "//*[@class='MuiButton-label' and text()='Modify']")
	public WebElement applicationModifyUnderApplicationsExternalUser;
	@FindBy(xpath = "//*[@class='divTableCell name']")
	public WebElement applicationEntitlmentExternalUser;
	@FindBy(xpath = "//*[@id='dtsearch_myDataEntitlementtypelist']")
	public WebElement entitlementTypeSearchUpdateEntitlemntTypePage;
	@FindBy(xpath = "//*[@id='search_myDataEntitlementtypelist']//i")
	public WebElement entitlementTypeSearchUpdateEntitlemntTypePageButton;
	@FindBy(xpath = "//*[@name='_action_Delete']")
	public WebElement entitlementTypeDelete;
	@FindBy(xpath = "//*[@id='myDataEntitlementtypelist_info']")
	public WebElement entitlementTypeCountMesage;
	@FindBy(xpath = "//*[@class='btn green readonlyrolebuttonupdate']")
	public WebElement entitlementTypeUpdateButton;
	@FindBy(xpath = "//*[@id='comments']")
	public WebElement commentsForEnablementOrLockAccountMyAccessExternalUser;
	@FindBy(xpath = "//*[text()='Proceed']")
	public WebElement confirmEnablementOrLockAccountMyAccessExternalUser;
	@FindBy(xpath = "//h5[@class='mt-3']")
	public WebElement requestConfirmationMessage;



	/**
	 * This method navigates to Create Entitlement page
	 */
	public void navigateToCreateNewEntitlement() throws InterruptedException {
		Thread.sleep(2000);
		// waitElementToBeClickable(menu);
		menu.click();
		// waitElementToBeClickable(search);
		try {
			search.sendKeys("Create New Entitlement");
			Thread.sleep(2000);
			// waitElementToBeClickable(newEntitlement);
			newEntitlement.click();
		} catch (Exception e) {
			log.info("Create Entitlement is not found");
		}
	}

	/** 
	     * This method is to navigate to update Entitlement Type page
	    
	     */

	public void navigateToUpdateEntitlementType() throws InterruptedException {
		Thread.sleep(2000);
		// waitElementToBeClickable(menu);
		menu.click();
		// waitElementToBeClickable(search);
		try {
			search.sendKeys("Update Existing Entitlement Type");
			Thread.sleep(2000);
			updateEntitlementType.click();
		} catch (Exception e) {
			log.info("Update Update Existing Entitlement Type is not found");
		}
	}

	/** 
	     * This method is to navigate to Create Entitlement Type page
	    
	     */

	public void navigateToCreateNewEntitlementType() throws InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(2000);
		// waitElementToBeClickable(menu);
		menu.click();
		// waitElementToBeClickable(search);
		try {
			search.sendKeys("Create New Entitlement Type");
			Thread.sleep(2000);
			newEntitlementType.click();
		} catch (Exception e) {
			log.info("Create Entitlement Type is not found");
		}
	}

	/** 
	     * This method is to validate created entitlement Type is listed under Entitlement Type list
	    
	     */


	public void validatesEntitlementTypeWhileEntitlementCreation(String entitlementName, String securitySys,
			String endPointValue, String entitlementTypeName) throws InterruptedException, AWTException {

		entitlementValue.sendKeys(entitlementName);
		driver.findElement(By.xpath("//*[@class='select2-chosen' and text()=' Select Security System ']")).click();
		Thread.sleep(2000);
		List<WebElement> values = securityDropdown;
		System.out.println("values size :" + values.size());
		List<WebElement> endPointvalues = endPointDropdown;
		List<WebElement> entitlementTypeValues = entitlementTypeDropdown;
		for (WebElement ele : values) {
			String name = ele.getText().trim();
			log.info("Security system drop down list:" + name);
		}
		for (WebElement ele : endPointvalues) {
			String name = ele.getText().trim();
			log.info("End point drop down list:" + name);
		}

		for (int i = 0; i < values.size(); i++) {

			if (values.get(i).getText().contains(securitySys)) {
				log.info(
						"Selecting the Security system from the security system drop down: " + values.get(i).getText());
				values.get(i).click();
				break;
			}
		}
		endPoint.click();
		Thread.sleep(2000);
		for (int i = 0; i < endPointvalues.size(); i++) {

			if (endPointvalues.get(i).getText().contains(endPointValue)) {

				log.info("Selecting the End point from the End point drop down: " + endPointvalues.get(i).getText());
				endPointvalues.get(i).click();
				break;
			}
		}

		entitlementType.click();
		Thread.sleep(1000);
		log.info("Select Entitlement Type");
		entitlementTypeSearch.sendKeys(entitlementTypeName);
		/*
		 * if(entitlementTypeNoSearchResultMessage.isDisplayed()) { if
		 * (entitlementTypeNoSearchResultMessage.getText().contains("No matches found"))
		 * log.info("New Entitlement Type is not found");
		 * //Assert.fail("Created New Entitlement Type is not found");
		 * 
		 * }
		 */
		log.info("New Entitlement Type is found");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@class='select2-match']")).click();
		Thread.sleep(2000);
		log.info("Entitlement Type is selected");

	}

	/** 
	     * This method is to validate the updated Entitlement Type 
	     * @param entitlement name
	     * @param security system
	 * @param end point
	 * @param entitlement type
	     
	     */
	public void validatesUpdatedEntitlementTypeWhileEntitlementCreation(String entitlementName, String securitySys,
			String endPointValue, String entitlementTypeName) throws InterruptedException, AWTException {

		entitlementValue.sendKeys(entitlementName);
		driver.findElement(By.xpath("//*[@class='select2-chosen' and text()=' Select Security System ']")).click();
		Thread.sleep(2000);
		List<WebElement> values = securityDropdown;
		System.out.println("values size :" + values.size());
		List<WebElement> endPointvalues = endPointDropdown;
		List<WebElement> entitlementTypeValues = entitlementTypeDropdown;
		for (WebElement ele : values) {
			String name = ele.getText().trim();
			log.info("Security system drop down list:" + name);
		}
		for (WebElement ele : endPointvalues) {
			String name = ele.getText().trim();
			log.info("End point drop down list:" + name);
		}

		for (int i = 0; i < values.size(); i++) {

			if (values.get(i).getText().contains(securitySys)) {
				log.info(
						"Selecting the Security system from the security system drop down: " + values.get(i).getText());
				values.get(i).click();
				break;
			}
		}
		endPoint.click();
		Thread.sleep(2000);
		for (int i = 0; i < endPointvalues.size(); i++) {

			if (endPointvalues.get(i).getText().contains(endPointValue)) {

				log.info("Selecting the End point from the End point drop down: " + endPointvalues.get(i).getText());
				endPointvalues.get(i).click();
				break;
			}
		}

		entitlementType.click();
		Thread.sleep(1000);
		log.info("Select Entitlement Type");
		entitlementTypeSearch.sendKeys(entitlementTypeName);
		/*
		 * if(entitlementTypeNoSearchResultMessage.isDisplayed()) { if
		 * (entitlementTypeNoSearchResultMessage.getText().contains("No matches found"))
		 * log.info("New Entitlement Type is not found");
		 * //Assert.fail("Created New Entitlement Type is not found");
		 * 
		 * }
		 */
		log.info("New Entitlement Type is found");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//*[@class='select2-match']")).click();
		Thread.sleep(2000);
		log.info("Entitlement Type is selected");

	}

	/**
	 * This method creates Entitlement with mandatory fields.
	 * 
	 * @param entitlementName
	 * @param Security        System
	 * @param End             Point Name
	 *
	 */

	public void createEntitlement(String entitlementName, String securitySys, String endPointValue,
			String entitlementTypeValue) throws InterruptedException, AWTException {

		entitlementValue.sendKeys(entitlementName);
		driver.findElement(By.xpath("//*[@class='select2-chosen' and text()=' Select Security System ']")).click();
		Thread.sleep(2000);
		List<WebElement> values = securityDropdown;
		System.out.println("values size :" + values.size());
		List<WebElement> endPointvalues = endPointDropdown;
		List<WebElement> entitlementTypeValues = entitlementTypeDropdown;
		for (WebElement ele : values) {
			String name = ele.getText().trim();
			log.info("Security system drop down list:" + name);
		}
		for (WebElement ele : endPointvalues) {
			String name = ele.getText().trim();
			log.info("End point drop down list:" + name);
		}

		for (int i = 0; i < values.size(); i++) {

			if (values.get(i).getText().contains(securitySys)) {
				log.info(
						"Selecting the Security system from the security system drop down: " + values.get(i).getText());
				values.get(i).click();
				break;
			}
		}
		endPoint.click();
		Thread.sleep(2000);
		for (int i = 0; i < endPointvalues.size(); i++) {

			if (endPointvalues.get(i).getText().contains(endPointValue)) {

				log.info("Selecting the End point from the End point drop down: " + endPointvalues.get(i).getText());
				endPointvalues.get(i).click();
				break;
			}
		}

		entitlementType.click();
		Thread.sleep(1000);
		log.info("Select Entitlement Type");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_ENTER);
		log.info("Entitlement Type is selected");
		Thread.sleep(2000);
		create.click();
		Thread.sleep(15000);

	}

	/**
	 * This method is to validate creation of Entitlement Type without entering
	 * mandatory fields and then entering mandatory fields.
	 */
	public void createEntitlementTypeWithMandatoryDetails(String entitlementTypeName, String entitlementTypeDisplayName,
			String endPointName) throws InterruptedException, AWTException {
		try {
			Thread.sleep(1000);
			entitlementTypeDisplayNameInput.sendKeys(entitlementTypeDisplayName);
			entitlementTypeCreate.click();
			Thread.sleep(1000);
			if (entitlementTypeNameBlankErrorMessage.isDisplayed() && entitlementTypeNameBlankErrorMessage.getText()
					.contains("Entitlement Type Name cannot be blank")) {
				log.info("User is not allowed to Create an Entitlement Type without Name");
				Thread.sleep(1000);
				entitlementTypeDisplayNameInput.clear();
				entitlementTypeNameInput.sendKeys(entitlementTypeName);
				entitlementTypeCreate.click();
				Thread.sleep(1000);
				if (entitlementTypeDisplayNameBlankErrorMessage.isDisplayed()
						&& entitlementTypeDisplayNameBlankErrorMessage.getText()
						.contains("Entitlement Type Display Name cannot be blank")) {
					log.info("User is not allowed to Create an Entitlement Type without Display name");
					Thread.sleep(1000);
					entitlementTypeDisplayNameInput.sendKeys(entitlementTypeDisplayName);
					Thread.sleep(1000);
					// select an end point
					endPointDropDownInput.click();
					Robot rb = new Robot();
					rb.keyPress(KeyEvent.VK_DOWN);
					rb.keyPress(KeyEvent.VK_ENTER);
					Thread.sleep(2000);
					entitlementTypeCreate.click();
					Thread.sleep(15000);
				}
			}
		} catch (Exception e) {

			Assert.fail("Entitlement Type Creation has failed " + e);
		}
	}

	/**
	 * This method is to update of an Entitlement Type
	 * @param entitlement type name
	 * @param Type name
	 * @param display name

	 */
	public void updateEntitlementType(String entitlementTypeName, String typeNameUpdate, String displayNameUpdate,
			String typeDescription, String endPointName) throws InterruptedException, AWTException {
		try {
			Thread.sleep(1000);
			entitlementTypeSearchUpdateEntitlemntTypePage.sendKeys(entitlementTypeName);
			entitlementTypeSearchUpdateEntitlemntTypePageButton.click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[text()='" + entitlementTypeName + "']")).click();
			entitlementTypeNameInput.clear();
			entitlementTypeNameInput.sendKeys(typeNameUpdate);
			entitlementTypeDisplayNameInput.clear();
			entitlementTypeDisplayNameInput.sendKeys(displayNameUpdate);
			entitlementDescriptionNameInput.sendKeys(typeDescription);
			entitlementTypeUpdateButton.click();
			Thread.sleep(15000);
		} catch (Exception e) {

			Assert.fail("Entitlement Type Creation has failed " + e);
		}
	}

	/**
	 * This method is to validate delete of an Entitlement Type
	 */
	public void deleteEntitlementType(String entitlementTypeName) throws InterruptedException, AWTException {
		try {
			Thread.sleep(1000);
			entitlementTypeSearchUpdateEntitlemntTypePage.sendKeys(entitlementTypeName);
			entitlementTypeSearchUpdateEntitlemntTypePageButton.click();
			Thread.sleep(2000);
			driver.findElement(By.xpath("//*[text()='" + entitlementTypeName + "']")).click();
			Thread.sleep(2000);
			entitlementTypeDelete.click();
			entitlementTypeSearchUpdateEntitlemntTypePage.sendKeys(entitlementTypeName);
			entitlementTypeSearchUpdateEntitlemntTypePageButton.click();
			String MainWindow = driver.getWindowHandle();
			Thread.sleep(1000);
			driver.switchTo().alert().accept();
			Thread.sleep(1000);
			driver.switchTo().window(MainWindow);
			entitlementTypeSearchUpdateEntitlemntTypePageButton.click();
			Thread.sleep(2000);
			driver.switchTo().alert().accept();
			Thread.sleep(1000);
			driver.switchTo().window(MainWindow);
			entitlementTypeSearchUpdateEntitlemntTypePage.sendKeys(entitlementTypeName);

			if (entitlementTypeCountMesage.getText().contains("Showing 0 to 0 of 0 entries")) {
				log.info(entitlementTypeName + "Entitlement Type is deleted successfully");
			} else {
				log.info(entitlementTypeName + "Entitlement Type is not deleted successfully");
				// Assert.fail(entitlementTypeName+"Entitlement Type is not deleted
				// successfully" );
			}

		} catch (Exception e) {

			Assert.fail("Entitlement Type deletion has failed " + e);
		}
	}

	/** 
	     * This method is for create Entitlement with non mandatory and mandatory fields . 
	     * @param entitlementName
	     * @param securitySys
	 * @param endPointValue
	     * @param entitlementTypeValue
	     */
	public void createEntitlementWithMandatoryDetails(String entitlementName, String securitySys, String endPointValue,
			String entitlementTypeValue) throws InterruptedException, AWTException {
		driver.findElement(By.xpath("//*[@class='select2-chosen' and text()=' Select Security System ']")).click();
		Thread.sleep(2000);
		List<WebElement> values = securityDropdown;
		System.out.println("values size :" + values.size());
		List<WebElement> endPointvalues = endPointDropdown;
		List<WebElement> entitlementTypeValues = entitlementTypeDropdown;
		for (WebElement ele : values) {
			String name = ele.getText().trim();
			System.out.println("Security system drop down list:" + name);
		}
		for (WebElement ele : endPointvalues) {
			String name = ele.getText().trim();
			System.out.println("End point drop down list:" + name);
		}
		/* Enter Security System Name */
		for (int i = 0; i < values.size(); i++) {

			if (values.get(i).getText().contains(securitySys)) {
				log.info(
						"Selecting the Security system from the security system drop down: " + values.get(i).getText());
				values.get(i).click();
				break;
			}
		}
		/* Enter End Point Name */
		endPoint.click();
		Thread.sleep(2000);
		for (int i = 0; i < endPointvalues.size(); i++) {

			if (endPointvalues.get(i).getText().contains(endPointValue)) {

				log.info("Selecting the End point from the End point drop down: " + endPointvalues.get(i).getText());
				endPointvalues.get(i).click();
				break;
			}
		}
		/* Enter Entitlement Type */
		entitlementType.click();
		Thread.sleep(1000);
		log.info("Select Entitlement Type");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_ENTER);
		log.info("Entitlement Type is selected");
		Thread.sleep(2000);
		try {
			create.click();
			Thread.sleep(2000);
			/* validate the Security Message */
			if (saviyntSecurityManagerPopUp.isDisplayed()
					&& saviyntSecurityManagerPopUpMessage.getText().contains("Please enter all the required details")) {
				log.info("Error message got displayed when entitlement name is not passed:"
						+ saviyntSecurityManagerPopUpMessage.getText());
				saviyntSecurityManagerPopUpClose.click();
				/* Browser Hard Refresh */
				driver.navigate().refresh();
				/* Enter Entitlement Name */
				entitlementValue.sendKeys(entitlementName);
				Thread.sleep(1000);
				/* Enter Security System Name */
				securitySystem.click();
				Thread.sleep(1000);
				for (int i = 0; i < values.size(); i++) {
					if (values.get(i).getText().contains(securitySys)) {
						log.info("Selecting the Security system from the security system drop down: "
								+ values.get(i).getText());
						values.get(i).click();
						break;
					}
				}
				create.click();
				Thread.sleep(2000);
				/* validate the Security Message */
				if (saviyntSecurityManagerPopUp.isDisplayed() && saviyntSecurityManagerPopUpMessage.getText()
						.contains("Please enter all the required details")) {
					log.info("Error message got displayed when entitlement name and security system details passed:"
							+ saviyntSecurityManagerPopUpMessage.getText());
					saviyntSecurityManagerPopUpClose.click();
					Thread.sleep(2000);
					/* Browser Hard Refresh */
					driver.navigate().refresh();
					/* Enter Entitlement Name */
					entitlementValue.sendKeys(entitlementName);
					/* Enter Security System Name */
					securitySystem.click();
					Thread.sleep(1000);
					for (int i = 0; i < values.size(); i++) {
						if (values.get(i).getText().contains(securitySys)) {
							log.info("Selecting the Security system from the security system drop down: "
									+ values.get(i).getText());
							values.get(i).click();
							break;
						}
					}
					Thread.sleep(1000);
					/* Enter End Point */
					endPoint.click();
					Thread.sleep(3000);
					for (int i = 0; i < endPointvalues.size(); i++) {
						if (endPointvalues.get(i).getText().contains(endPointValue)) {
							log.info("Selecting the End point from the End point drop down: "
									+ endPointvalues.get(i).getText());
							endPointvalues.get(i).click();
							break;
						}
					}
					create.click();
					Thread.sleep(2000);
					/* validate the Security Message */
					if (saviyntSecurityManagerPopUp.isDisplayed() && saviyntSecurityManagerPopUpMessage.getText()
							.contains("Please enter all the required details")) {
						log.info("Error message got displayed " + saviyntSecurityManagerPopUpMessage.getText());
						saviyntSecurityManagerPopUpClose.click();

						driver.navigate().refresh();
						entitlementValue.sendKeys(entitlementName);
						securitySystem.click();
						Thread.sleep(1000);
						for (int i = 0; i < values.size(); i++) {

							if (values.get(i).getText().contains(securitySys)) {
								log.info("Selecting the Security system from the security system drop down: "
										+ values.get(i).getText());
								values.get(i).click();
								break;
							}
						}
						Thread.sleep(1000);
						endPoint.click();
						Thread.sleep(3000);
						for (int i = 0; i < endPointvalues.size(); i++) {

							if (endPointvalues.get(i).getText().contains(endPointValue)) {

								log.info("Selecting the End point from the End point drop down: "
										+ endPointvalues.get(i).getText());
								endPointvalues.get(i).click();
								break;
							}
						}
						entitlementType.click();
						Thread.sleep(1000);
						log.info("Select Entitlement Type");
						// Robot rb = new Robot();
						rb.keyPress(KeyEvent.VK_DOWN);
						rb.keyPress(KeyEvent.VK_ENTER);
						log.info("Entitlement Type is selected");
						Thread.sleep(3000);
						create.click();
						Thread.sleep(15000);

					}

				}
			}

		} catch (Exception e) {
			log.info(e);
			Assert.fail("Validation of Create Entitlement without mandatory fields details has failed");

		}

	}

	/** 
	     * This method is to navigate to Entitlement in identity repo. 
	     */

	public void navigateToEntitlementsInIdentityRepo() throws InterruptedException {
		try {
			Thread.sleep(1000);
			menu.click();
			Thread.sleep(1000);
			search.sendKeys("Entitlements");
			Thread.sleep(2000);
			entitlementLink.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.info("Navigation to Entitlement has failed");
		}
	}

	/**
	 * This method search Entitlement on Entitlemet Page.
	 * 
	 * @param Entitlement Name to search For
	 */
	public void searchEntitlement(String entitlementName) throws InterruptedException {
		try {
			entitlementSearch.sendKeys(entitlementName);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);

			if (entitlementCount.getText().contains("0 entries"))
				Assert.fail("No entitlement found with following name");
			else
				log.info("Search entitlement has been completed successfully");

		} catch (Exception e) {
			Assert.fail("Search entitlement failed");

		}

	}

	/** 
		     * This method is to click on the searched entitlement
		     */
	public void clickSearchedEntitlement() {

		try {
			log.info("Click on Searched entitlement link");
			entitlement.click();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			Assert.fail("Unable to click on Seached Entitlement link");
		}
	}

	/** 
		     * This method is to validate the mandatory fields are non editable for an existing entitlement
	 * @param security system
             * @param end point
             * @param Entitlement Type
             **/

	public void validateMandatoryFieldsUpdateEntitlement() {

		if (secsys.isEnabled() == true && endpoint.isEnabled() == true && entitlementTypeKey.isEnabled() == true) {
			Assert.fail(
					"Mandatory fields Entitlement type ; Security System; End Points on Entilement Page are editable");

		} else if (secsys.isEnabled() == false && endpoint.isEnabled() == false
				&& entitlementTypeKey.isEnabled() == false) {
			log.info(
					"Mandatory fields Entitlement type ; Security System; End Points on Entilement Page are non editable");
		}
	}

	/**
	 * This method validates the details of the newly created Entitlement.
	 * 
	 * @param Target System Name for which Entitlement is created
	 * @param End    Point Name
	 * @return Entitlement Type selected during Entitlement Creation
	 */
	public void validateEntitlement(String securitySys, String endPointValue, String entitlementTypeValue)
			throws InterruptedException {

		log.info("From xls Security System: " + securitySys);
		log.info("From xls  End point : " + endPointValue);
		log.info("From xls  entitlement type: " + entitlementTypeValue);
		try {

			entitlement.click();
			log.info("Security System: " + secsys.getAttribute("Value"));
			log.info("End point : " + endpoint.getAttribute("Value"));
			log.info("entitlement type: " + entitlementTypeKey.getAttribute("Value"));

			if ((secsys.getAttribute("Value").equalsIgnoreCase(securitySys))
					&& (endpoint.getAttribute("Value").equalsIgnoreCase(endPointValue))
					&& (entitlementTypeKey.getAttribute("Value").equalsIgnoreCase(entitlementTypeValue))) {
				log.info("Entitlement is created correctly with provided details");
			} else {
				log.info("Entitlement is not created correctly with provided detail");
			}
		} catch (Exception e) {
			Assert.fail("Entitlement validation failed");

		}

	}
	/** 
		     * This method is to validate if entitlement is updated with provided details. If not, fail the test case
	 * @param entitlement description
             * @param entitlement owner
	 * @param associate entitlement 
         **/

	public void validateUpdatedEntitlement(String entitlementDescription, String entitlementOwner,
			String associateEntitlement) throws InterruptedException {

		log.info("From xls Security System: " + entitlementDescription);
		log.info("From xls  End point : " + entitlementOwner);
		log.info("From xls  End point : " + associateEntitlement);

		try {

			entitlement.click();
			log.info("description: " + description.getAttribute("Value"));

			if ((description.getAttribute("Value").equalsIgnoreCase(entitlementDescription))) {
				log.info("Entitlement description  is updated correctly");
			}

			ownerTab.click();
			Thread.sleep(1000);
			log.info("owner details : " + ownerName.getText());
			if ((ownerName.getText().contains(entitlementOwner))) {
				log.info("Entitlement Owner details  is updated correctly");
			}

		} catch (Exception e) {
			Assert.fail("Entitlement validation failed");

		}

	}

	public void validateUpdatedEntitlementWithRole(String entitlementName, String role) throws InterruptedException {

		log.info("From xls Security System: " + role);

		try {

			entitlement.click();
			otherEntitlementTab.click();
			Thread.sleep(1000);
			rolesLink.click();
			Thread.sleep(1000);

			String entries = countOfRoles.getText().substring(17);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of roles: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);

			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				String cell = driver.findElement(By.xpath("//a[contains(@href,'/ECM/roles/show/'" + 4 + i + "')]"))
						.getText();
				log.info("Name of role: " + cell);
				if (cell.contains(role)) {
					log.info("Role details are added correctly to existing entitlement:" + entitlementName);

				} else {
					Assert.fail("Role details are added correctly to existing entitlement:" + entitlementName);
				}
			}

		} catch (Exception e) {
			Assert.fail("Entitlement validation for Role update has failed");

		}

	}

	public void validateUpdatedEntitlementWithEntitlementMap(String entitlementName, String EntilementMap)
			throws InterruptedException {

		log.info("From xls Security System: " + EntilementMap);

		try {

			entitlement.click();
			otherEntitlementTab.click();
			Thread.sleep(1000);
			rolesLink.click();
			Thread.sleep(1000);

			String entries = countOfEntitlement.getText().substring(17);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of roles: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);

			// Iterating over the List
			for (int i = 0; i <= rows; i++) {
				log.info("Before For loop");
				String cell = driver
						.findElement(By.xpath("//a[contains(@href,'/ECM/entitlement_values/show/'" + 3 + i + "')]"))
						.getText();
				log.info("Name of EntilementMap: " + cell);
				if (cell.contains(EntilementMap)) {
					log.info("EntilementMap details are added correctly to existing entitlement:" + entitlementName);

				} else {
					Assert.fail("EntilementMap details are added correctly to existing entitlement:" + entitlementName);
				}
			}

		} catch (Exception e) {
			Assert.fail("Entitlement validation for EntilementMap update has failed");

		}

	}

	/** 
	     * This method is to validate wheather the status if the entitlement is Inactive.
	 * If not, fail the test case
	     */

	public void validateInactiveEntitlement(String status) throws InterruptedException {

		log.info("From xls Security System: " + status);

		try {

			entitlement.click();
			if (statusDropDown.getText().contains(status)) {
				log.info("Entitlement Status has been updated successfully: " + status);
			} else {
				Assert.fail("Entitlement Status hasn't been updated successfully");
			}

		} catch (Exception e) {
			Assert.fail("Entitlement status validation has failed");

		}

	}

	/** 
		     * This method is to validate the remove details are not displayed for the entitlement
	 * @param entitlement description
             * @param entitlement owner
             **/

	public void validateUpdatedEntitlementWithoutRemovedDetails(String entitlementDescription, String entitlementOwner)
			throws InterruptedException {

		log.info("From xls Security System: " + entitlementDescription);
		log.info("From xls  End point : " + entitlementOwner);
		try {

			entitlement.click();
			log.info("description: " + description.getAttribute("Value"));

			if ((description.getAttribute("Value").equalsIgnoreCase(""))) {
				log.info("Entitlement description has been removed correctly");
			}

			ownerTab.click();
			Thread.sleep(1000);

			if ((countOfitemsOnOwnersPage.getText().contains("Showing 0 to 0 of 0 entries"))) {
				log.info("Entitlement Owner has been removed correctly");
			}

		} catch (Exception e) {
			Assert.fail("Entitlement Removed Details validation has failed");

		}

	}

	public void validateAccountForEntitlement(String user, String targetSystem) throws InterruptedException {

		log.info("From xls External user: " + user);

		try {

			entitlement.click();
			accountsTab.click();
			if ((driver.findElement(By.xpath("//*[text()='" + user + "']")).getText().contains(user)) && driver
					.findElement(By.xpath("//td[text()='" + targetSystem + "']")).getText().contains(targetSystem))
				log.info("New Account has been successfully added for the user: " + user
						+ " And to the security system: " + targetSystem);
			else {
				Assert.fail("New Account hasn't been successfully added for the user: " + user
						+ " And to the security system: " + targetSystem);
				Thread.sleep(1000);
			}

		} catch (Exception e) {
			Assert.fail("Addition of Account for the Entitlement has failed");

		}

	}

	/** 
		     * This method is to navigate to Update Entitlement page
		     */

	public void navigateToUpdateExistingEntitlement() throws InterruptedException {
		try {
			Thread.sleep(1000);
			menu.click();
			search.sendKeys("Update Existing Entitlement");
			Thread.sleep(1000);
			try {
				updateEntitlement.click();
				log.info("Navigation to Update Existing Entitlement is successfully");
			} catch (Exception e) {
				log.info("Update Existing Entitlement link is not found");

			}
		} catch (Exception e) {
			Assert.fail("Navigation to Update Existing Entitlement failed");

		}

	}

	/** 
		     * This method is to update an existing entitlement
	 * @param entitlement description
             * @param entitlement owner
	 * @param associate entitlement 
             * @param associate target system
	 * @param associate end point
             * @param associate entitlement type
		     */
	public void updateEntitlement(String entitlementDescription, String entitlementOwner, String associateEntitlement,
			String associatSystemName, String associateEndPoint, String associateEnttitlementType)
					throws InterruptedException, AWTException {
		log.info("Update Entitlement Description");
		description.clear();
		description.sendKeys(entitlementDescription);
		update.click();
		log.info("Update Owner details for the entitlement");
		Thread.sleep(1000);
		ownerTab.click();
		Thread.sleep(1000);
		actions.click();
		Thread.sleep(1000);
		addOwner.click();
		Thread.sleep(1000);
		searchOwner.sendKeys(entitlementOwner);
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		log.info("#########" + ownerCount.getText());
		if (ownerCount.getText().contains("0 entries"))
			// Assert.fail("No user found with following name to add as owner");
			log.info("No Role found with following name");
		// Thread.sleep(3000);
		checkBox.click();
		Thread.sleep(2000);
		save.click();
		Thread.sleep(1000);
		close.click();
		/* Update associate entitlement */
		// addAssociateEntitlment(associateEntitlement,associatSystemName,associateEndPoint,associateEnttitlementType);
		/*
		 * associateEntitlementTab.click(); Thread.sleep(6000); actions.click();
		 * Thread.sleep(1000); addAssociateEntitlement.click(); Thread.sleep(1000);
		 * List<WebElement> sysNameAssco = systemNameAssociate;
		 * System.out.println("sysNameAssco size :" + sysNameAssco.size());
		 * List<WebElement> endPointAssco = endPointAssociate;
		 * System.out.println("endPointAssco size :" + endPointAssco.size()); //
		 * List<WebElement> entitlementTypeAsscoValues = entitlementTypeAssociate; //
		 * System.out.println("entitlementTypeAsscoValues size :" + //
		 * entitlementTypeAsscoValues.size()); for (WebElement ele : sysNameAssco) {
		 * String name = ele.getText().trim();
		 * log.info("Associate Security system drop down list:" + name); } for
		 * (WebElement ele : endPointAssco) { String name = ele.getText().trim();
		 * log.info("Associate End point drop down list:" + name); }
		 * 
		 * for (int i = 0; i < sysNameAssco.size(); i++) {
		 * 
		 * if (sysNameAssco.get(i).getText().contains(associatSystemName)) {
		 * log.info("Selecting the Security system from the security system drop down: "
		 * + sysNameAssco.get(i).getText()); sysNameAssco.get(i).click(); break; } }
		 * driver.findElement(By.xpath("//*[@name='endpoint']")).click();
		 * Thread.sleep(2000); for (int i = 0; i < endPointAssco.size(); i++) {
		 * 
		 * if (endPointAssco.get(i).getText().contains(associateEndPoint)) {
		 * 
		 * log.info("Selecting the End point from the End point drop down: " +
		 * endPointAssco.get(i).getText()); endPointAssco.get(i).click(); break; } }
		 * 
		 * entitlementTypeAssociate.click(); Thread.sleep(1000);
		 * log.info("Select Entitlement Type"); // Robot rb = new Robot();
		 * rb.keyPress(KeyEvent.VK_DOWN); rb.keyPress(KeyEvent.VK_ENTER);
		 * log.info("Entitlement Type is selected"); Thread.sleep(2000); create.click();
		 * Thread.sleep(15000); js = (JavascriptExecutor) driver; js.
		 * executeScript("$(\"#(//tr//td[text()='Test Entitlement2'])[2]\").animate({ scrollTop: \""
		 * + 100 + "px\" })"); // drive
		 */

	}

	public void addRoleToEntitlement(String role) throws InterruptedException, AWTException {

		otherEntitlementTab.click();
		Thread.sleep(1000);
		rolesLink.click();
		actions.click();
		Thread.sleep(1000);
		addRole.click();
		Thread.sleep(1000);
		searchRole.sendKeys(role);
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		log.info("#########" + countOfRoles.getText());
		if (countOfRoles.getText().contains("0 entries"))
			// Assert.fail("No user found with following name to add as owner");
			log.info("No role found with following name" + role);
		// Thread.sleep(3000);
		checkBoxRole.click();
		Thread.sleep(2000);
		save.click();
		Thread.sleep(1000);
		close.click();

	}

	public void addAssociateEntitlment(String associateEntitlement, String sysName, String endPointVal,
			String asscoEntitlementType) throws AWTException {

		try {
			associateEntitlementTab.click();
			Thread.sleep(2000);
			actions.click();
			Thread.sleep(1000);
			addAssociateEntitlement.click();
			Thread.sleep(1000);
			List<WebElement> sysNameAssco = systemNameAssociate;
			System.out.println("sysNameAssco size :" + sysNameAssco.size());
			List<WebElement> endPointAssco = endPointAssociate;
			System.out.println("endPointAssco size :" + endPointAssco.size());
			// List<WebElement> entitlementTypeAsscoValues = entitlementTypeAssociate;
			// System.out.println("entitlementTypeAsscoValues size :" +
			// entitlementTypeAsscoValues.size());
			for (WebElement ele : sysNameAssco) {
				String name = ele.getText().trim();
				log.info("Associate Security system drop down list:" + name);
			}
			for (WebElement ele : endPointAssco) {
				String name = ele.getText().trim();
				log.info("Associate End point drop down list:" + name);
			}

			for (int i = 0; i < sysNameAssco.size(); i++) {

				if (sysNameAssco.get(i).getText().contains(sysName)) {
					log.info("Selecting the Security system from the security system drop down: "
							+ sysNameAssco.get(i).getText());
					sysNameAssco.get(i).click();
					break;
				}
			}
			driver.findElement(By.xpath("//*[@name='endpoint']")).click();
			Thread.sleep(2000);
			for (int i = 0; i < endPointAssco.size(); i++) {

				if (endPointAssco.get(i).getText().contains(endPointVal)) {

					log.info("Selecting the End point from the End point drop down: " + endPointAssco.get(i).getText());
					endPointAssco.get(i).click();
					break;
				}
			}

			entitlementTypeAssociate.click();
			Thread.sleep(1000);
			log.info("Select Entitlement Type");
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_DOWN);
			rb.keyPress(KeyEvent.VK_ENTER);
			log.info("Entitlement Type is selected");
			Thread.sleep(2000);
			create.click();
			Thread.sleep(15000);
			js = (JavascriptExecutor) driver;
			js.executeScript(
					"$(\"#(//tr//td[text()='Test Entitlement2'])[2]\").animate({ scrollTop: \"" + 100 + "px\" })");
			// driver.findElement(By.xpath("(//*[@class='slimScrollBar'])[4]")).click();

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addEntitlementMapToEntitlement(String entitlementmap) throws InterruptedException, AWTException {

		otherEntitlementTab.click();
		Thread.sleep(1000);
		entitlementMapLink.click();
		entitlementMapActions.click();
		Thread.sleep(1000);
		addEntitlementMap.click();
		Thread.sleep(1000);
		searchEntitlement.sendKeys(entitlementmap);
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		log.info("#########" + countOfEntitlement.getText());
		if (countOfEntitlement.getText().contains("0 entries"))
			// Assert.fail("No user found with following name to add as owner");
			log.info("No entitlement with following name" + entitlementmap);
		// Thread.sleep(3000);
		checkBoxEntitlement.click();
		Thread.sleep(2000);
		save.click();
		Thread.sleep(1000);
		close.click();

	}
	/** 
		     * This method is to update an existing entitlement by removing the details
	 * @param entitlement description
             * @param entitlement owner
             **/

	public void updateEntitlementByRemovingExistingDetails(String entitlementDescription, String entitlementOwner)
			throws InterruptedException, AWTException {
		log.info("Remove Entitlement Description");
		description.clear();
		update.click();
		log.info("Remove Owner details for the entitlement");
		Thread.sleep(1000);
		ownerTab.click();
		Thread.sleep(1000);
		String entries = countOfitemsOnOwnersPage.getText().substring(17);
		String finalEntries = entries.replace("entries", " ");
		String finalEntries2 = entries.replace("entries", " ").trim();
		log.info("No of owners: " + finalEntries2);
		int rows = Integer.valueOf(finalEntries2);
		log.info("********ROWs*******" + rows);
		// Iterating over the List
		for (int i = 1; i <= rows; i++) {
			driver.findElement(By.xpath("(//*[@class='odd' or @class='even']//input[@name='ownerkey'])[" + i + "]"))
			.click();

			Thread.sleep(1000);
		}

		driver.findElement(By.xpath("(//a[@class='btn red'])[1]")).click();
		Thread.sleep(15000);

	}

	/** 
	     * This method is to make an active entilement to inactive 
	     
	     */

	public void updateEntitlementByMakingIactive(String status) throws InterruptedException, AWTException {
		log.info("Making status of an existing entitlement from active to inactive");
		statusDropDown.click();
		statusDropDownSearch.sendKeys("Inactive");
		statusDropDownSearchSelected.click();
		update.click();
		Thread.sleep(15000);
		log.info("Update Status dropdown Value");
	}

	public void updateEntitlementWithMetaData(String securitySys, String endPointValue, String entitlementTypeValue,
			String entitlementDescription, String entitlementOwner, String associateEntitlement)
					throws InterruptedException, AWTException {
		log.info("Update Entitlement Description");
		description.clear();
		description.sendKeys(entitlementDescription);
		log.info("Update SOX critical Value");
		soxCriticalDropDown.click();
		soxCriticalDropDownValue.sendKeys("Low");
		soxCriticalDropDownValueSelected.click();
		log.info("Update Sys critical Value");
		sysCriticalDropDown.click();
		sysCriticalDropDownValue.sendKeys("Low");
		sysCriticalDropDownValueSelected.click();
		log.info("Update Risk Value");
		riskDropDownValue.click();
		riskDropDownValueSelected.sendKeys("Low");
		riskValueSelected.click();
		update.click();
		log.info("Update Owner details for the entitlement");
		Thread.sleep(1000);
		ownerTab.click();
		Thread.sleep(1000);
		actions.click();
		Thread.sleep(1000);
		addOwner.click();
		Thread.sleep(1000);
		searchOwner.sendKeys(entitlementOwner);
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);
		log.info("#########" + ownerCount.getText());
		if (ownerCount.getText().contains("0 entries"))
			// Assert.fail("No user found with following name to add as owner");
			log.info("No user found with following name to add as owner");
		// Thread.sleep(3000);
		checkBox.click();
		Thread.sleep(2000);
		save.click();
		Thread.sleep(1000);
		close.click();
		// log.info("Update associate entitlement details for the entitlement");
		// Thread.sleep(1000);
		// associateOwnersTab.click();
		// Thread.sleep(1000);
		// actions.click();
		Thread.sleep(1000);
		// addAssociateEntitlement.click();
		// Thread.sleep(2000);
		// Select drpSysName = new Select(addChildEntitlementSecuritySysName);
		// drpSysName.selectByVisibleText(securitySys);
		// Thread.sleep(1000);
		// Select drpSysEndPoint = new Select(addChildEntitlementSecuritySysEndPoint);
		// drpSysEndPoint.selectByVisibleText(endPointValue);
		// Thread.sleep(1000);
		// Select drpSysType = new Select(addChildEntitlementType);
		// drpSysEndPoint.selectByVisibleText(entitlementTypeValue);
		// Thread.sleep(1000);

	}

	public void updateEntitlementOwner(String owner) throws InterruptedException, AWTException {

		ownerTab.click();
		Thread.sleep(1000);
		actions.click();
		Thread.sleep(1000);
		addOwner.click();
		Thread.sleep(1000);
		searchOwner.sendKeys(owner);
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		if (ownerCount.getText().contains("0 entries"))
			Assert.fail("No user found with following name to add as owner");
		Thread.sleep(2000);
		checkBox.click();
		save.click();
		Thread.sleep(1000);
		close.click();

	}

	public void validateUpdatedEntitlementAsAnotherUSer(String soxCriticalValue, String syscriticalValue,
			String riskValue, String entitlementDescription, String entitlementOwner) {
		log.info("From xls Security System: " + entitlementDescription);
		log.info("From xls  End point : " + entitlementOwner);
		try {

			entitlement.click();
			log.info("description: " + description.getAttribute("Value"));

			if ((description.getAttribute("Value").equalsIgnoreCase(entitlementDescription))) {
				log.info("Entitlement description  is updated correctly");
			}

			if ((soxCriticalValueFromUi.getText().equals(soxCriticalValue))) {
				log.info("SOX Critical Value  is updated correctly");
			}
			if ((sysCriticalValueFromUi.getText().equals(syscriticalValue))) {
				log.info("Sys Critical Value is updated correctly");
			}
			if ((riskValueFromUi.getText().equals(riskValue))) {
				log.info("Risk Value is updated correctly");
			}

			ownerTab.click();
			Thread.sleep(1000);
			log.info("owner details : " + ownerName.getText());
			if ((ownerName.getText().contains(entitlementOwner))) {
				log.info("Entitlement Owner details  is updated correctly");
			}

		} catch (Exception e) {
			Assert.fail("Entitlement validation failed");

		}

	}

	/**
	 ** This method is to validate Manage Entitlment is not available for
	 * End User 
	 * * @Create New Entitlement     
	 * * @Update Existing Entitlement
	 * * @Create Entitlement Type
	 * *@Update Entitlement Type     
	 */
	public void validateManageEntitlementAsEndUser(String manageEntitlementTab) {
		try {
			Thread.sleep(2000);
			menu.click();
			List<WebElement> tabs = driver.findElements(By
					.xpath("//*[@class='MuiList-root left-menu left-menu-sidebar MuiList-dense MuiList-padding']//li"));
			log.info("tab size:" + tabs.size());
			for (int i = 0; i < tabs.size(); i++) {
				Thread.sleep(2000);
				log.info("List of tabs: " + tabs.get(i).getText());
				if (tabs.get(i).getText().contains(manageEntitlementTab)) {
					log.info("End user has access to Manage Entitlement Tab");
					Assert.fail("End user has access to Manage Entitlement Tab");
					break;

				} else {
					log.info("End User doesn't have permission to Manage Entitlement ");
					Thread.sleep(1000);
					saviyntLogo.click();
					break;

				}

			}
			Thread.sleep(2000);

		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			log.info("validate Manage Entitlement As EndUser has failed");
		}

	}

	/**
	 ** This method is to validate updated Entitlment is listed End User 
	 * * @Create New Entitlement     
	 * * @Create Security system
	 */
	public void validateUpdatedEntitlementListedAsExternalUser(String securitySys, String entitlementName)
			throws InterruptedException {
		try {
			Thread.sleep(4000);
			log.info("*********Before User is on My Application page*********");
			if (myApplicationListsTitleAsExternalUser.getText().contains("My Applications")) {
				log.info("User is on My Application page");
				if (applicationNameUnderApplicationsExternalUser.getText().contains(securitySys)) {
					Thread.sleep(2000);
					applicationModifyUnderApplicationsExternalUser.click();
					Thread.sleep(4000);
					if (applicationEntitlmentExternalUser.getText().contains(entitlementName)) {
						log.info("Entitlement with MetaData Update is listed under the application");
						Thread.sleep(1000);
						driver.findElement(By.xpath("(//*[@class='MuiIconButton-label'])[3]")).click();
						Thread.sleep(4000);

					} else {
						// log.info("Entitlement with MetaData Update is not listed under the
						// application");
						Assert.fail("Entitlement with MetaData Update is listed under the application");
					}
				}
			}

		} catch (Exception e) {
			Assert.fail("validation of Updated EntitlementListed As ExternalUser failed");

		}

	}

	/**
	 ** This method is to enable suspended Entitlement
	 * * @AccountName   
	 * * @Security system
	 * * @enable
	 */
	public void enableSuspendedEntitlement(String securitySys, String accountName, String enable)
			throws InterruptedException {
		try {
			Thread.sleep(4000);
			if (myApplicationListsTitleAsExternalUser.getText().contains("My Applications")) {
				log.info("User is on My Application page");
				searchApplicationUnderMyAccessExternalUser.sendKeys(accountName);
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(2000);
				iconsectionApplication.click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@class='MuiList-root MuiMenu-list']//li[text()='"+enable+"']"))
				.click();
				Thread.sleep(1000);
				commentsForEnablementOrLockAccountMyAccessExternalUser.sendKeys("Test:" +enable);
				confirmEnablementOrLockAccountMyAccessExternalUser.click();
				log.info("User Account request with all details");
				Thread.sleep(5000);

				if (requestConfirmationMessage.getText().contains("Confirmation")) {
					log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
					log.info("Request New access for the user is completed: " + securitySys);

				}
				driver.findElement(By.xpath("//*[text()='Request History']")).click();
				Thread.sleep(1000);

			} else {

				log.info("User is not on Application page");
			}

		} catch (Exception e) {
			Assert.fail("Account Enablement failed for account :" +e);

		}

	}

	/**
	 ** This method is to validate account lock
	 * * @AccountName   
	 * * @Security system
	 * * @accountState
	 */
	public void validateAccountLock(String securitySys, String accountName, String accountstate)
			throws InterruptedException {
		try {
			Thread.sleep(4000);
			if (myApplicationListsTitleAsExternalUser.getText().contains("My Applications")) {
				log.info("User is on My Application page");
				searchApplicationUnderMyAccessExternalUser.sendKeys(accountName);
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(2000);
				if(driver.findElement(By.xpath("//*[text()='"+accountstate+"']")).getText().contains(accountstate));
				log.info("User with account :"+accountName +"has been: " +accountstate );
			}

		} catch (Exception e) {
			Assert.fail("User with account :"+accountName +"has been: " +accountstate +e);

		}

	}


}
