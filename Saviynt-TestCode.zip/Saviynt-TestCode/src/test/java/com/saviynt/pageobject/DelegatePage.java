package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DelegatePage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger("DelegatePage");

	public DelegatePage(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
////Element Repository with element locators////
	@FindBy(xpath = "//*[@class = 'MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@placeholder ='Search']")
	public WebElement search;
	@FindBy(xpath = "//*[text()='Create Delegate']")
	public WebElement createDelegateLink;
	@FindBy(xpath = "//*[text()='Manage Delegate']")
	public WebElement manageDelegateLink;
	@FindBy(xpath = "//*[@id='name']")
	public WebElement delegateReasonField;
	@FindBy(xpath = "//*[@id='description']")
	public WebElement delegateDescritionField;
	@FindBy(xpath = "(//*[@class='btn blue'])[1]")
	public WebElement selectUserButton;
	@FindBy(xpath = "(//*[@class='btn blue'])[2]")
	public WebElement selectDelegateButton;
	@FindBy(xpath = "//*[@id='dtsearch_allusers']")
	public WebElement searchUserParentField;
	@FindBy(xpath = "//*[@id='search_allusers']")
	public WebElement searchParentUserButton;
	@FindBy(xpath = "(//*[@class='radio'])[1]")
	public WebElement checkBoxParentUser;
	@FindBy(xpath = "//*[@id='parentUserBtn']")
	public WebElement submitParentUser;
	@FindBy(xpath = "//*[@id='dtsearch_allusersofloggedmanager']")
	public WebElement searchUserDelegateField;
	@FindBy(xpath = "//*[@id='search_allusersofloggedmanager']")
	public WebElement searchDelegateUserButton;
	@FindBy(xpath = "//*[@name='bpownerDelegate']")
	public WebElement checkBoxDelegateUser;
	@FindBy(xpath = "//*[@id='delegateUserBtn']")
	public WebElement submitDelegateUser;
	@FindBy(xpath = "//*[@id='startdate']")
	public WebElement delegateStartDate;
	@FindBy(xpath = "//*[@id='enddate']")
	public WebElement delegateEndDate;
	@FindBy(xpath = "//*[@id='myform']//a[@class='btn green']")
	public WebElement createDelegate;
	@FindBy(xpath = "//*[@class='btn default closebutton']")
	public WebElement securityManagerClose;
	@FindBy(xpath = "//*[@class='select2-chosen' and text()='Active']")
	public WebElement showAllDelegates;
	@FindBy(xpath = "//*[@class='select2-input']")
	public WebElement searchCountDelegates;
	@FindBy(xpath = "//*[@class='odd' or @class='even']//td[@class=' sorting_1']")
	public WebElement delegatesNameManageDelegates;
	@FindBy(xpath = "//*[@class='odd' or @class='even']//td[2]")
	public WebElement delegatesDescriptionManageDelegates;
	@FindBy(xpath = "//*[@class='odd' or @class='even']//span[@class='UTCDATETIME']")
	public WebElement startDateAndendDateManageDelegates;
	@FindBy(xpath = "//*[@id='allusersofloggedmanager_info']")
	public WebElement selectDelegateMessage;
	
	
	/**
	 * This method navigates to Create Delegate page
	 */
	public void navigateToCreateDelegate() throws InterruptedException {
		Thread.sleep(2000);
		menu.click();
		try {
			search.sendKeys("Create Delegate");
			Thread.sleep(2000);
			createDelegateLink.click();
		} catch (Exception e) {
			log.info("Create Delegate is not found");
		}
	}
	
	
	/**
	 * This method navigates to mmanage Delegate page
	 */
	public void navigateToManageDelegate() throws InterruptedException {
		Thread.sleep(2000);
		menu.click();
		try {
			search.sendKeys("Manage Delegate");
			Thread.sleep(2000);
			manageDelegateLink.click();
		} catch (Exception e) {
			log.info("Manage Delegate is not found");
		}
	}
	
	/**
	 * This method is to validate creation of Delegate without entering
	 * mandatory fields and then entering mandatory fields.
	 */
	public void createDelegateWithMandatoryDetails(String reason, String description,String parent, String delegate,String startDate,String endDate) throws InterruptedException, AWTException {
		try {
			/* Leave the reason field empty*/
			delegateDescritionField.sendKeys(description);
			selectParentUser(parent);
			selectDelegate(delegate);
			selectStartDate(startDate);
			selectEndDate(endDate);
			createDelegate.click();
			if(driver.findElement(By.xpath("//*[@class='validation']")).getText().contains("Delegate Name cannot be empty")) {
				log.info("Delegation name cannot be Empty");
					}
			driver.navigate().refresh();
			/* Leave the description field empty*/
			delegateReasonField.sendKeys(reason);
			selectParentUser(parent);
			selectDelegate(delegate);
			selectStartDate(startDate);
			selectEndDate(endDate);
			createDelegate.click();
			if(driver.findElement(By.xpath("//*[@class='modal-title' and text()='Saviynt Security Manager']")).getText().contains("Saviynt Security Manager")) {
				securityManagerClose.click();
					}
			driver.navigate().refresh();
			
			/* Leave the start date  empty*/
			delegateReasonField.sendKeys(reason);
			delegateDescritionField.sendKeys(description);
			selectParentUser(parent);
			selectDelegate(delegate);
			delegateEndDate.sendKeys(endDate);
			delegateEndDate.click();
			createDelegate.click();
			if(driver.findElement(By.xpath("//*[@class='modal-title' and text()='Saviynt Security Manager']")).getText().contains("Saviynt Security Manager")) {
				securityManagerClose.click();
					}
			driver.navigate().refresh();
			
			/* Leave the end date  empty*/
			delegateReasonField.sendKeys(reason);
			delegateDescritionField.sendKeys(description);
			selectParentUser(parent);
			selectDelegate(delegate);
			delegateStartDate.sendKeys(startDate);
			delegateStartDate.click();
			createDelegate.click();
			if(driver.findElement(By.xpath("//*[@class='modal-title' and text()='Saviynt Security Manager']")).getText().contains("Saviynt Security Manager")) {
				securityManagerClose.click();
					}
			driver.navigate().refresh();
			
			 /** 
			     * This method creates delegates with all mandatory fields. 
			     * @param reason
			     * @param description
			     * @param parent user
			     * @param delegate
			     * @param start date
			     * @param end date
			     * 
			
			     */
			log.info("Entering delegation name:"+reason);
			delegateReasonField.sendKeys(reason);
			Thread.sleep(1000);
			log.info("Entering delegation description:"+description);
			delegateDescritionField.sendKeys(description);
			Thread.sleep(1000);
			log.info("selecting parent :"+parent);
			selectParentUser(parent);
			log.info("selecting delegate :"+delegate);
			selectDelegate(delegate);
			log.info("selecting start date :"+startDate);
			selectStartDate(startDate);
			log.info("selecting end date :"+endDate);
			selectEndDate(endDate);
			createDelegate.click();
            log.info("Delegation is created successfully");
			
		} catch (Exception e) {

			Assert.fail("Delegate Creation has failed " + e);
		}
	}

	private void selectEndDate(String endDate) {
		delegateEndDate.sendKeys(endDate);
		delegateEndDate.click();
	}

	private void selectStartDate(String startDate) {
		delegateStartDate.sendKeys(startDate);
		delegateStartDate.click();
	}

	private void selectDelegate(String delegateUser) throws InterruptedException {
		try {
		selectDelegateButton.click();
		Thread.sleep(2000);
		log.info("Select delegate User:" +delegateUser);
		searchUserDelegateField.sendKeys(delegateUser);
		Thread.sleep(2000);
		searchDelegateUserButton.click();
		Thread.sleep(2000);
		checkBoxDelegateUser.click();
		Thread.sleep(1000);
		Robot rb1 = new Robot();
		rb1.keyPress(KeyEvent.VK_TAB);
		rb1.keyRelease(KeyEvent.VK_TAB);
		rb1.keyPress(KeyEvent.VK_TAB);
		rb1.keyRelease(KeyEvent.VK_TAB);
		rb1.keyPress(KeyEvent.VK_TAB);
		rb1.keyRelease(KeyEvent.VK_TAB);
		rb1.keyPress(KeyEvent.VK_TAB);
		rb1.keyRelease(KeyEvent.VK_TAB);
		rb1.keyPress(KeyEvent.VK_TAB);
		rb1.keyRelease(KeyEvent.VK_TAB);
		rb1.keyPress(KeyEvent.VK_ENTER);
		rb1.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		//submitDelegateUser.click();
		}catch(Exception e ) {
			Assert.fail("Delegate selection is failed"+e);
		}
	}

	private void selectParentUser(String parentUser) throws InterruptedException {
		try {
		selectUserButton.click();
		Thread.sleep(2000);
		log.info("Select Parent User:" +parentUser);
		Thread.sleep(2000);
		searchUserParentField.sendKeys(parentUser);
		Thread.sleep(1000);
		searchParentUserButton.click();
		Thread.sleep(2000);
		checkBoxParentUser.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_TAB);
		rb.keyPress(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_TAB);
		rb.keyPress(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_TAB);
		rb.keyPress(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_TAB);
		rb.keyPress(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_TAB);
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		log.info("Parent User is selected");
		//((JavascriptExecutor)driver).executeScript("arguments[0].checked = true;", submitParentUser);
		//Actions actions = new Actions(driver); actions.moveToElement(submitParentUser).click().build().perform();
		//submitParentUser.click();
		}catch(Exception e){
			Assert.fail("Parent User selection is failed"+e);
		}
	}

	/**
	 * This method is to validate created Delegate 
	 */
	public void validateDelegateWithMandatoryDetails(String reason, String description,String startDate,String endDate) throws InterruptedException, AWTException {
		try {
			showAllDelegates.click();
			searchCountDelegates.sendKeys("All");
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			if (delegatesNameManageDelegates.getText().contains(reason) && delegatesDescriptionManageDelegates.getText().contains(description) ) {
				if ((startDateAndendDateManageDelegates.getText().contains(startDate)) ||startDateAndendDateManageDelegates.getText().contains(endDate)){
					log.info("Delegation has been validated successfully");
				}
			}
			
		} catch (Exception e) {

			Assert.fail("Validation of Delegates has failed " + e);
		}
	}

	/**
	 * This method is to validate Inactive user is not listed under Delegate user list
	 */
	public void inActiveUserNotDelegate(String inactiveUser,String reason, String description,String parent, String delegate,String startDate,String endDate) throws InterruptedException, AWTException {
			log.info("Entering delegation name:"+reason);
			delegateReasonField.sendKeys(reason);
			Thread.sleep(1000);
			log.info("Entering delegation description:"+description);
			delegateDescritionField.sendKeys(description);
			Thread.sleep(1000);
			log.info("selecting parent :"+parent);
			selectParentUser(parent);
			log.info("selecting delegate :"+inactiveUser);
			selectDelegateButton.click();
			Thread.sleep(2000);
			searchUserDelegateField.sendKeys(inactiveUser);
			Thread.sleep(2000);
			searchDelegateUserButton.click();
			try {
			if (selectDelegateMessage.getText().contains("Showing 0 to 0 of 0 entries")) {
				log.info("Inactive user is not listed under Delegate User List");
				driver.findElement(By.xpath("(//*[@id='usermodaldiv']//button)[1]")).click();
				Thread.sleep(2000);
			}
			
			
		} catch (Exception e) {

			Assert.fail("Inactive user is listed under Delegate User List " + e);
		}
	}

}
