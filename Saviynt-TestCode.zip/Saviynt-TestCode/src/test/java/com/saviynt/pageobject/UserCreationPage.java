package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mortbay.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.Assert;

public class UserCreationPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger("UserCreationPage");

	public UserCreationPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	////Element Repository with element locators////
	@FindBy(xpath = "//*[@class='cl-logo']")
	public WebElement Home;
	@FindBy(xpath = "//*[@class = 'MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@type = 'text']")
	public WebElement search;
	@FindBy(xpath = "//span[text()= 'Create User Request']")
	public WebElement createUser;
	@FindBy(xpath = "//span[text()= 'Upload User Request']")
	public WebElement uploadUser;
	@FindBy(xpath = "//input[@title='Local User' and @value='Yes']")

	public WebElement localUser;
	@FindBy(xpath = "//input[@title='Local User' and @value='No']")
	public WebElement NoLocalUser;
	@FindBy(xpath = "//div[text()='PrimaryID']")
	public WebElement primaryID;
	@FindBy(xpath = "//input[@title='First_Name']")
	public WebElement firstName;
	@FindBy(xpath = "//input[@title='Last_Name']")
	public WebElement lastName;
	@FindBy(xpath = "//input[@id='MIDDLE INITIAL']")
	public WebElement initial;
	@FindBy(xpath = "//input[@id='MIDDLE_NAME']")
	public WebElement middleName;
	@FindBy(xpath = "//input[@id='JOB_TITLE']")
	public WebElement jobtitle;

	// Account manager details
	@FindBy(id = "MANAGERNAME")
	public WebElement accounManager;
	@FindBy(id = "MANAGER E-MAILADDRESS")
	public WebElement accounManagerEmail;

	// manager details
	@FindBy(id = "MANAGER")
	public WebElement manager;
	@FindBy(id = "MANAGER E-MAIL")
	public WebElement managerEmail;

	// company details
	@FindBy(id = "COMPANY ASSOCIATION:")
	public WebElement company;
	@FindBy(id = "selectEnumEMPLOYEE CATEGORY")
	public WebElement category;
	@FindBy(id = "s2id_selectEnumEMPLOYEETYPE")
	public WebElement employeeType;
	@FindBy(xpath = "//div[@id='select2-drop']//ul//li//div")
	public List<WebElement> employeeTypeDrpdown;

	// phone details
	@FindBy(id = "COUNTRY CODE")
	public WebElement countryCode;
	@FindBy(id = "AREA CODE")
	public WebElement areaCode;
	@FindBy(id = "LOCAL NUMBER")
	public WebElement localNumber;
	@FindBy(id = "EXTENSION")
	public WebElement extension;

	// partner details
	@FindBy(xpath = "//input[@title='Firstname']")
	public WebElement partnerFirstName;
	@FindBy(id = "LASTNAME")
	public WebElement partnerLastName;
	@FindBy(id = "MIDDLE INITIAL")
	public WebElement partnerInitial;
	@FindBy(id = "JOBTITLE")
	public WebElement partnerJobtitle;

	// partner access
	@FindBy(id = "PARTNER ACCESS")
	public WebElement partnerAccess;
	@FindBy(id = "LOGONID")
	public WebElement logOnId;

	// organization details
	@FindBy(id = "EMPLOYEE_ACCESS")
	public WebElement hrEmployeeId;
	// public WebElement = driver.findElement(By.xpath(""));
	@FindBy(xpath = "//a[@id='clickUpload']")
	public WebElement uploadAttachment;
	@FindBy(xpath = "//*[normalize-space(text())='Submit']")
	public WebElement submitButton;
	@FindBy(xpath = "//*[normalize-space(text())='Next']")
	public WebElement nextButton;
	@FindBy(xpath = "//div[@class='note note-success text-transform-none']//p")
	public WebElement successNote;

	@FindBy(xpath = "//*[contains(text(),'user has been created/updated')]")
	public WebElement createdMessage;
	@FindBy(xpath = "//div[@class='datatable-scroll']")
	public WebElement userDataTable;
	@FindBy(xpath = "//td[2]")
	public WebElement firstNameInfo;
	@FindBy(xpath = "//td[3]")
	public WebElement lastNameInfo;
	@FindBy(xpath = "//td[4]")
	public WebElement status;
	@FindBy(xpath = "//td[6]")
	public WebElement email;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement userCount;
	@FindBy(xpath = "//input[@id='USER DETAILS']")
	public WebElement userType;
	@FindBy(xpath = "//input[contains(@id,'EVERGREENDEVICE')]")
	public WebElement needEvergreenDevice;
	@FindBy(xpath = "//input[contains(@id,'PARTNER_ACCESS')]")
	public WebElement externalEmail;

	@FindBy(id = "dtsearch_usersList")
	public WebElement search_usersList;

	// select file

	@FindBy(xpath = "//*[@class='buttonAlignmt']")
	public WebElement selectFile;

	@FindBy(xpath = "//input[@name='firstrow' and @value='YES']")
	public WebElement firstRowHeadingRadiobtn;
	@FindBy(xpath = "//*[@class='btn blue']")
	// "//i[@class='glyphicon glyphicon-eye-open']")
	public WebElement upload;

	@FindBy(xpath = "//div[@id='userImportTable']")
	public WebElement table;

	@FindBy(xpath = "//div[@id='userImportTable']//th")
	public List<WebElement> header;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li")
	public List<WebElement> headerDrpdwn;

	@FindBy(xpath = "//*[@id='importBtn']/a[1]")
	public WebElement importBtn;

	@FindBy(xpath = "//label[1]//ins[@class='iCheck-helper']")
	public List<WebElement> yesRadioBtn;
	@FindBy(xpath = "//label[2]//ins[@class='iCheck-helper']")
	public List<WebElement> noRadioBtn;

	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement searchDropdwn;

	@FindBy(xpath = "//*[@class='page-title']")
	public WebElement UploadUserTile;

	@FindBy(xpath = "(//*[@class='icon-search'])[1]")
	public WebElement searchButton;

	@FindBy(xpath = "//div[text()='This is not an allowed file type.']")
	public WebElement invalidFileType;

	@FindBy(xpath = "//button[@class='btn default closebutton']")
	public WebElement closeButton;

	@FindBy(xpath = "//*[@class='modal-body']")
	public WebElement securityManagerText;
	@FindBy(xpath = "//h3[text()=' No records found']")
	public WebElement noRecords;

	@FindBy(xpath = "//*[@class='btn default button-previous']")
	public WebElement backButton;

	public WebElement recordsCount;

	public void navigateToCreateUserRequest() throws InterruptedException {
		Thread.sleep(1000);
		menu.click();

		search.sendKeys("Create User Request");

		Thread.sleep(1000);

		createUser.click();
		Thread.sleep(1000);
	}

	public void provideUserDetails(String userFirstName, String userLastName, String useIinitial, String userJobTitle,
			String userManagerName, String userHREmployeeId, String userPartnerAccess, String userPartnerFirstName,
			String userPartnerLastName, String email) throws InterruptedException {
		try {
			Thread.sleep(1000);
			hrEmployeeId.sendKeys(userHREmployeeId);
			// needEvergreenDevice.sendKeys("No");
			externalEmail.sendKeys(userFirstName + "123@gmail.com");
			userType.sendKeys("Employee");
			firstName.sendKeys(userFirstName);
			lastName.sendKeys(userLastName);
			middleName.sendKeys(useIinitial);
			jobtitle.sendKeys(userJobTitle);
		} catch (InterruptedException e1) {
			log.error("Register element is not found.");
			throw (e1);
		}
	}

	/**
	 ** This method is to submit user request
	 */
	public void submitCreateUserRequest() throws InterruptedException {

		submitButton.click();

	}

	/**
	 ** This method is to search user
	 ** @param user
	 */

	public void searchUser(String user) throws InterruptedException {
		try {
			search_usersList.clear();
			search_usersList.sendKeys(user);
			Thread.sleep(1000);
			searchButton.click();
			Thread.sleep(2000);

			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}

	/**
	 ** This method is to validate email generation after user creation
	 */
	public void validateEmailGeneration() throws InterruptedException, AWTException {

		String emailInfo = email.getText();
		log.info("email generated  for user is " + emailInfo);
		if (emailInfo.isEmpty()) {
			Assert.fail("No email is generated  for user ");
		}

	}

	/**
	 ** This method is to validate user details after creation
	 */

	public void validateUserDetails(String userFirstName, String userLastName) {
		if (userCount.getText().contains("0 entries"))
			Assert.fail("No User found with following name");

		if (status.getText().equalsIgnoreCase("Active") && firstNameInfo.getText().equalsIgnoreCase(userFirstName)
				&& lastNameInfo.getText().equalsIgnoreCase(userLastName))
			log.info("First name, Last name and status of user are as expected.");
		else
			Assert.fail("First name, Last name and status of user are not as expected.");

	}

	/**
	 ** This method is to upload csv file with user details
	 */
	public void uploadUserRequest() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();
		Thread.sleep(2000);
		yesRadioBtn.get(4).click();
		Thread.sleep(4000);
		upload.click();
		Thread.sleep(4000);
		header.get(1).click();
		searchDropdwn.sendKeys("FIRSTNAME");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		header.get(2).click();
		searchDropdwn.sendKeys("LASTNAME");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		header.get(3).click();
		searchDropdwn.sendKeys("STATUSKEY");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(4000);
		importBtn.click();
		Thread.sleep(4000);

	}


	/**
	 ** This method is to upload csv file termination users
	 */
	public void uploadUserRequestWithTerminationDetails()
			throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();
		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);
		header.get(1).click();
		searchDropdwn.sendKeys("FIRSTNAME");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(2).click();
		searchDropdwn.sendKeys("LASTNAME");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(3).click();
		searchDropdwn.sendKeys("STATUSKEY");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		Thread.sleep(3000);
		importBtn.click();
		Thread.sleep(2000);

	}

	public void uploadUserRequestWithUdateDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();
		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);
		header.get(1).click();
		searchDropdwn.sendKeys("FIRSTNAME");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(2).click();
		searchDropdwn.sendKeys("LASTNAME");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(3).click();
		searchDropdwn.sendKeys("STATUSKEY");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(5000);
		importBtn.click();
		Thread.sleep(2000);

	}

	public void uploadUserRequestForEmptyFile() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();

		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);
		System.out.println("***************" + noRecords.getText());
		if (noRecords.isDisplayed())
			log.info("Input CSV file has no user details ");
	}

	public void provideCSV() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\usersBulk.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	public void provideCSVForWorkFlow() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(4000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\WorkflowUserList.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
	}

	public void provideCSVForTwoLevelWorkFlow() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//TwoLevelWorkflowUserList.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
	}

	public void provideCSVWithUpdateDetails(String fileName) throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\" + fileName);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	public void provideCSVWithTerminationDetails(String fileName) throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\" + fileName);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	public void provideCSVWithManagerTerminationDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"\\C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\TerminationManager.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	public void provideCSVWithManagerActivationDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"\\C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\ActivationManager.csv");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	public void provideFiletherThanCSV() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\users1.xlt");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(3000);

		if (invalidFileType.isDisplayed()) {
			String error = invalidFileType.getText();
			log.info("****Invalid File Message****:" + error);
			log.info("****closeButton****");
			Thread.sleep(3000);
			closeButton.click();
			// Assert.fail(error);
		}
	}

	public void emptyCSVFileWithoutUserDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection("C:\\Users\\snigdha.ahmed\\Desktop\\UsersNoRecords.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);

	}

	public void navigateToUploadUserRequest() throws InterruptedException {
		Thread.sleep(1000);
		try {
			Home.click();
			Thread.sleep(2000);
			menu.click();
			search.sendKeys("Upload User Request");
			Thread.sleep(1000);
			uploadUser.click();
			Thread.sleep(1000);
		} catch (NoSuchElementException e) {
			log.info("Element is not found");

		}

	}

	public void validateCSVUserDetails(String userFirstName, String userLastName) {

		if (status.getText().equalsIgnoreCase("Active") && firstNameInfo.getText().equalsIgnoreCase(userFirstName)
				&& lastNameInfo.getText().equalsIgnoreCase(userLastName))
			log.info("First name, Last name and status of user are as expected.");
		else
			Assert.fail("First name, Last name and status of user are not as expected.");

	}
	public void approveRequest() throws InterruptedException, AWTException {
		Thread.sleep(5000);
		try {		

			driver.findElement(By.xpath("//button[@id='approverequestButton']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//*[@id='txmt']")).sendKeys("approve for test automation");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//button[@class='btn green' and @id='subcomall']")).click();
			Thread.sleep(5000);

		} catch (NoSuchElementException e) {
			log.info("Element is not found");

		}

	}


}