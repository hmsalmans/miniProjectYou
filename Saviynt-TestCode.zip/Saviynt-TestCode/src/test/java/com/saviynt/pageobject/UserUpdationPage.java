package com.saviynt.pageobject;

import java.awt.AWTException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.junit.Assert;

public class UserUpdationPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();
	public static String reqId="";
	public UserUpdationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	////Element Repository with element locators////
	@FindBy(xpath = "//a[@class='tooltip1']")
	public WebElement userLink;
	@FindBy(xpath = "//input[@id='middlename']")
	public WebElement middlename;
	@FindBy(xpath = "//input[@id='location']")
	public WebElement location;
	@FindBy(xpath = "//button[@id='updateButton']")
	public WebElement updateButton;
	@FindBy(xpath = "//td[8]")
	public WebElement city;
	@FindBy(xpath = "//a[@href='/ECM/users/show/3']")
	public WebElement manager;
	@FindBy(xpath = "//*[@id='leaveStatus']")
	public WebElement leaveStatus;
	@FindBy(xpath = "//*[@id='email']")
	public WebElement emailField;
	@FindBy(xpath = "//*[@id='managername']")
	public WebElement managerName;
	@FindBy(xpath = "//*[@class='btn blue readonlyrolebutton managerdiv']")
	public WebElement selectManger;
	@FindBy(xpath = "//*[@id='dtsearch_allusers']")
	public WebElement searchManger;
	@FindBy(xpath = "//*[@id='search_allusers']")
	public WebElement searchMangerbutton;
	@FindBy(xpath = "//input[contains(@label,'snigdha.ahmed')]")
	public WebElement selectMangerbutton;
	@FindBy(xpath = "//*[@id='managerbtn']")
	public WebElement mangerSubmitbutton;

	@FindBy(xpath = "//td[4]")
	public WebElement status;

	//////Users Page//////
	@FindBy(xpath = "//*[@id='arsReqApprovalColumn']")
	public WebElement coloumns;
	@FindBy(xpath = "//*[@id='usersList_column_toggler']//label[text()=' Job Code']")
	public WebElement jobCodeColoumn;

	/**
	 ** This method is to update user details
	 ** @param updateMiddleName
	 ** @param updateLocation
	 ** @param managerName
	 */

	public void updateUser(String updateMiddleName, String updateLocation) throws AWTException, InterruptedException {
		try {

			log.info("Middle name - " + updateMiddleName);
			log.info("Location - " + updateLocation);
			Thread.sleep(2000);
			userLink.click();
			Thread.sleep(2000);
			middlename.clear();
			middlename.sendKeys(updateMiddleName);
			Thread.sleep(2000);
			location.clear();
			location.sendKeys(updateLocation);
			Thread.sleep(4000);
			updateButton.click();
			Thread.sleep(2000);
			reqId=	driver.findElement(By.xpath("//tr[1]//td[1]")).getText().trim();
			log.info(reqId);
		} catch (Exception e) {
			Assert.fail("Update User has failed");

		}
	}

	/**
	 ** This method is to validate updated details of user
	 ** @param updateMiddleName
	 ** @param updateLocation
	 */
	public void validateUpdatedDetails(String updateMiddleName, String updateLocation) throws InterruptedException {
		try {
			userLink.click();
			driver.navigate().refresh();
			Thread.sleep(2000);
			log.info(middlename.getAttribute("Value"),location.getAttribute("Value") );
			if ((middlename.getAttribute("Value").equalsIgnoreCase(updateMiddleName))
					&& (location.getAttribute("Value").equalsIgnoreCase(updateLocation)))
				log.info("User is updated with provided details");
			else {
				log.info("Validation of Update user has been failed");
			}
		} catch (NoSuchElementException e) {
			log.info("Element is not found");

		}

	}


	/**
	 ** This method is to validate updated city
	 ** @param updatedCity
	 */
	public void validateUpdatedDetailsCity(String updateCity) throws InterruptedException {
		Thread.sleep(2000);
		if (city.getText().equalsIgnoreCase(updateCity))
			log.info("City has been updated successfully for the existing user");
		else
			Assert.fail("City hasn't been updated successfully for the existing user");

	}


	/**
	 ** This method is to validate updated leave status of user
	 ** @param user
	 ** @param status
	 */
	public void validateUpdatedDetailsStatus(String user,String Status) throws InterruptedException {
		try {
			Thread.sleep(2000);
			log.info("***Beginning*******");
			log.info("status:"+driver.findElement(By.xpath("//*[@id='usersList']//span[text()='"+Status+"']")).getText());
			if (driver.findElement(By.xpath("//*[@id='usersList']//span[text()='"+Status+"']")).getText().contains(Status)) 
			{
				log.info("status has been updated successfully to: "+Status+ "for the existing user: " +user);
			}else {
				Assert.fail("status hasn'y been updated successfully to: "+Status+ "for the existing user: " +user);
			}

		}catch(Exception e) {
			log.info(e);
		}
	}


	public void validateJobCodeDetails(String user,String jobCode) throws InterruptedException {
		Thread.sleep(2000);
		try {
			coloumns.click();
			Thread.sleep(1000);
			jobCodeColoumn.click();
			coloumns.click();
			if (driver.findElement(By.xpath("//*[@id='usersList']//td[text()='"+jobCode+"']")).getText().contains(jobCode)) 
			{
				log.info("status has been updated successfully to: "+jobCode+ "for the existing user: " +user);
			}else {
				Assert.fail("status hasn'y been updated successfully to: "+jobCode+ "for the existing user: " +user);
			}
		} catch (Exception e) {
			log.info(e);
		}
	}

	/**
	 ** This method is to update leave status of user
	 ** @param leaveStatusOfUser
	 */
	public void updateUserLeaveStatus(String leaveStatusOfUser) {
		try {
			Thread.sleep(2000);
			userLink.click();
			Thread.sleep(2000);
			emailField.clear();
			leaveStatus.clear();
			leaveStatus.sendKeys(leaveStatusOfUser);
			updateButton.click();
		} catch (Exception e) {
			log.info("Leave Update for the User has failed");

		}
	}

	/**
	 ** This method is to update manager of user
	 ** @param managerName
	 */
	public void updateManagerField(String managerName) {
		try {
			log.info("Updating the manger of the user");
			Thread.sleep(2000);
			userLink.click();
			Thread.sleep(2000);
			selectManger.click();
			searchManger.sendKeys(managerName);
			searchMangerbutton.click();
			Thread.sleep(1000);
			selectMangerbutton.click();
			Thread.sleep(1000);
			mangerSubmitbutton.click();

			updateButton.click();
			Thread.sleep(1000);

			log.info("Manager update has been done successfully");
		} catch (Exception e) {
			log.info("Manager Update for the User has failed");

		}

	}

}