package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.google.common.base.Function;
import io.cucumber.java.en.And;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import org.junit.Assert;
import com.google.common.base.Function;

public class RoleCreationPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger("RoleCreationPage");
	public static String taskId ="";

	public RoleCreationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

////Element Repository with element locators////
	@FindBy(xpath = "//*[@class = 'MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@placeholder ='Search']")
	public WebElement search;
	@FindBy(xpath = "//span[text() = 'Roles']")
	public WebElement role;
	@FindBy(xpath = "")
	public WebElement roleOwner;
	@FindBy(xpath = "//a[normalize-space(text())='Next']")
	public WebElement nextBtn;
	@FindBy(xpath = "(//a[@class='btn btn-primary'])[1]")
	public WebElement action;
	@FindBy(xpath = "(//a[@class='btn btn-primary'])[2]")
	public WebElement actionOnUserTab;
	@FindBy(xpath = "//div[@class='btn-group open']//ul/li[1]/a[2]")
	public WebElement createRole;
	@FindBy(id = "role_name")
	public WebElement roleNameField;
	@FindBy(id = "description")
	public WebElement description;
	@FindBy(id = "displayname")
	public WebElement roleDisplayname;
	@FindBy(xpath = "//select[@id='roletype']")
	public WebElement roleType;
	@FindBy(xpath = "(//*[@class='btn green'])[1]")
	public WebElement createBtn;
	@FindBy(xpath = "//span[text() ='Role Name Already Exists !']")
	public WebElement roleNameError;
	@FindBy(id = "dtsearch_roleList")
	public WebElement search_usersList;
	@FindBy(xpath = "(//*[@class='icon-search'])[2]")
	public WebElement searchButton;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement roleCount;
	@FindBy(xpath = "//div[@id='myDataTable2_info']")
	public WebElement entitlementCount;

	@FindBy(xpath = "//a[text()='Role Owners']")
	public WebElement roleOwners;
	@FindBy(xpath = "//*[@data-toggle='modal' and @href='#adRoleowner']")
	public WebElement addRoleOwners;
	@FindBy(xpath = "//*[@data-toggle='modal' and @href='#addUser']")
	public WebElement addUsers;

	@FindBy(xpath = "//a[@id='removebutton']")
	public WebElement removeRoleOwners;
	@FindBy(xpath = "//input[@class='uniform']")
	public WebElement checkBox;
	@FindBy(xpath = "//*[@id='mydatatableroleuser']//input")
	public WebElement checkBoxUser;
	@FindBy(xpath = "//button[@id='savebutton']")
	public WebElement saveRoleOwners;
	@FindBy(xpath = "(//*[@class='btn green' or text()='Save'])[6]")
	public WebElement saveUsers;
	@FindBy(xpath = "//a[text()='Versions']")
	public WebElement versions;
	@FindBy(xpath = "//a[text()='Groups']")
	public WebElement groups;
	@FindBy(xpath = "(//input[@class='form-control input-medium'])[2]")
	public WebElement searchRoleOwners;
	@FindBy(xpath = "//*[@id='dtsearch_mydatatableroleuser']")
	public WebElement searchUser;
	@FindBy(xpath = "//input[@class='uniform' and @value='407']")
	public WebElement checkRoleOwners;
	@FindBy(xpath = "//a[text()='Entitlements']")
	public WebElement entitlements;
	@FindBy(xpath = "//a[@class='btn btn-primary' and @ href='#addEntitlement1']")
	public WebElement addEntitlements;
	@FindBy(xpath = "//*[@id='dtsearch_myDataTableentvaltcode1']")
	public WebElement searchEntitlements;
	@FindBy(xpath = "//input[@id='intKey_2']")
	public WebElement checkEntitlements;
	@FindBy(xpath = "//a[@class='btn red ']")
	public WebElement removeEntitlements;
	@FindBy(xpath = "//*[@id='savebutton']")
	public WebElement saveEntitlements;
	@FindBy(xpath = "//a[@class='btn btn-xs red']")
	public WebElement discontinue;
	@FindBy(xpath = "//a[@id='sendForApproval']")
	public WebElement sendForApproval;
	@FindBy(xpath = "(//input[@class='form-control'])[12]")
	public WebElement maxTimeFrame;
	@FindBy(xpath = "(//*[@class='ui-tabs-anchor'])[3]")
	public WebElement roleOwnersTab;
	@FindBy(xpath = "(//*[@class='ui-tabs-anchor'])[4]")
	public WebElement usersTab;
	@FindBy(xpath = "(//*[@class='btn default  searchButt'])[2]")
	public WebElement searchOwnersButton;
	@FindBy(xpath = "	//*[@id='search_mydatatableroleuser']")
	public WebElement searchUsersButton;
	@FindBy(xpath = "//*[@id='search_myDataTableentvaltcode1']/i")
	public WebElement searchEntitlementButton;
	@FindBy(xpath = "//*[@class='icon-edit svyellow iconSVYNT-edit tooltips']")
	public WebElement editRole;
	@FindBy(xpath = "//*[@id='descriptionU']")
	public WebElement roleDescription;
	@FindBy(xpath = "//*[@id='updatebutton']")
	public WebElement roleUpdate;
	@FindBy(xpath = "//span[text()= 'Request History']")
	public WebElement requestHistory;	
	@FindBy(xpath = "//input[not(contains(disabled)]")
	public WebElement selectVersion;
	@FindBy(xpath = "//*[@id='busjustrole']")
	public WebElement justification;
	@FindBy(xpath = "//a[@id='sendForApprovalConfirm']")
	public WebElement approvalConfirm;
	@FindBy(xpath = "//*[@id='gritter-item-1']//div[2]")
	public WebElement requestId;
	@FindBy(xpath = "//*[@class='gritter-close']//div[2]")
	public WebElement gritterClose;

	@FindBy(xpath = "//div[@ class='bootbox-body']")
	public WebElement timeFrameError;


	//////////////pending approvals page//////////////


	@FindBy(xpath = "//div[contains(@class,'searchBox')]")
	public WebElement searchBox;
	@FindBy(xpath = "")
	public WebElement view ;
	@FindBy(xpath = "//button[contains(@class,' btn btn-sm green initialcls')]")
	public WebElement accept;
	@FindBy(xpath = "//button[contains(@class,'reject')]")
	public WebElement reject;
	@FindBy(xpath = "//a[contains(@class,'buttonaccept')]")
	public WebElement acceptAll;
	@FindBy(xpath = "//a[contains(@class,'buttonreject')]")
	public WebElement rejectAll;
	@FindBy(xpath = "//*[contains(@name,'mandatorycomment')]")
	public WebElement comment;
	@FindBy(xpath = "//*[contains(@class,'btn-success')]")
	public WebElement savecomment ;
	@FindBy(xpath = "//a[@class='btn blue']")
	public WebElement finalConfirm;

	///////////////////////////////////////role removal/////////////////////////////////////////////
	@FindBy(xpath = "//*[@id='roleList']//tbody//tr[1]//td[5]")
	public WebElement roleStatus;
	@FindBy(xpath = "//i[contains(@class,'delete')]")
	public WebElement deleteRole;
	@FindBy(xpath = "//div[@class='modal fade in']")
	public WebElement roleDeleteDialogBox ;
	@FindBy(xpath = "//button[@class='btn btn-success']")
	public WebElement proceed;

	////////////////////////////////////end user validation///////////////////////////	
	@FindBy(xpath = "//span[text()='Manage Roles']")
	public WebElement manageRole;
	@FindBy(xpath = "//span[text()='Create New Role']")
	public WebElement createNewRole;
	@FindBy(xpath = "//*[text() ='OOPS !']")
	public WebElement oopsError;

	///////////////////////////////////////////////
	@FindBy(xpath = "//span[@id='blankrolename']")
	public WebElement blankRolenameError;
	@FindBy(xpath = "//a[@class='btn green']")
	public WebElement next;
	@FindBy(xpath = "//button[@class='btn default closebutton']")
	public WebElement closeButton;
	@FindBy(xpath = "//a[@class='btn default button-previous']")
	public WebElement back;

	/////////////////////Groups////////////////////////
	@FindBy(xpath = "//*[text()=' Actions ']")
	public WebElement actions;
	@FindBy(xpath = "//i[@class='icon-plus']")
	public WebElement addChildRole;
	@FindBy(xpath = "//*[@id='dtsearch_addChildRole']")
	public WebElement searchChildRole;
	@FindBy(xpath = "//input[@name='rolekeyforchk']")
	public WebElement childsrolekeyCheck;
	@FindBy(xpath = "//*[@id='savebutton']")
	public WebElement saveButton;
	@FindBy(xpath = "//a[@id='removebutton']")
	public WebElement removeChildRole;
	@FindBy(xpath = "//span[text()='Add New Access']")
	public WebElement addNewAccess;
	@FindBy(xpath = "//input[@id='outlined-adornment-password']")
	public WebElement appSearchBox;
	@FindBy(xpath = "//div[@id='panel1a-header']")
	public WebElement app;
	@FindBy(xpath = "//span[text() ='Request New Account']")
	public WebElement requestNewAccount;
	@FindBy(xpath = "//input[@id='modify-account-name']")
	public WebElement accountName;
	@FindBy(xpath = "//span[text()='Review & Submit']")
	public WebElement reviewSubmit;
	@FindBy(xpath = "//div[@class='account-attributes row']")
	public WebElement appName;
	@FindBy(xpath = "//div[contains(@class,'upload-list-text')]")
	public WebElement comments;
	@FindBy(xpath = "//input[@type='checkbox' and @value='checkedC']")
	public WebElement checkbox;
	@FindBy(xpath = "//span[text()='Submit']")
	public WebElement submit;
	@FindBy(xpath = "/div[@class='next-approver']")
	public WebElement nextApprover;
	@FindBy(xpath = "//*[text()='Request New Account']")
	public WebElement requestNewAccess;
	@FindBy(xpath = "//span[text()='Request']")
	public WebElement request;
	@FindBy(xpath = "//*[text()='Select Access']")
	public WebElement selectAccess;
	@FindBy(xpath = "//*[@id='modify-account-name']")
	public WebElement accountName1;
	@FindBy(xpath = "//*[text()='Review & Submit']")
	public WebElement reviewAndSubmit;
	@FindBy(xpath = "//*[text()='Review']")
	public WebElement reviewHeader;
	@FindBy(xpath = "//*[@class='MuiIconButton-label']//input")
	public WebElement checkBox1;
	@FindBy(xpath = "//span[text()='Submit']")
	public WebElement submitFinal;
	@FindBy(xpath = "//*[text()='Request Approvals']")
	public WebElement requestApproval;
	@FindBy(xpath = "//h5[@class='mt-3']")
	//*[@class='header-title']
	public WebElement requestConfirmationMessage;
	@FindBy(xpath = "//*[text()='Request History']")
	public WebElement requestHistoryLink;
	@FindBy(xpath = "//span[text() ='Done']")
	public WebElement done;

	@FindBy(xpath = "//a[@class='tooltip1']")
	public WebElement userLink;
	@FindBy(xpath = "//a[contains(text(),'Roles')]")
	public WebElement rolesTab;

	@FindBy(xpath = "//a[contains(text(),'Role Details')]")
	public WebElement roleDetailsTab;
	@FindBy(xpath = "//*[@class = 'saviynt-logo-size']")
	public WebElement saviyntLogo;
	@FindBy(xpath = "//textarea[contains(@class,'inputMultiline')]")
    public WebElement busJustifcation;
    @FindBy(xpath = "//textarea[contains(@class,'nstanceCheckoutComment')]")
    public WebElement comments1;

	/** 
	 * This method is to navigate to Roles page 		     
	 */
	public void navigateToRolesPage() throws AWTException, InterruptedException {
		driver.navigate().refresh();
		Thread.sleep(2000);
		menu.click();
		search.sendKeys("Roles");
		Thread.sleep(2000);
		role.click();
		Thread.sleep(4000);
	}

	/** 
		     * This method is to create Role 
		     * @param roleName
		     * @param typeOfRole		     
		     */
	public void createRoles(String roleName, String typeOfRole) throws AWTException, InterruptedException {
		try {
			action.click();
			Thread.sleep(2000);
			createRole.click();
			Thread.sleep(1000);
			roleNameField.sendKeys(roleName);
			Select select = new Select(roleType);
			select.selectByVisibleText(typeOfRole);
			if (typeOfRole.contains("Emergency Access")) {
				maxTimeFrame.sendKeys("1");
			}

			Thread.sleep(1000);
			createBtn.click();

			Thread.sleep(15000);
		} catch (InterruptedException e) {
			log.info(roleName + " Role creation has been failed");
		}

	}
	/** 
	     * This method is to create Role 
	     * @param roleName
	     * @param typeOfRole		     
	     */
	public void createEmergencyRoles(String roleName, String typeOfRole) throws AWTException, InterruptedException {
		try {
			action.click();
			Thread.sleep(2000);
			createRole.click();
			Thread.sleep(1000);
			roleNameField.sendKeys(roleName);
			Select select = new Select(roleType);
			select.selectByVisibleText(typeOfRole);

			Thread.sleep(1000);
			createBtn.click();

			Thread.sleep(5000);
		} catch (InterruptedException e) {
			log.info(roleName + " Role creation has been failed");
		}

	}

	/** 
	     * This method is validate error message while creating role without providing role name
	     * @param roleName
	     * @param typeOfRole		     
	     */
	public void createNewRoleWithoutRolename() throws AWTException, InterruptedException {
		try {
			action.click();
			Thread.sleep(2000);
			createRole.click();
			Thread.sleep(1000);
			//roleNameField.sendKeys(roleName);

			Thread.sleep(1000);
			//next.click();
			createBtn.click();
			Thread.sleep(2000);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,-250)");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			log.info(" Role creation has been failed");
		}

	}

	/** 
	     * This method is validate error message while creating role with already existing role name
	     * @param roleName		     
	     */
	public void createNewRoleWithAlreadyExistingRolename(String roleName) throws AWTException, InterruptedException {
		try {
			Thread.sleep(1000);
			roleNameField.sendKeys(roleName);
			Thread.sleep(1000);
			//next.click();
			createBtn.click();
			Thread.sleep(2000);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,-250)");
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			log.info("validation of role creation with already existing role na has been failed");
		}
	}
	/** 
	     * This method is to create role
	     * @param roleName
	     * @param typeOfRole		     
	     */
	public void createNewRole(String roleName, String typeOfRole) throws AWTException, InterruptedException {
		try {

			Thread.sleep(1000);
			roleNameField.clear();
			roleNameField.sendKeys(roleName);

			Thread.sleep(1000);
			Select select = new Select(roleType);
			select.selectByVisibleText(typeOfRole);
			createBtn.click();
			Thread.sleep(15000);
		} catch (InterruptedException e) {
			log.info(roleName + " Role creation has been failed");
		}
	}


	public void ValidateCreatingNewRoles() throws AWTException, InterruptedException {
		try {
			Thread.sleep(2000);
			if(blankRolenameError.isDisplayed()) {
				log.info(blankRolenameError.getText());
			}else if(roleNameError.isDisplayed()) {
				log.info(roleNameError.getText());	
			}else if(timeFrameError.isDisplayed()) {
				log.info(timeFrameError.getText());
				closeButton.click();
			}
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			log.info("validation of creation has been failed");
		}
	}

	public void ValidateEmergencyRoles() throws AWTException, InterruptedException {
		try {
			if(timeFrameError.isDisplayed()) {
				log.info(timeFrameError.getText());
				closeButton.click();
			}
			Thread.sleep(2000);
		} catch (InterruptedException e) {
			log.info( "validation of emergency role creation without time frame has been failed");
		}
	}


	public void validateRoleCreation(String RoleName) throws AWTException, InterruptedException {
		try {
			if (roleCount.getText().contains("0 entries"))

				Assert.fail("No role found with following name");
			if (driver.findElement(By.xpath("//*[text()='" + RoleName + "']")).isDisplayed())
				log.info("Role is created");
		} catch (Exception e) {
			log.info("Fetching role count has been faile");
		}
	}

	public void searchRole(String roleName) throws InterruptedException {
		try {
			Thread.sleep(2000);
			search_usersList.clear();
			search_usersList.sendKeys(roleName);
			Thread.sleep(1000);
			searchButton.click();
			Thread.sleep(2000);

		} catch (Exception e) {
			log.info("Search role failed");

		}

	}


	public void editRole() throws InterruptedException {
		try {

			Thread.sleep(1000);
			editRole.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.info("Edit role has been failed");

		}

	}

	/** 
	     * This method is validate removal of role		     
	     */
	public void removeRole() throws InterruptedException {
		try {

			Thread.sleep(1000);
			if(roleStatus.getText().equalsIgnoreCase("Active")){
				log.info("deleting role");
				deleteRole.click();
				Thread.sleep(1000);
				proceed.click();
				Thread.sleep(1000);
			}else {
				Thread.sleep(1000);
				Assert.fail("Unable to delete role due to "+ roleStatus.getText());
			}

		} catch (Exception e) {
			log.info("Role removal has been failed");

		}

	}

	/** 
	     * This method is to validate role details		     
	     */
	public void navigateToRoleDetails() throws InterruptedException {
		try {

			Thread.sleep(1000);
			log.info("Navigating Role Details tab");
			//editRole.click();
			roleDetailsTab.click();


			Thread.sleep(2000);
		} catch (Exception e) {
			log.info("Navigation to Role Details has been failed");
		}

	}

	/** 
	     * This method is to update role
	     * @param displayName
	     * @param description		     
	     */
	public void updateRoleDetails(String displayName,String description) throws InterruptedException {
		try {

			Thread.sleep(1000);
			log.info("Updating Role Display name");
			Thread.sleep(1000);
			roleDisplayname.clear();
			roleDisplayname.sendKeys(displayName);
			roleDisplayname.click();
			Thread.sleep(1000);
			log.info("Updating Role Description");
			roleDescription.clear();
			roleDescription.sendKeys(description);
			roleUpdate.click();
			Thread.sleep(2000);
		} catch (Exception e) {
			log.info("Role update has been failed");
		}

	}

	/** 
	     * This method is to update role owner details 
	     * @param roleName
	     * @param owner	
	 * @param roleAction    
	     */

	public void updateRolesWithOwner(String RoleName, String owner, String roleAction) {
		try {
			Thread.sleep(1000);

			if(roleAction.equals("Removal")) {
				log.info("role owner removal");
				removeRoleOwner(owner);

			}else {
				roleOwnersTab.click();
				Thread.sleep(2000);
				action.click();
				Thread.sleep(1000);
				log.info("Adding role owner");
				addRoleOwners.click();
				Thread.sleep(2000);
				searchRoleOwners.clear();
				searchRoleOwners.sendKeys(owner);
				Thread.sleep(1000);
				searchOwnersButton.click();
				Thread.sleep(3000);

				checkBox.click();

				saveRoleOwners.click();
				log.info("save role owner");
				Thread.sleep(10000);

				driver.navigate().refresh();
				Thread.sleep(5000);

			}
		} catch (Exception e) {
			Assert.fail("Owner update has been failed ");
		}
	}

	/** 
	     * This method is to validate role owner removal
	     * @param removeRoleOwner	     
	     */

	public void removeRoleOwner(String owner) {
		try {
			Thread.sleep(1000);

			roleOwnersTab.click();
			Thread.sleep(2000);

			if (roleCount.getText().contains("0 entries"))
				Assert.fail("No User found with following name");

			int entriesinfo = roleCount.getText().length();
			log.info(entriesinfo);

			String entries = roleCount.getText().substring(17);

			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);

			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");

				log.info("***xpath of Security system:**** " + "//*[@id='myDataTableowner']//tbody//tr[" + i + "]//td[1]//div//span//input[@name='ownerkey']");
				String cell = driver.findElement(By.xpath("//tr[" + i + "]//td[2]")).getText();
				log.info(cell);
				if (owner.contains(cell)) {
					log.info("removing role owner " + owner);
					driver.findElement(By.xpath("//*[@id='myDataTableowner']//tbody//tr[" + i + "]//td[1]//div//span//input[@name='ownerkey']")).click();

					log.info("removing role owner " + owner);
					break;
				} 

			}





			removeRoleOwners.click();
			Thread.sleep(8000);
			driver.navigate().refresh();
		} catch (Exception e) {
			Assert.fail("Owner removal has been failed ");
		}
	}

	/** 
	     * This method is to validate entitlement removal
	     * @param entitlement		     
	     */

	public void removeEntitlement(String entitlement) {
		try {
			Thread.sleep(1000);

			entitlements.click();
			Thread.sleep(2000);

			driver.findElement(By.xpath("//div[@id='myDataTable2_info']")).getText();

			if (driver.findElement(By.xpath("//div[@id='myDataTable2_info']")).getText().contains("0 entries"))
				Assert.fail("No entitlement found with following name");

			int entriesinfo = driver.findElement(By.xpath("//div[@id='myDataTable2_info']")).getText().length();
			log.info(entriesinfo);

			String entries = driver.findElement(By.xpath("//div[@id='myDataTable2_info']")).getText().substring(17);

			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);

			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");

				log.info("***xpath of Security system:**** " + "//*[@id='myDataTable2']//tbody//tr[" + i + "]//td[1]/");
				String cell = driver.findElement(By.xpath("//tr[" + i + "]//td[2]")).getText();
				log.info(cell);
				if (entitlement.contains(cell)) {
					log.info("removing Entitlement " + entitlement);
					driver.findElement(By.xpath("//*[@id='myDataTable2']//tbody//tr[" + i + "]//td[1]//div//span//input[@name='childsaprolekey']")).click();

					log.info("removing Entitlement " + entitlement);
					break;
				} 

			}
			removeEntitlements.click();
			Thread.sleep(10000);
			driver.navigate().refresh();
			Thread.sleep(5000);

		} catch (Exception e) {
			Assert.fail("Child role removal has been failed ");
		}
	}


	/** 
	     * This method is to update role with entitlement
	     * @param roleName
	     * @param entitlement		     
	     */
	public void updateRolesWithEntitlement(String roleName, String entitlementName) throws InterruptedException {
		try {

			log.info("updating " + roleName + " with entitlement : " + entitlementName );
			Thread.sleep(10000);
			entitlements.click();
			Thread.sleep(3000);
			addEntitlements.click();
			Thread.sleep(1000);
			searchEntitlements.clear();
			searchEntitlements.sendKeys(entitlementName);
			Thread.sleep(4000);
			searchEntitlementButton.click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@name='newrolekey']")).click();

			Thread.sleep(3000);
			saveEntitlements.click();
			Thread.sleep(25000);
			driver.navigate().refresh();

		} catch (Exception e) {
			Assert.fail("Update Entitlement has been failed");

		}
	}


	public void updateRolesWithOutEntitlement(String RoleName, String EntitlementName) throws InterruptedException {
		try {

			Thread.sleep(1000);
			next.click();
			Thread.sleep(1000);
			next.click();

		} catch (Exception e) {
			Assert.fail("Update Entitlement has been failed");

		}
	}

	public void updateRolesStepsWithOutEntitlement(String RoleName, String EntitlementName) throws InterruptedException {
		try {

			Thread.sleep(1000);
			closeButton.click();
			Thread.sleep(1000);
			back.click();

		} catch (Exception e) {
			Assert.fail("Update Entitlement has been failed");

		}
	}

	public void isLoaded() throws Error {
		new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(30)).pollingEvery(Duration.ofSeconds(5))
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver webDriver) {
				WebElement element = saveEntitlements;
				System.out.println("Waiting for the element");
				return element != null && element.isDisplayed();
			}
		});
	}

	/** 
	     * This method is to navigate to versions tab 		     
	     */
	public void navigateToVersion() throws InterruptedException {
		try {
			Thread.sleep(5000);
			versions.click();
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			log.info("Navigation to versions tab has failed");
		}
	}

	/** 
	     * This method is to validate version discontinue		     
	     */

	public void discontinueVersion() throws InterruptedException {
		try {
			Thread.sleep(1000);
			discontinue.click();
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			log.info("Version discontinuation has failed");
		}	
	}

	public void validateDiscontinueStatus() throws InterruptedException {
		try {
			navigateToVersion();
			Thread.sleep(1000);
			log.info("role count" );
			log.info(roleCount.getText() );
			if (roleCount.getText().contains("0 entries"))
				Assert.fail("No User found with following name");

			int entriesinfo = roleCount.getText().length();
			log.info(entriesinfo);

			String entries = roleCount.getText().substring(17);

			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);

			log.info("********ROWs*******" + rows);

			log.info("***xpath of Security system:**** " + "//tr[" + rows + "]//td[5]");
			String status = driver.findElement(By.xpath("//*[@id='myDataTable13']//tbody//tr[" + rows + "]//td[5]")).getText();
			log.info("status of version : " + status );

			if(status.equals("Discontinued")) {
				log.info("version is discontinued");
			}else {
				Assert.fail("version is not discontinued");	
			}

		} catch (InterruptedException e) {
			log.info("validation of version status has failed");
		}		

	}
	/** 
	     * This method is to send version for approval		     
	     */

	public void sendVersionForApproval() throws InterruptedException {
		try {
			Thread.sleep(8000);
			if (roleCount.getText().contains(" 0 entries"))
				Assert.fail("No version found ");

			int entriesinfo = roleCount.getText().length();
			log.info(roleCount.getText());
			log.info(entriesinfo);
			String entries =null;
			if(entriesinfo == 29) {
				entries = roleCount.getText().substring(19);	
			}else
				entries = roleCount.getText().substring(17);

			//String entries = roleCount.getText().substring(17);

			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);

			log.info("********ROWs*******" + rows);


			if(rows>15) {
				int y = rows - 15 ;
				driver.findElement(By.xpath("//a[text()='2']")).click();
				Thread.sleep(4000);
				log.info("***xpath of Security system:**** " + "//tr[" +y+ "]//td[1]");
				driver.findElement(By.xpath("//*[@id='myDataTable13']//tbody//tr[" + y + "]//td[1]")).click();

			}else {

				log.info("***xpath of Security system:**** " + "//tr[" +rows+ "]//td[1]");
				driver.findElement(By.xpath("//*[@id='myDataTable13']//tbody//tr[" + rows + "]//td[1]")).click();
			}	
			sendForApproval.click();
			Thread.sleep(3000);
			justification.sendKeys("for test automation");
			Thread.sleep(1000);
			approvalConfirm.click();
			Thread.sleep(3000); 
			taskId = requestId.getText().replace("Status","").replace("Roles Sent for Approval", "").replace("Request ID = ", "").trim();

			log.info( taskId);

			Thread.sleep(10000);
		} catch (InterruptedException e) {
			log.info("seanding version for approval has failed");
		}	
	}

	/** 
	     * This method is to navigate to request history page	     
	     */

	public void navigateToRequestHistory() throws InterruptedException {
		Thread.sleep(1000);
		try {

			menu.click();
			search.sendKeys("Request History");
			Thread.sleep(1000);
			requestHistory.click();
			Thread.sleep(2000);
		} catch (NoSuchElementException e) {
			log.info("Navigation to request history page has failed");

		}

	}

	/** 
	     * This method is to search for request id
	     * @param id		     
	     */
	public void searchRequestId(String id) throws InterruptedException, AWTException {

		try {

			Thread.sleep(4000);
			searchBox.click();
			Thread.sleep(1000);

			Thread.sleep(2000);
			Robot rb = new Robot();
			StringSelection str = new StringSelection(taskId);

			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
			// press Contol+V for pasting
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			// release Contol+V for pasting
			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);
			// for pressing and releasing Enter
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			/*	searchBox.sendKeys("15233");
			Thread.sleep(1000);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);*/

			Thread.sleep(1000);
		} catch (NoSuchElementException e) {
			log.info("Searching request id has failed");

		}

	}

	public void viewRequest() throws InterruptedException, AWTException {
		Thread.sleep(1000);
		try {		
			view.click();
			Thread.sleep(1000);
		} catch (NoSuchElementException e) {
			log.info("view request has failed");

		}

	}

	/**
	 ** This method is to validate request approval     
	 */


	public void approveRequest() throws InterruptedException, AWTException {
		Thread.sleep(5000);
		try {		
			//accept.click();
			Thread.sleep(1000);
			comment.sendKeys("approve for test automation");
			savecomment.click();
			Thread.sleep(1000);
			acceptAll.click();
			Thread.sleep(2000);
			finalConfirm.click();
		} catch (NoSuchElementException e) {
			log.info("approving request has failed");

		}

	}

	/**
	 ** This method is to validate request rejection   
	 */

	public void rejectRequest() throws InterruptedException, AWTException {
		Thread.sleep(5000);
		try {
			Thread.sleep(3000);
			log.info("Rejecting request");
			//reject.click();
			Thread.sleep(1000);
			comment.sendKeys("reject for test automation");
			savecomment.click();
			Thread.sleep(1000);
			rejectAll.click();
			Thread.sleep(2000);
			finalConfirm.click();
		} catch (NoSuchElementException e) {
			log.info("Rejecting request has failed");

		}

	}



	public void validateRoleOwnerUpdate(String roleOwner, String roleOwnerAction, String approvalAction) {
		try {
			Thread.sleep(1000);
			//editRole.click();
			Thread.sleep(1000);
			roleOwnersTab.click();
			Thread.sleep(2000);
			if (roleCount.getText().contains("0 entries")) {
				log.info("No User found with following name");
				if(roleOwnerAction.equals("add")&& approvalAction.equalsIgnoreCase("reject")||roleOwnerAction.equals("remove")&& approvalAction.equalsIgnoreCase("approve")) {
					log.info("role owner update is as expected");



				}else if(roleOwnerAction.equals("add")&& approvalAction.equalsIgnoreCase("approve")||roleOwnerAction.equals("remove")&& approvalAction.equalsIgnoreCase("reject")) {

					Assert.fail("role owner update is not as expected");

				}
			}else {
				int entriesinfo = roleCount.getText().length();
				log.info(entriesinfo);

				String entries = roleCount.getText().substring(17);

				String finalEntries2 = entries.replace("entries", " ").trim();
				log.info("No of rows " + finalEntries2);
				int rows = Integer.valueOf(finalEntries2);

				log.info("********ROWs*******" + rows);

				for (int i = 1; i <= rows; i++) {
					log.info("Before For loop");

					log.info("***xpath of Security system:**** " + "//tr[" + i + "]//td[2]");
					String cell = driver.findElement(By.xpath("//tr[" + i + "]//td[2]")).getText();
					//log.info("Name of security system: " + cell);

					if(roleOwnerAction.equals("add")&& approvalAction.equalsIgnoreCase("reject")||roleOwnerAction.equals("remove")&& approvalAction.equalsIgnoreCase("approve")) {
						log.info("validation of role owner reject");
						if (roleOwner.contains(cell)) {
							Assert.fail("role owner update is not as expected");
							break;
						} 

					}else if(roleOwnerAction.equals("add")&& approvalAction.equalsIgnoreCase("approve")||roleOwnerAction.equals("remove")&& approvalAction.equalsIgnoreCase("reject")) {

						if (roleOwner.contains(cell)) {
							log.info("role owner is updated as " + roleOwner);
							break;
						} 				
					}
				}
			}
			Thread.sleep(12000);
		} catch (Exception e) {
			Assert.fail("Owner update validation has been failed ");
		}
	}

	public void validateRoleDeactivation() {
		try {
			Thread.sleep(1000);

			if (roleStatus.getText().equalsIgnoreCase("Inactive"))
				log.info("role has been removed successfully");
			else
				Assert.fail("role removal has been failed");

		} catch (Exception e) {
			Assert.fail("role removal has been failed ");
		}
	}

	public void validateRoleModification(String displayName, String description) {
		try {
			Thread.sleep(3000);
			log.info( displayName + " " +roleDisplayname.getAttribute("Value") );
			log.info(description + " " + roleDescription.getAttribute("Value") );
			log.info("role has been modified successfully");

		} catch (Exception e) {
			Assert.fail("role modification has been failed ");
		}
	}

	public void validateThatRoleIsNotModified(String displayName, String description) {
		try {
			Thread.sleep(1000);
			roleDetailsTab.click();
			Thread.sleep(1000);

			if (!(roleDisplayname.getAttribute("Value").equalsIgnoreCase(displayName) && roleDescription.getAttribute("Value").equalsIgnoreCase(description)))
				log.info("role has not been modified as expected");
			else
				Assert.fail("role modification has been done eveb after discontinuing version");

		} catch (Exception e) {
			Assert.fail("role modification has been failed ");
		}
	}

	public void navigateToManageRolesPage() throws InterruptedException {
		try {
			menu.click();
			Thread.sleep(2000);
			search.sendKeys("Manage Roles");
			Thread.sleep(1000);
			manageRole.click();
			Thread.sleep(5000);
			log.info("User is on Manage Roles");


		} catch (Exception e) {
			Assert.fail("Navigation to Manage Roles has failed ");

		}
	}
	public void navigateToCreateNewRolesPage() throws InterruptedException {
		try {

			menu.click();
			Thread.sleep(2000);
			search.sendKeys("Create New Role");
			Thread.sleep(1000);
			createNewRole.click();
			Thread.sleep(5000);
			log.info("User is on Create New Roles");


		} catch (Exception e) {
			Assert.fail("Navigationto Create New Roles page has failed ");

		}
	}
	public void validateNoAccessForEndUser() throws InterruptedException {
		try {

			if(oopsError.isDisplayed())				
				log.info(oopsError.getText() + "You dont have access");


		} catch (Exception e) {
			Assert.fail("Validating as end user has failed");

		}
	}

	public void validateEntitlementUpdate(String entitlement, String roleAction,String approvalAction) {
		try {
			Thread.sleep(1000);
			//editRole.click();
			Thread.sleep(1000);
			entitlements.click();
			Thread.sleep(2000);
			if (entitlementCount.getText().contains(" 0 entries")) {
				log.info("No Entitlement found ");
				if(roleAction.equals("Removal")&&approvalAction.equals("approve")||roleAction.equals("add")&&approvalAction.equals("reject")) {

					log.info("entitlement is updated as expected");

				}else if(roleAction.equals("Removal")&&approvalAction.equals("reject")||roleAction.equals("add")&&approvalAction.equals("approve")) {

					Assert.fail("entitlement is not updated as expected");

				}
			}else {

				int entriesinfo = entitlementCount.getText().length();
				log.info(entriesinfo);

				String entries = entitlementCount.getText().substring(17);

				String finalEntries2 = entries.replace("entries", " ").trim();
				log.info("No of rows " + finalEntries2);
				int rows = Integer.valueOf(finalEntries2);

				log.info("********ROWs*******" + rows);

				for (int i = 1; i <= rows; i++) {
					log.info("Before For loop");

					log.info("***xpath of Security system:**** " + "//tr[" + i + "]//td[2]");
					String cell = driver.findElement(By.xpath("//tr[" + i + "]//td[2]")).getText();
					//log.info("Name of security system: " + cell);

					if(roleAction.equals("Removal")&&approvalAction.equals("approve")||roleAction.equals("add")&&approvalAction.equals("reject")) {
						log.info("validation of role owner Removal");
						if (entitlement.equalsIgnoreCase(cell)) {
							Assert.fail("entitlement is not removed");
							break;
						} else
							log.info("Entitlement is updated as expected");

					}else if(roleAction.equals("Removal")&&approvalAction.equals("reject")||roleAction.equals("add")&&approvalAction.equals("approve")) {

						if (entitlement.equalsIgnoreCase(cell)) {
							log.info("entitlement is updated as " + entitlement);
							break;
						} 
						else
							log.info("Entitlement is not updated as expected");
					}
				}
			}
			Thread.sleep(12000);
		} catch (Exception e) {
			Assert.fail("entitlement update validation has been failed ");
		}
	}
	public void updateRolesWithGroup(String group) throws InterruptedException {
		try {

			Thread.sleep(10000);
			groups.click();
			Thread.sleep(3000);
			actions.click();
			Thread.sleep(1000);
			addChildRole.click();
			Thread.sleep(1000);
			searchChildRole.clear();
			searchChildRole.sendKeys(group);
			Thread.sleep(4000);
			Robot rb = new Robot();

			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			childsrolekeyCheck.click();
			Thread.sleep(3000);
			saveButton.click();
			Thread.sleep(15000);
			driver.navigate().refresh();
			Thread.sleep(3000);

		} catch (Exception e) {
			Assert.fail("Update group has been failed");

		}
	}

	/**
	 * This method is to remove childrole from role
	 * @param childRole  
	 */

	public void removeGroup(String childRole) throws InterruptedException {
		try {

			Thread.sleep(10000);
			groups.click();
			Thread.sleep(3000);
			if (roleCount.getText().contains("0 entries"))
				Assert.fail("No child role found with following name to remove");

			int entriesinfo = roleCount.getText().length();
			log.info(entriesinfo);

			String entries = roleCount.getText().substring(17);

			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);

			log.info("********ROWs*******" + rows);

			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");

				log.info("*** xpath of child role : **** " + "//*[@id='myDataTable7']//tbody//tr[" + i + "]//td[2]//a");
				String cell = driver.findElement(By.xpath("//*[@id='myDataTable7']//tbody//tr[" + i + "]//td[2]//a")).getText();
				//log.info("Name of security system: " + cell);


				if (childRole.equalsIgnoreCase(cell)) {
					driver.findElement(By.xpath("//*[@id='myDataTable7']//tbody//tr[" + i + "]//td[1]")).click();
				} 

			}
			removeChildRole.click();
			Thread.sleep(10000);
			driver.navigate().refresh();
			Thread.sleep(3000);


		} catch (Exception e) {
			Assert.fail("Update child role has been failed");

		}
	}
	/**
	 * This method is to update role with childrole
	 * @param childRole
	 * @param roleAction
	 * @param approvalAction   
	 */
	public void validateChildRoleUpdate(String childRole, String roleAction, String approvalAction) {
		try {
			Thread.sleep(1000);

			Thread.sleep(1000);
			groups.click();
			log.info("clicked on groups");
			Thread.sleep(4000);
			if (driver.findElement(By.xpath("//div[@id='myDataTable7_info']")).getText().contains(" 0 entries")) {
				log.info("No child role found");

				if(roleAction.equals("Removal")&&approvalAction.equals("approve")||roleAction.equals("add")&&approvalAction.equals("reject")) {

					log.info("child role is updated as expected");

				} else if(roleAction.equals("Removal")&&approvalAction.equals("reject")||roleAction.equals("add")&&approvalAction.equals("approve")) {

					Assert.fail("child role is not updated as expected");

				}
			}else {

				int entriesinfo = driver.findElement(By.xpath("//div[@id='myDataTable7_info']")).getText().length();
				log.info(entriesinfo);

				String entries = entitlementCount.getText().substring(17);

				String finalEntries2 = entries.replace("entries", " ").trim();
				log.info("No of rows " + finalEntries2);
				int rows = Integer.valueOf(finalEntries2);

				log.info("********ROWs*******" + rows);

				for (int i = 1; i <= rows; i++) {
					log.info("Before For loop");

					log.info("*** xpath of child role : **** " + "//*[@id='myDataTable7']//tbody//tr[" + i + "]//td[2]//a");
					String cell = driver.findElement(By.xpath("//*[@id='myDataTable7']//tbody//tr[" + i + "]//td[2]//a")).getText();
					log.info("Name of child role : " + cell);

					if(roleAction.equals("Removal")&&approvalAction.equals("approve")||roleAction.equals("add")&&approvalAction.equals("reject"))  {
						log.info("validation of child role update");
						if (childRole.equalsIgnoreCase(cell)) {
							log.info("childRole is not removed");
							Assert.fail("childRole is not removed");
							break;
						} 
						else
							log.info("Child role is updated as expected");

					}else if(roleAction.equals("Removal")&&approvalAction.equals("reject")||roleAction.equals("add")&&approvalAction.equals("approve")) {

						if (childRole.equalsIgnoreCase(cell)) {
							log.info("child role is added " + childRole);
							break;
						} 	else
							log.info("child role is not updated as expected");			
					}
				}}
			Thread.sleep(12000);
		} catch (Exception e) {
			Assert.fail("child role update validation has been failed ");
		}
	}

	public String searchEndpointToRequestAccess(String role) throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			addNewAccess.click();
			Thread.sleep(2000);
			appSearchBox.sendKeys(role);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			log.info("appSearchBox");
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + role + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(role)) {
					links.get(j).click();
					Thread.sleep(3000);
					log.info("requestNewAccess");
					request.click();
					log.info("requestNewAccess");
					Thread.sleep(1000);
					done.click();
					Thread.sleep(1000);
					reviewAndSubmit.click();
					Thread.sleep(1000);
					if (reviewHeader.getText().contains("Review")) {
						log.info("User is on the Review page with details of role");
						Thread.sleep(1000);
						checkBox1.click();
						log.info("");
						Thread.sleep(1000);
						submitFinal.click();
						log.info("User submits the access request with all details");
						Thread.sleep(5000);
						if (requestConfirmationMessage.getText().contains("Confirmation")) {
							log.info("%%%%confirmaion%%%%:"+requestConfirmationMessage.getText());
							log.info("Request New access for the user is completed: " + role);

						}
					}
				}

			}





		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestIdDetails=requestConfirmationMessage.getText();
		return requestIdDetails;

	} 

	public String searchEndpointToRequestAccessForRole(String role) throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			addNewAccess.click();
			Thread.sleep(2000);
			appSearchBox.sendKeys(role);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(8000);
			log.info("appSearchBox");
			List<WebElement> links = driver.findElements(By.xpath("//*[text()= 'Enterprise Role 9 Display']"));
			log.info("links");
			log.info(links);
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase("Enterprise Role 9 Display")) {
					log.info(role);
					links.get(j).click();
					Thread.sleep(6000);
					request.click();
					Thread.sleep(6000);
					//log.info("Begin Java executor");
					//WebElement element = driver.findElement(By.xpath("//input[contains(@class, 'SlimSelect_manualInput')]"));
					//JavascriptExecutor jse = (JavascriptExecutor)driver;
					//jse.executeScript("arguments[0].value='3:42pm'", element);
					//log.info("End Java executor");
					//driver.findElement(By.xpath("(//*[@role = 'presentation'])[3]")).click();
					//try {
					log.info("Begin keyword");
					driver.findElement(By.xpath("//input[contains(@class, 'SlimSelect_manualInput')]")).sendKeys(Keys.ARROW_LEFT);
					driver.findElement(By.xpath("//input[contains(@class, 'SlimSelect_manualInput')]")).sendKeys(Keys.ARROW_LEFT);
					driver.findElement(By.xpath("//input[contains(@class, 'SlimSelect_manualInput')]")).sendKeys(Keys.BACK_SPACE);
					log.info("end keyword");
					//}catch(Exception e) {
					//	log.info("error:"+e);
				//	}
					
					//driver.findElement(By.xpath("(//*[@role = 'presentation'])[3]")).se
					//rb.keyPress(KeyEvent.VK_BACK_SPACE);
					/*
					DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
					Calendar cal = Calendar.getInstance();
					System.out.println(dateFormat.format(cal.getTime()));
					log.info(    driver.findElement(By.xpath("//input[contains(@class, 'SlimSelect_manualInput')]")).getAttribute("Value"));
					
					driver.findElement(By.xpath("//input[contains(@class, 'SlimSelect_manualInput')]")).clear();
					driver.findElement(By.xpath("//input[contains(@class,'SlimSelect_manualInput')]")).sendKeys(dateFormat.format(cal.getTime()));
					Thread.sleep(4000);
					*/
					
					busJustifcation.sendKeys("test automation");
					done.click();
					Thread.sleep(1000);
					reviewAndSubmit.click();
					Thread.sleep(1000);
					log.info("requestNewAccess");
					Thread.sleep(1000);
					if (reviewHeader.getText().contains("Review")) {
						log.info("User is on the Review page with details of role");
						Thread.sleep(1000);
						comments1.sendKeys("test automation");
						Thread.sleep(1000);
						checkBox1.click();
						log.info("submitting request");
						Thread.sleep(1000);
						submitFinal.click();
						log.info("User submits the access request with all details");
						Thread.sleep(5000);
						if (requestConfirmationMessage.getText().contains("Confirmation")) {
							log.info("%%%%confirmaion%%%%:"+requestConfirmationMessage.getText());
							log.info("Request New access for the user is completed: " + role);
						}
					}
				}

			}



		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestIdDetails=requestConfirmationMessage.getText();
		String[] splited = requestIdDetails.split("\\s+");
		log.info("****RequestID created: " + splited[1]);
		taskId= splited[1];
		log.info( taskId);
		return requestIdDetails;
	} 


	public void validateRoleAccess(String user, String role) throws InterruptedException {
		try {

			userLink.click();
			rolesTab.click();
			Thread.sleep(1000);
			if (driver.findElement(By.xpath("//*[text()='" + role + "']")).getText().contains(role))
				log.info("New Account has been successfully for the user: " + user + " And to the security system: "
						+ role);
			else if (roleCount.getText().contains("0 entries"))
				Assert.fail("New Account has been successfully for the user: " + user + " And to the security system: "
						+ role);

		} catch (NoSuchElementException e) {
			Assert.fail("Validate role access has failed");

		}

		Thread.sleep(1000);
	}

	/**
	 ** This method is to validate create new role is not available for End User    
	 */

	public void validateEndUsersAccessToCreateNewRole() throws InterruptedException {
		try {
			Thread.sleep(2000);
			menu.click();
			List<WebElement> tabs = driver.findElements(By
					.xpath("//*[@class='MuiList-root left-menu left-menu-sidebar MuiList-dense MuiList-padding']//li"));
			log.info("tab size:" + tabs.size());
			for (int i = 0; i < tabs.size(); i++) {
				Thread.sleep(2000);
				log.info("List of tabs: " + tabs.get(i).getText());
				if (tabs.get(i).getText().contains("Create New Role")) {
					log.info("End user has access to Create New Role Tab");
					Assert.fail("End user has access to Create New Role Tab");
					break;
				} else {
					log.info("End User doesn't have permission to Create New Role ");
					Thread.sleep(1000);
					saviyntLogo.click();
					break;

				}
			}
			Thread.sleep(2000);

		}catch (NoSuchElementException e) {
			Assert.fail("Validate role access has failed");

		}
	}



}