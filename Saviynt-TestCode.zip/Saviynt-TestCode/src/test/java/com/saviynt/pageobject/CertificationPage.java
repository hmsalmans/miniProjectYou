package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.time.Duration;
import org.testng.Assert;
import org.openqa.selenium.JavascriptExecutor;
import java.time.LocalDate;
import java.util.Date;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class CertificationPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();
	SoftAssert softAssert = new SoftAssert();

	public CertificationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

////Element Repository with element locators////
	@FindBy(xpath = "//*[@class='MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@type ='text']")
	public WebElement search;
	@FindBy(xpath = "//span[text() ='Campaign']")
	public WebElement campaign;
	@FindBy(xpath = "//input[@id ='dtsearch_myDataTable']")
	public WebElement searchBox;
	@FindBy(xpath = "//td[3]")
	public WebElement campaignName;
	@FindBy(xpath = "//a[contains(text() ,'Ready to Submit Certification') or contains(text() ,'Start Certification') or contains(text() ,'Resume Certification') ]")
	public WebElement startCertification;
	@FindBy(xpath = "//a[contains(text() ,'Ready to Submit Certification')]")
	public WebElement startquarterlyCertification;
	@FindBy(xpath = "//i[contains(@class ,'activate')]")
	public WebElement activate;
	@FindBy(xpath = "//input[@id ='dtsearch_userListDataTable']")
	public WebElement searchUser;
	@FindBy(xpath = "//input[@id ='dtsearch_certificationDetailsList']")
	public WebElement searchUserToCertify;

	@FindBy(xpath = "//*[@id='dtsearch_myDataTable']")
	public WebElement searchCampaign;
	@FindBy(xpath = "//*[@id='search_myDataTable']")
	public WebElement clickSearchedCampaign;
	@FindBy(xpath = "//*[@id='myDataTable']/tbody/tr[@class='odd']/td[3]/a")
	public WebElement changeOfPostionCampaign;
	@FindBy(xpath = "//*[@id='myDataTable_info']")
	public WebElement countOfCampaing;
	//////////////////////////////// employment status/////////////////
	@FindBy(xpath = "//div[@id='myDataTable15_info']")
	public WebElement entCount;
	@FindBy(xpath = "(//*[@class='select2-arrow'])[3]")
	public WebElement selectStatusdrpDown;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement searchStatus;
	@FindBy(xpath = "//*[@class='select2-match']")
	public WebElement selectStatus;
	@FindBy(xpath = "//a[@class='active-status']")
	public WebElement userStatus;
	@FindBy(xpath = "//div[contains(text(), 'Works For Me')]")
	public WebElement worksForMe;
	@FindBy(xpath = "//div[contains(text(), 'Does Not Work For Me')]")
	public WebElement doesNotWorksForMe;
	@FindBy(xpath = "//div[contains(text(), 'Terminated')]")
	public WebElement terminated;
	@FindBy(xpath = "//div[contains(text(), 'Extend End Date')]")
	public WebElement extendEndDate;
	@FindBy(xpath = "//a[@id='nextbutton']")
	public WebElement nextButton;
	@FindBy(xpath = "//*[@id='finishAccessReviewBtn']")
	public WebElement finish;
	@FindBy(xpath = "//td[7]")
	public WebElement systemName;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement userCount;
	@FindBy(xpath = "//button[text()='Close']")
	public WebElement close;
	@FindBy(xpath = "//span[text()='Back']")
	public WebElement back;
	@FindBy(xpath = "//input[@name='eSignUsername']")
	public WebElement username;
	@FindBy(xpath = "//input[@name='eSignPassword']")
	public WebElement password;
	@FindBy(xpath = "//input[@id='eSignTnC']")
	public WebElement eSignCheck;
	@FindBy(xpath = "//a[@id='addSignaturebtn']")
	public WebElement addSign;
	@FindBy(xpath = "//span[@id='eSignPasswordError']")
	public WebElement eSignError;
	@FindBy(xpath = "//div[text()='Please accept terms and conditions']")
	public WebElement checkError;
	@FindBy(xpath = "//button[@class='btn default closebutton']")
	public WebElement closebutton;
	// @FindBy(xpath = "//*[@id='dcoments']")
	@FindBy(xpath = "//*[@class='form-control dcomentsid']")
	public WebElement commentBox;
	@FindBy(xpath = "(//button[@value='Yes'])[2]")
	public WebElement yes;
	@FindBy(xpath = "//a[text()='Fully Executed Certification [100%]']")
	public WebElement fullyExecuted;
	@FindBy(xpath = "//*[@id='ui-id-3']")
	public WebElement certificationCompletePopUp;
	@FindBy(xpath = "//*[@class='modal-header']//h3")
	public WebElement certificationCompletePopUpTitle;
	@FindBy(xpath = "//div[contains(@class,'opened-dialogs')]//div[@class='modal-header']//h4")
	public WebElement certificationInCompletePopUpTitle;
	@FindBy(xpath = "//*[@class='modal-footer']//h4")
	public WebElement lockCeritificationConfirmationTitle;
	@FindBy(xpath = "//input[@id='dtsearch_userListDataTable']")
	public WebElement search_usersList;
	@FindBy(xpath = "//span[text()='Search']")
	public WebElement searchButton;
	@FindBy(xpath = "//div[@id='s2id_statustype']")
	public WebElement statusType;
	@FindBy(xpath = "///div[text()='All']")
	public WebElement allTypes;
	/////////////////extend end date//////////////////////
	@FindBy(xpath = "//*[@id='comments']")
	public WebElement comments;

	@FindBy(xpath = "//input[@id='conditionalEnddate']")
	public WebElement endDate;
	@FindBy(xpath = "//button[@id='submitdate']")
	public WebElement submitDate ;
	@FindBy(xpath = "//tr[1]//td[10]")
	public WebElement updatedExtendDate ;
	//////////////////Doesnot works for me////////////////
	@FindBy(xpath = "//*[text()='Add Certifier']")
	public WebElement addCertifier;
	@FindBy(xpath = "//input[@id='dtsearch_allusersofloggedmanager']")
	public WebElement searchManager;
	@FindBy(xpath = "//*[@id='search_allusersofloggedmanager']//i[@class='icon-search']")
	public WebElement searchIcon;
	@FindBy(xpath = "//input[@name='bpowner']")
	public WebElement radioBtn;
	@FindBy(xpath = "//button[@id='submitbtn']")
	public WebElement submitBtn ;
	@FindBy(xpath = "//i[@class='icon-search']")
	public WebElement searchbtn;
	//////////////////////////////////////////reassign///////////////////////////////////////////
	@FindBy(xpath = "//input[@id='showUserable']")
	public WebElement checkBox;
	@FindBy(xpath = "//div[@class='bootbox-body']")
	public WebElement error;
	@FindBy(xpath = "//button[@class='btn default closebutton']")
	public WebElement errorClose ;
	@FindBy(xpath = "//button[@class='btn btn-default close1']")
	public WebElement addCertifierClose ;

	/////////////Role owner campaign///////////////////
	@FindBy(xpath = "//input[@id='dtsearch_myDataTable']")
	public WebElement searchRole;
	@FindBy(xpath = "//i[contains(@class, 'svgreen')]")
	public WebElement belongsToMe;
	@FindBy(xpath = "//i[contains(@class, 'revoke')]")
	public WebElement doesNotBelongsToMe;
	@FindBy(xpath = "//i[contains(@class, 'discontinue')]")
	public WebElement decommission;
	@FindBy(xpath = "//a[contains(text(), 'Users')]")
	public WebElement users;
	@FindBy(xpath = "//input[contains(@id, 'dtsearch_myDataTable14')]")
	public WebElement searchUsers;
	@FindBy(xpath = "//*[@id='finishAccessReviewButton']")
	public WebElement finishAccess;
	@FindBy(xpath = "//*[contains(text(),'Do you want to lock the Certification?')]")
	public WebElement lockConfimation;
	@FindBy(xpath = "//button[@value='Yes']")
	public WebElement yesBtn;
	@FindBy(xpath = "//*[@id='ui-id-1']//div//h4[text()='Do you want to lock the Certification?']")
	public WebElement lockConfirmation;
	@FindBy(xpath = "//div[@class='modal-footer']//button[@value='Yes']")
	public WebElement yesButton;
	@FindBy(xpath = "//span[text()='Back']")
	public WebElement backBtn;
	@FindBy(xpath = "(//*[@class='modal-body'])[2]")
	public WebElement certificationPopUp;
	@FindBy(xpath = "//input[@id='dtsearch_roleList']")
	public WebElement search_roleList;
	@FindBy(xpath = "(//*[@class='ui-tabs-anchor'])[4]")
	public WebElement usersTab;
	@FindBy(xpath = "//div[@id='myDataTableroleuser_info']")
	public WebElement userinfo;
	//////Change of position/////
	@FindBy(xpath = "//*[@id='userListDataTable']//tbody//td[10]")
	public WebElement totalUserAccount;
	@FindBy(xpath = "//*[@id='s2id_statustype']")
	public WebElement showAllCampaign;
	@FindBy(xpath = "//*[@id='select2-drop']//input")
	public WebElement showAllTextField;
	@FindBy(xpath = "//a[contains(text(), 'Associated Entitlements')]")
	public WebElement entitlements;
	@FindBy(xpath = "//input[contains(@id, 'dtsearch_myDataTable15')]")
	public WebElement searchEntitlements;
	///////Search user from the Filter option on Certification page
	@FindBy(xpath = "//a[text()='Show Filters']")
	public WebElement showFilters;
	@FindBy(xpath = "//*[@class='panel-group accordion compunentAccord']//div[@id='dt_USERNAME' or @id='dt_User_FIRSTNAME']")
	public WebElement userNameFilter;
	@FindBy(xpath = "//*[@id='search_USERNAME' or @id='search_User_FIRSTNAME']")
	public WebElement searchUserNameField;
	@FindBy(xpath = "//*[@id='filteredValue']//a")
	public WebElement clearAll;
	@FindBy(xpath = "//a[text()='Hide Filter']")
	public WebElement hideFilters;
	@FindBy(xpath = "//*[@id='campaignProgressRefresh']")
	public WebElement refreshProgressCertification;
	@FindBy(xpath = "//*[@class='btn default closebutton']")
	public WebElement securityManagerPopUpclose;
	//////Ceritify user after selecting from filter option on certification page
	@FindBy(xpath = "(//*[@id='uniform-selectAll'])[1]")
	public WebElement selectAllCheckbox;
	@FindBy(xpath = "//*[@id='s2id_attestationBulk']//a/span")
	public WebElement selectedActionDropDown;
	@FindBy(xpath = "//*[@id='select2-drop']//input")
	public WebElement searchSelectedActionDropDown;
	@FindBy(xpath = "//*[@id='confirmBulk']//div//a")
	public WebElement confirmBulk;

	/**
	 ** This method is to navigate to campaign page
	 */
	public void navigateToCampaign() throws InterruptedException {
		try {
			Thread.sleep(2000);
			menu.click();
			search.sendKeys("Campaign");
			Thread.sleep(1000);
			campaign.click();
			Thread.sleep(1000);
			log.info("User is on  campaign page");

		} catch (Exception e) {
			//Assert.fail("Navigation has failed to  campaign page");
			log.info("Navigation has failed to  campaign page" +e);

		}
	}

	/**
	 ** This method is to search certification
	 ** @param certificationName
	 */
	public void searchCertification(String certificationName) throws InterruptedException {
		try {
			Thread.sleep(4000);
			log.info("clicking on status type");
			statusType.click();
			log.info("Selecting status type to All");
			StringSelection str = new StringSelection("All");
			Robot rb = new Robot();
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
			// press Contol+V for pasting
			rb.keyPress(KeyEvent.VK_CONTROL);
			rb.keyPress(KeyEvent.VK_V);
			Thread.sleep(1000);
			// release Contol+V for pasting
			rb.keyRelease(KeyEvent.VK_CONTROL);
			rb.keyRelease(KeyEvent.VK_V);
			// for pressing and releasing Enter
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
			log.info("Selected status type to All");
			Thread.sleep(2000);
			searchBox.clear();
			searchBox.sendKeys(certificationName);
			Thread.sleep(5000);
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			if (userCount.getText().contains(" 0 entries"))
				Assert.fail(certificationName + " is not available in saviynt");
			else
				log.info("Search certification has been completed successfully: " +certificationName);
		} catch (Exception e) {
			Assert.fail("Search certification failed: "+certificationName + "  error : " + e);
			//log.info("Search certification failed"+e);

		}

	}

	/**
	 ** This method is to search campaign
	 ** @param campaignName
	 */
	public void searchCampaign(String campaignName) throws InterruptedException {
		try {
			log.info("Searching the change of position campaign: " + campaignName);
			Thread.sleep(1000);
			showAllCampaign.click();
			showAllTextField.sendKeys("All");
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
			searchBox.clear();
			searchBox.sendKeys(campaignName);
			Thread.sleep(1000);
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
			Thread.sleep(2000);
			if (userCount.getText().contains("0 entries"))
				Assert.fail(campaignName + " is not available in saviynt");
			else
				log.info("Search campaign has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search campaign failed");

		}

	}
	
	/**
	 ** This method is to click on a campaign

	 */
	public void clickCampaign(String annualCampaign) throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(By.xpath("//tr[@class='even' or @class='odd']//a[text()='" +annualCampaign+ "']"))
			.click();
			log.info("clicked on campaign succesfully");
		} catch (Exception e) {
			// Assert.fail("clicked on certification failed");
			log.info("clicked on campaign failed" +e);
		}

	}
	
	/**
	 ** This method is to click a certification

	 */
	public void clickCertification(String certificationName) throws InterruptedException {
		try {
			Thread.sleep(1000);
			driver.findElement(By.xpath("//tr[@class='even' or @class='odd']//a[text()='" +certificationName+ "']"))
			.click();
			log.info("clicked on certification succesfully");
		} catch (Exception e) {
			// Assert.fail("clicked on certification failed");
			log.info("clicked on certification failed" + e);

		}

	}

	/**
	 ** This method is to activate and start certification
	 */
	public void activateCertification() throws InterruptedException {
		try {
			Thread.sleep(3000);
			Thread.sleep(2000);
			log.info("Certification activation has completed");

		} catch (Exception e) {
			Assert.fail("Certification activation has failed");

		}
	}
	
	/**
	 ** This method is to active a queaterly certification

	 */
	public void activatequarterlyCertification() throws InterruptedException {
		try {

			Thread.sleep(3000);
			startCertification.click();
			Thread.sleep(10000);
			if(activate.isDisplayed()) {
				activate.click();
			}

			if(startCertification.isDisplayed()) {
				startCertification.click();
			}
			activate.click();
			Thread.sleep(2000);
			log.info("Certification activation has completed");

		} catch (Exception e) {
			log.info("Certification activation has failed");

		}
	}

	/**
	 ** This method is to search an user
	 * * @param username

	 */
	public void searchUser(String userName) throws InterruptedException {
		try {
			Thread.sleep(1000);
			log.info("Search clear");
			searchUser.clear();
			Thread.sleep(2000);

			searchUser.sendKeys(userName);
			Thread.sleep(1000);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);

			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}
	}

	/**
	 ** This method is to search user to certify
	 * * @param username

	 */

	public void searchUserToCertify(String userName) throws InterruptedException {
		try {
			driver.navigate ().refresh();
			Thread.sleep(2000);
			log.info("Search clear");
			searchUserToCertify.clear();
			Thread.sleep(1000);
			log.info("Search " + userName);
			searchUserToCertify.sendKeys(userName);
			Thread.sleep(2000);
			log.info("Search btn");
			searchbtn.click();
			Thread.sleep(10000);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,350)");
			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			softAssert.fail("seach user failed for " + users);
		}
	}

	/**
	 ** This method is to provide search an user and certify
	 * * @param username

	 */
	public void searchUserAndCertifyFromFilters(String userName) throws InterruptedException {
		try {
			log.info("Search user on Ceritification page and Certify :"+userName);
			driver.navigate ().refresh();
			Thread.sleep(10000);
			showFilters.click();
			Thread.sleep(10000);
			//if(userName.equalsIgnoreCase("testusername121")) {
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,250)");
			//}
			log.info("Click UserName field");
			userNameFilter.click();
			log.info("Clicked UserName field");
			Thread.sleep(1000);
			searchUserNameField.sendKeys(userName);
			Thread.sleep(2000);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			log.info("Xpath for the user checkbox under username filter:"+"//*[@id='USERNAME_"+userName+"' or @id='User_FIRSTNAME_"+userName+"']");
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='USERNAME_"+userName+"' or @id='User_FIRSTNAME_"+userName+"']")).click();
			Thread.sleep(4000);
			////////certify the selected user///////
			selectAllCheckbox.click();
			Thread.sleep(10000);
			selectedActionDropDown.click();
			searchSelectedActionDropDown.sendKeys("Certify");
			Thread.sleep(5000);
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(10000);
			confirmBulk.click();
			Thread.sleep(5000);

		} catch (Exception e) {
			softAssert.fail("seach user failed for " + users);
			Assert.fail("Search and user Ceritifcation failed" +e);
		}
	}

	/**
	 ** This method is to search an user and revoke access
	 * * @param username

	 */
	public void searchUserAndRevokeFromFilters(String userName) throws InterruptedException {
		try {
			log.info("Search user on Ceritification page and Remove :"+userName);
			driver.navigate ().refresh();
			Thread.sleep(5000);
			showFilters.click();
			Thread.sleep(10000);
			log.info("Click UserName field");
			userNameFilter.click();
			//Thread.sleep(1000);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,50)");
			Thread.sleep(1000);
			log.info("Clicked UserName field");
			searchUserNameField.sendKeys(userName);
			Thread.sleep(2000);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			log.info("Xpath for the user checkbox under username filter:"+"//*[@id='USERNAME_"+userName+"' or @id='User_FIRSTNAME_"+userName+"']");
			Thread.sleep(4000);
			driver.findElement(By.xpath("//*[@id='USERNAME_"+userName+"' or @id='User_FIRSTNAME_"+userName+"']")).click();
			Thread.sleep(4000);
			////////Remove the selected user///////
			selectAllCheckbox.click();
			Thread.sleep(10000);
			selectedActionDropDown.click();
			searchSelectedActionDropDown.sendKeys("Remove");
			Thread.sleep(5000);
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(10000);
			confirmBulk.click();
			Thread.sleep(5000);


		} catch (Exception e) {
			//softAssert.fail("seach user failed for " + users);
			Assert.fail("Search and user revomal failed" +e);

		}

	}
	
	
	/**
	 ** This method is to search an user to revoke access
	 * * @param username

	 */
	public void searchUserToRevoke(String userName) throws InterruptedException {
		try {
			driver.navigate ().refresh();
			Thread.sleep(2000);
			log.info("Search clear");
			searchUserToCertify.clear();
			Thread.sleep(1000);

			log.info("Search " + userName);
			searchUserToCertify.sendKeys(userName);
			Thread.sleep(2000);
			/*	Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);*/
			log.info("Search btn");
			searchbtn.click();
			Thread.sleep(8000);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,250)");
			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			softAssert.fail("seach user failed for " + users);

		}



	}

	/**
	 ** This method is to clear user search field
**/
	public void searchUserClear() throws InterruptedException {
		try {
			Thread.sleep(2000);
			log.info("Search clear");
			searchUserToCertify.clear();
			Thread.sleep(3000);

			log.info("Search clear has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search clear failed");

		}
	}

	/**
	 ** This method is to update status of user in reassigned certification
	 */

	public void selectReassinedEmploymentStatus(String user , String status, String extendDateCheck ,String extendDate,String SecuritySys, String reassignecheck, String reassigneTo ) throws InterruptedException {
		try {
			Thread.sleep(2000);
			log.info("****Employment status before update*****" + userStatus.getText());
			Thread.sleep(5000);
			Robot rb = new Robot();
			log.info("*********before click on status drop down***********");
			searchUser.click();
			log.info("*******Scroll to status  drop down*************");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement element = selectStatusdrpDown;
			js.executeScript("arguments[0].scrollIntoView();", element);
			log.info("*******click on status  drop down*************");
			selectStatusdrpDown.click();
			Thread.sleep(4000);
			log.info("*******after click on status drop down*************");
			//Thread.sleep(1000);
			log.info("*******select the desired status*************");
			log.info("desired status is " + status + " for user" + user);

			searchStatus.sendKeys("Works For Me");
			selectStatus.click();
			Thread.sleep(2000);
			log.info("Employment status  is updated as " + status);

		} catch (Exception e) {
			Assert.fail("selecting Employment Status has failed" +e);


		}
	}

	/**
	 ** This method is to select employment status from the drop down of an user
	 * * @param username
	 * @param status
	 * @param extendateCheck
	 * @param extend date
	 * @param reassgin check
	 * @param reassgin To

	 */
	public void selectEmploymentStatus(String user , String status, String extendDateCheck ,String extendDate, String reassignecheck, String reassigneTo) throws InterruptedException {
		try {
			Thread.sleep(5000);
			Robot rb = new Robot();
			log.info("*********before click on status drop down***********");
			searchUser.click();
			log.info("*******Scroll to status  drop down*************");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement element = selectStatusdrpDown;
			js.executeScript("arguments[0].scrollIntoView();", element);
			log.info("*******click on status  drop down*************");
			selectStatusdrpDown.click();
			Thread.sleep(2000);
			log.info("*******select the desired status*************");
			log.info("desired status is " + status + " for user" + user);
			if(extendDateCheck.contains("Yes")) {
				extendEndDate(extendDate);
				log.info("submiting extended date ");
				submitDate(extendDate);
				//checkExtendedEndDate(extendDate);
				// js.executeScript("arguments[0].scrollIntoView();", element);
			}else {
				searchStatus.sendKeys(status);
				selectStatus.click();
				Thread.sleep(2000);
				log.info("Employment status  is updated as " + status);
			}
			if(status.contains("Does Not Work For Me")) {
				log.info("waiting for addCertifier popup");
				if(	addCertifier.isDisplayed()) {
					log.info("add Certifier popup is found and reasigning the certification.");
					reassignCertification(reassigneTo);
				}else
					Assert.fail("No popup found to reassign certification");
			}


		} catch (Exception e) {
			//Assert.fail("selecting Employment Status has failed" +e);
			softAssert.fail("seach user failed for " + users);

		}
	}

	public void validateCertificationPage() throws InterruptedException {
		nextButton.click();
		JavascriptExecutor Js1 = (JavascriptExecutor) driver;
		Js1.executeScript("window.scrollBy(0,200)");
		Thread.sleep(10000);
	}

	/**
	 ** This method is to validate a certification
	 * * @param Target System
	 */
	public void validateCertification(String systemName) throws InterruptedException {
		try {

			Thread.sleep(4000);
			log.info("Begining of validation of ceritification");

			if (userCount.getText().contains("0 entries"))
				log.info("No records to certify or revoke");
			log.info("********message********: " + userCount.getText());
			int entriesinfo = userCount.getText().length();
			String entries =null;
			if(entriesinfo == 29) {
				entries = userCount.getText().substring(19);	
			}else
				entries = userCount.getText().substring(17);

			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of certification: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);

			log.info("********ROWs*******" + rows);

			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				log.info("***xpath of Security system:**** " + "//tr[" + i + "]//td[4]");
				String cell = driver.findElement(By.xpath("//tr[" + i + "]//td[4]")).getText();
				log.info("Name of security system: " + cell);
				if (systemName.contains(cell)) {
					log.info("certifying");

					JavascriptExecutor Js1 = (JavascriptExecutor) driver;
					Js1.executeScript("window.scrollBy(0,250)");
					Thread.sleep(3000);
					try {
						log.info("***xpath of certify:**** " + "//*[@id='certificationDetailsList']//tbody/tr[" + i
								+ "]//td//i[@class='iconSV-certify svgreen tooltips']");
						driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i
								+ "]//td//i[@class='iconSV-certify svgreen tooltips']")).click();
					} catch (Exception e) {

						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",
								driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i
										+ "]//td//i[@class='iconSV-certify svgreen tooltips']")));
					}


				} else {
					log.info("revoking");
					try {
						log.info("***xpath of revoke:****"+"//*[@id='certificationDetailsList']//tbody/tr['" + i+ "']//td//i[@class='iconSV-revoke svred tooltips']" );
						Thread.sleep(1000);
						driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr['" + i+ "']//td//i[@class='iconSV-revoke svred tooltips']")).click();
					}catch(Exception e) {
						log.info("Java executor to click on Revoke");
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",
								driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[2]//td//i[@class='iconSV-revoke svred tooltips']")));
					}

				}

			}


		} catch (Exception e) {
			// Assert.fail("Certification validation has failed ");
			log.info("Certification validation has failed " + e);

		}
	}

	/**
	 ** This method is to validate quaterly certification
	 * * @param Target System

	 */
	public void validateQuarterlyCertification(String systemName) throws InterruptedException {
		try {
			Thread.sleep(4000);
			log.info("Begining of validation of ceritification");

			if (userCount.getText().contains("0 entries"))
				Assert.fail("No records to certify or revoke");

			log.info("********message********: " + userCount.getText());
			int entriesinfo = userCount.getText().length();
			log.info(entriesinfo);

			String entries = userCount.getText().substring(19);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of certification: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);

			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				log.info("***xpath of Security system:**** " + "//tr[" + i + "]//td[7]");
				String cell = driver.findElement(By.xpath("//tr[" + i + "]//td[7]")).getText();
				log.info("Name of security system: " + cell);
				if (systemName.contains(cell)) {
					log.info("certifying");
					JavascriptExecutor Js1 = (JavascriptExecutor) driver;
					Js1.executeScript("window.scrollBy(0,1000)");
					try {
						log.info("***xpath of certify:**** " + "//*[@id='certificationDetailsList']//tbody/tr[" + i
								+ "]//td//i[@class='iconSV-certify svgreen tooltips']");
						driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i
								+ "]//td//i[@class='iconSV-certify svgreen tooltips']")).click();
					} catch (Exception e) {

						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",
								driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i
										+ "]//td//i[@class='iconSV-certify svgreen tooltips']")));
					}


				} else {
					log.info("revoking");
					try {
						log.info("***xpath of revoke:****"+"//*[@id='certificationDetailsList']//tbody/tr[" + i+ "]//td//i[@class='iconSV-revoke svred tooltips']" );
						Thread.sleep(1000);
						if(driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i+ "]//td//i[@class='iconSV-revoke svred svredactive tooltips']")).isDisplayed())
							log.info("It is already revoked");
						else
							driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i+ "]//td//i[@class='iconSV-revoke svred tooltips']")).click();
					}catch(Exception e) {
						log.info("Java executor to click on Revoke");
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",
								driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[2]//td//i[@class='iconSV-revoke svred tooltips']")));
					}

				}

			}

			Thread.sleep(3000);
			log.info("**********Before click Finish*********************");

			finish.click();

			log.info("**********After click Finish*********************");
			Thread.sleep(3000);

		} catch (Exception e) {
			// Assert.fail("Certification validation has failed ");
			log.info("Certification validation has failed " + e);

		}
	}

	/**
	 ** This method is to add signature while finishig certification
	 ** @param eusername
     ** @param epassword
	 */
	public void addSignature(String eusername, String epassword, String comment) throws InterruptedException {
		try {

			username.sendKeys(eusername);
			password.sendKeys(epassword);
			Thread.sleep(1000);
			eSignCheck.click();
			Thread.sleep(1000);
			addSign.click();
			Thread.sleep(7000);
			if(certificationCompletePopUpTitle.getText().contains("Your Certification is Completed")) {
				certificationCompletePopUpTitle.click();
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				commentBox.sendKeys(comment);
				Thread.sleep(3000);
				yes.click();
				Thread.sleep(1000);
			}


		} catch (Exception e) {
			log.info("Adding signature has failed " + e);

		}
	}

	/**
	 ** This method is to validate if certification is completed 
	 */
	public void checkCompleteValidation() throws InterruptedException {
		try {
			log.info("Check complete Validation");
			refreshProgressCertification.click();
			Thread.sleep(2000);
			securityManagerPopUpclose.click();
			Thread.sleep(10000);
			if (fullyExecuted.isDisplayed())
				log.info("Certication is done completely");
			else
				Assert.fail("Certication is not completely done");

		} catch (Exception e) {
			log.info("certification completion has failed");

		}
	}

	
	/**
	 ** This method is to search and click a campaign 
	 * * @param campaign name

	 */
	public void searchclickCampaign(String campaignNameChange) throws InterruptedException {
		try {
			log.info("Searching the change of position campaign: " + campaignNameChange);
			searchBox.clear();
			searchCampaign.sendKeys(campaignNameChange);
			clickSearchedCampaign.click();
			Thread.sleep(4000);
			log.info("Validate the campaign is found with name : " + campaignNameChange);
			if (countOfCampaing.getText().contains("0 entries")) {
				Assert.fail("Campaign hasn't been Lauched with name " + campaignNameChange);
			}
			log.info("Campaign has been Launched with name : " + campaignNameChange);
			Thread.sleep(1000);
			changeOfPostionCampaign.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			Assert.fail("Failed to click campaign");

		}
	}
	public void searchUser1(String user) throws InterruptedException {
		try {	
			search_usersList.clear();
			search_usersList.sendKeys(user);

			Thread.sleep(1000);
			searchButton.click();

			Thread.sleep(2000);

			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}
	/**
	 ** This method is to search role
	 */

	public void searchRole(String role) throws InterruptedException {
		try {	
			searchRole.clear();
			searchRole.sendKeys(role);

			Thread.sleep(1000);

			Robot rb = new Robot();

			// for pressing and releasing Enter
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);

			belongsToMe.click();
			log.info("belongsToMe");

			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}

	/**
	 ** This method is to select status of role
	 *@param rolename

	 */
	public void selectStatusOfRole(String role) throws InterruptedException {
		try {	

			belongsToMe.click();
			log.info("belongsToMe");

			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}
	
	/**
	 ** This method is to navigate to user page
	 */
	public void navigateToUsers() throws InterruptedException {
		try {	

			users.click();

			log.info("Navigated to users tab successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}

	public void validateUsersRoleAccess() throws InterruptedException {
		try {	

			searchUser.sendKeys("user");


			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}
	/**
	 ** This method is to finish certification
	 */
	public void finishCertification() throws InterruptedException {
		try {
			//softAssert.assertAll();
			Thread.sleep(3000);
			log.info("**********Before click Finish*********************");

			finish.click();

			log.info("**********After click Finish*********************");
			Thread.sleep(3000);
		} catch (Exception e) {
			Assert.fail("failed to finish Certification");
		}
	}

	public void finishRoleOwnerCertification() throws InterruptedException {
		try {	
			Thread.sleep(3000);
			log.info("**********Before click Finish*********************");

			finishAccess.click();

			log.info("**********After click Finish*********************");
			Thread.sleep(3000);


			log.info("waiting for popup");
			if(	lockConfimation.isDisplayed()) {

				log.info(lockConfimation.getText());
				yesBtn.click();
			}/*else
		Assert.fail("No popup found to reassign certification");*/


		} catch (Exception e) {
			Assert.fail("failed to finish Certification");
		}
	}

	public void finishAppOwnerCertification() throws InterruptedException {
		try {
			Thread.sleep(3000);
			log.info("**********Before click Finish*********************");
			finish.click();
			log.info("**********After click Finish*********************");
			Thread.sleep(8000);
			log.info("waiting for popup");
			//Thread.sleep(3000);
			if (certificationPopUp.getText().contains("Do you want to lock the Certification?")) {
				log.info(lockConfirmation.getText().contains("Do you want to lock the Certification?"));
				yesButton.click();
			}
			else if (certificationPopUp.getText().contains("Your Certification is not complete")){
				Assert.fail(certificationInCompletePopUpTitle.getText()); /*
				 * else Assert.fail("No popup found to reassign certification");
				 */
			}
			Thread.sleep(6000);
		} catch (Exception e) {
			Assert.fail("failed to finish Certification"+e);
		}
	}
	public void completeCertification() throws InterruptedException {
		try {

			log.info("waiting for popup");
			Thread.sleep(3000);
			if (lockConfirmation.isDisplayed()) {

				log.info(lockConfirmation.getText());
				yesButton.click();
			} 
			/* else Assert.fail("No popup found to reassign certification");
			 */

		} catch (Exception e) {
			Assert.fail("failed to finish Certification");
		}
	}

	public void extendEndDate(String extendDate) throws InterruptedException {
		try {	
			Thread.sleep(3000);
			searchStatus.sendKeys("Extend End Date");
			selectStatus.click();
			Thread.sleep(4000);
			comments.sendKeys("for test automation");
			log.info(" Extended Date : " + extendDate);
			endDate.click();
			Thread.sleep(3000);
			//extendDate ="31-May-2023";
			dateFormatter(extendDate);
			String date = extendDate.split("-")[0];
			String month = extendDate.split("-")[1];
			String year = extendDate.split("-")[2];
			log.info(date + " " + month  + " " +  year);
			String cmonth = driver.findElement(By.xpath("//div[1]//*[@class='datepicker-switch']")).getText();
			log.info(cmonth);
			log.info(month + " " + year);
			log.info(!(cmonth.equalsIgnoreCase(month + " " + year)));
			while(!(cmonth.equalsIgnoreCase(month + " " + year))){
				log.info("Search the month in the calender");
				driver.findElement(By.xpath("//div[1]//*[@class='next']")).click();
				cmonth = driver.findElement(By.xpath("//div[1]//*[@class='datepicker-switch']")).getText();
				log.info("Searched month:" +cmonth);
			}

			try {
				log.info("***xpath of Security system:**** " + "//div[1]//*[@class='day' and text()='" + date + "']");
				log.info("***************Before clicking on date*****************************");
				driver.findElement(By.xpath("//div[1]//*[@class='day' and text()='" + date + "']")).click();
				log.info("***************After clicking on date*****************************");
			}catch(Exception e) {
				log.info("Please check the extend date in the input parameter sheet");

			}


		} catch (Exception e) {
			//Assert.fail("failed to extend EndDate");
			log.info("failed to extend EndDate"+e);
		}
	}

	/** 
	     * This method to format the input date into dd-MMM-YYYY
	     * @param extend date from the input sheet
	     * @return string formatted date
	     */

	private String dateFormatter(String extendDate) throws ParseException {
		DateFormat df1 = new SimpleDateFormat("dd-MMM-yy"); // for parsing input
		DateFormat df2 = new SimpleDateFormat("dd-MMMM-yyyy");  // for formatting output
		Date d = df1.parse(extendDate);
		String outputDate = df2.format(d);
		System.out.println("After formating:"+outputDate);
		return outputDate;
	}

	public void submitDate(String extendDate) throws InterruptedException {
		try {	

			log.info(" submiting Date ");
			Thread.sleep(3000);
			submitDate.click();
			Thread.sleep(2000);
			log.info(" submited Date ");
		} catch (Exception e) {
			Assert.fail("failed to extend EndDate");
		}
	}
	/**
	 ** This method is to reassign certification to new manager
	 ** @param reassignTo
	 */
	public void reassignCertification(String reassigneTo) throws InterruptedException {
		try {	
			Thread.sleep(3000);
			if(reassigneTo.contains("Default")) {
				log.info("Reassigning certification to default manager");
				checkBox.click();
				submitBtn.click();
				Thread.sleep(3000);

			}else {

				log.info("Reassigning certification to " + reassigneTo);
				searchManager.sendKeys(reassigneTo);
				searchIcon.click();
				Thread.sleep(2000);
				radioBtn.click();
				submitBtn.click();
				Thread.sleep(2000);
			}
			log.info("");
			Thread.sleep(3000);
		} catch (Exception e) {
			Assert.fail("failed to reassign certification");
		}
	}

	public static void highLightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}

		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element);
	}



	public void selectRoleStatus(String user , String status ) throws InterruptedException {
		try {
			Thread.sleep(2000);

			Thread.sleep(3000);
			Robot rb = new Robot();
			log.info("*********before click on status drop down***********");
			searchUser.click();
			log.info("*******Scroll to status  drop down*************");
			JavascriptExecutor js = (JavascriptExecutor) driver;
			WebElement element = selectStatusdrpDown;
			js.executeScript("arguments[0].scrollIntoView();", element);
			log.info("*******click on status  drop down*************");
			selectStatusdrpDown.click();
			Thread.sleep(2000);
			//log.info("*******after click on status drop down*************");
			//Thread.sleep(1000);
			log.info("*******select the desired status*************");
			log.info("desired status is " + status + " for user" + user);
			if(status.contains("Belongs")) {
				belongsToMe.click();
				log.info("submiting extended daTE ");

			}else 
				if(status.contains("DoesNotBelongsToMe")) {
					doesNotBelongsToMe.click();
					log.info("waiting for addCertifier popup");
					if(	addCertifier.isDisplayed()) {
						log.info("add Certifier popup is found and reasigning the certification.");
						//reassignCertification(reassigneTo);
					}else
						Assert.fail("No popup found to reassign certification");
				}


		} catch (Exception e) {
			Assert.fail("selecting Employment Status has failed" +e);


		}



	}

	/**
	 ** This method is to validate app owner certification
	 ** @param systemName
	 ** @param users
	 */
	public void validateAppOwnerCertification(String users) throws InterruptedException {
		try {

			Thread.sleep(4000);
			log.info("Begining of validation of ceritification");
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,550)");
			if (userCount.getText().contains("0 entries"))
				softAssert.fail("No records to certify or revoke");
			log.info("********message********: " + userCount.getText());
			int entriesinfo = userCount.getText().length();

			String entries =null;
			if(entriesinfo == 28) {
				entries = userCount.getText().substring(18);	
			}else
				entries = userCount.getText().substring(17);

			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of certification: " + finalEntries2);
			int rows =Integer.valueOf(finalEntries2);

			log.info("********ROWs*******" + rows);

			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				//log.info("***xpath of Security system:**** " + "//*[@id='certificationDetailsList']//tbody//tr[" + i + "]//td[3]");
				//String cell = driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tr[" + i + "]//td[3]")).getText();
				//log.info("Name of security system: " + cell);
				String userName = driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tr[" + i + "]//td[4]")).getText();
				log.info("Name of user : " + userName);
				//	if (cell.contains(systemName)) {
				log.info("certifying");
				/*	
					JavascriptExecutor Js1 = (JavascriptExecutor) driver;
					Js1.executeScript("window.scrollBy(0,250)");*/
				Thread.sleep(5000);
				try {
					log.info("***xpath of certify:**** " + "//*[@id='certificationDetailsList']//tr[1]//i[@class='iconSV-certify svgreen tooltips']");
					driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tr[1]//i[@class='iconSV-certify svgreen tooltips']")).click();
					Thread.sleep(3000);
				} catch (Exception e) {

					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();",
							driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tr[1]//i[@class='iconSV-certify svgreen tooltips']")));
				}

			}

			Thread.sleep(10000);
		} catch (Exception e) {
			// Assert.fail("Certification validation has failed for " + users);
			log.info("Certification validation has failed " + e);
			//softAssert.fail("Certification validation has failed for " + users);


		}
	}

	/**
	 ** This method is to validate app owner certification
	 ** @param systemName
	 ** @param users
	 */
	public void validateAppOwnerRevoke(String users) throws InterruptedException {
		try {

			Thread.sleep(4000);
			log.info("Begining of validation of ceritification");
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,550)");
			if (userCount.getText().contains("0 entries"))
				softAssert.fail("No records to certify or revoke");
			log.info("********message********: " + userCount.getText());
			int entriesinfo = userCount.getText().length();

			String entries =null;
			if(entriesinfo == 29) {
				entries = userCount.getText().substring(19);	
			}else
				entries = userCount.getText().substring(17);

			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of certification: " + finalEntries2);
			int rows =Integer.valueOf(finalEntries2);

			log.info("********ROWs*******" + rows);

			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				log.info("***xpath of Security system:**** " + "//*[@id='certificationDetailsList']//tbody//tr[" + i + "]//td[3]");
				String cell = driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tr[" + i + "]//td[3]")).getText();
				log.info("Name of security system: " + cell);
				String userName = driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tr[" + i + "]//td[4]")).getText();
				log.info("Name of user : " + userName);
				log.info("revoking");
				try {
					log.info("***xpath of revoke:****"+"//*[@id='certificationDetailsList']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']" );
					Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']")).click();
				}catch(Exception e) {

					log.info("Java executor to click on Revoke");
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();",
							driver.findElement(By.xpath("//*[@id='certificationDetailsList']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']")));
				}




			}
			//	backBtn.click();
			Thread.sleep(10000);
		} catch (Exception e) {
			// Assert.fail("Certification validation has failed for " + users);
			log.info("Certification validation has failed " + e);
			//softAssert.fail("Certification validation has failed for " + users);


		}
	}

	public void validateRoleOwnerCertification(String user) throws InterruptedException {
		try {
			Thread.sleep(4000);
			log.info("Searching user validation of ceritification");
			searchUsers.sendKeys(user);
			Thread.sleep(2000);
			log.info("Begining of validation of ceritification");
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,250)");
			if (userCount.getText().contains("0 entries"))
				softAssert.fail("No records to certify or revoke");

			log.info("********message********: " + userCount.getText());
			int entriesinfo = userCount.getText().length();

			String entries =null;
			if(entriesinfo == 29) {
				entries = userCount.getText().substring(19);	
			}else
				entries = userCount.getText().substring(17);

			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of certification: " + finalEntries2);
			int rows =Integer.valueOf(finalEntries2);

			log.info("********ROWs*******" + rows);

			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				log.info("***xpath of Security system:**** " + "//*[@id='myDataTable14']//tbody//tr[" + i + "]//td[2]");
				//	String cell = driver.findElement(By.xpath("//*[@id='myDataTable14']//tr[" + i + "]//td[2]")).getText();
				//log.info("Name of security system: " + cell);
				String userName = driver.findElement(By.xpath("//*[@id='myDataTable14']//tr[" + i + "]//td[4]")).getText();
				log.info("Name of user : " + userName);
				if (userName.contains(user)) {
					log.info("certifying");
					/*	
					JavascriptExecutor Js1 = (JavascriptExecutor) driver;
					Js1.executeScript("window.scrollBy(0,250)");*/
					Thread.sleep(3000);
					try {
						log.info("***xpath of certify:**** " + "//*[@id='myDataTable14']//tr[" + i + "]//td[2]//i[@class='iconSV-certify svgreen tooltips']");
						driver.findElement(By.xpath("//*[@id='myDataTable14']//tr[" + i + "]//td[2]//i[@class='iconSV-certify svgreen tooltips']")).click();
					} catch (Exception e) {

						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",
								driver.findElement(By.xpath("//*[@id='myDataTable14']//tr[" + i + "]//td[2]//i[@class='iconSV-certify svgreen tooltips']")));
					}
				}

				else {
					log.info("revoking");
					try {
						log.info("***xpath of revoke:****"+"//*[@id='myDataTable14']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']" );
						Thread.sleep(1000);
						driver.findElement(By.xpath("//*[@id='myDataTable14']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']")).click();
					}catch(Exception e) {

						log.info("Java executor to click on Revoke");
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",
								driver.findElement(By.xpath("//*[@id='myDataTable14']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']")));
					}

				}


			}
			//	backBtn.click();
			Thread.sleep(10000);
		} catch (Exception e) {
			// Assert.fail("Certification validation has failed for " + users);
			log.info("Certification validation has failed " + e);
			//softAssert.fail("Certification validation has failed for " + users);


		}
	}

	public void validateTotalNumberOfAccountUserPartOf(String user, String accounts) {
		log.info("Validation of total Number of Accounts of the User: "+user);
		if(totalUserAccount.getText().contains(accounts)) {
			log.info("Validation of the numbers of user accounts is successful");
		}else {
			Assert.fail("Validation of the numbers of user accounts is failed");
		}
	}

	public void updateUserEmploymentStatus(String user) throws InterruptedException {
		try {
			Thread.sleep(2000);
			log.info("****Employment status before update*****" + userStatus.getText());
			Thread.sleep(5000);
			log.info("*******click on status  drop down*************");
			selectStatusdrpDown.click();
			Thread.sleep(4000);
			log.info("*******after click on status drop down*************");
			log.info("*******select the desired status*************");
			searchStatus.sendKeys("Works For Me");
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);
			log.info("Employment status  is updated as " + "Works For Me");

		} catch (Exception e) {
			Assert.fail("Employment status update is failed " + e);

		}

		log.info("Finish access review for the user: "+user);
		Thread.sleep(2000);
		finish.click();
		Thread.sleep(2000);
		if(lockConfimation.isDisplayed()) {
			yesBtn.click();
			Thread.sleep(8000);


		}
	}

	public void validateAccessToRoleAfterRevoke(String roleName, String users) throws InterruptedException {
		try {
			Thread.sleep(2000);
			search_roleList.clear();
			search_roleList.sendKeys(roleName);
			log.info("user send role name");
			Thread.sleep(5000);
			log.info("user search role");
			//searchButton.click();
			Robot rb = new Robot();
			// for pressing and releasing Enter
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			log.info("user link checking");
			//userLink.click();
			//driver.findElement(By.xpath("//a[text()="+ roleName +"]")).click();
			driver.findElement(By.xpath("//td[2]")).click();
			//td[2]//td[2]
			//a[text()='Role Application12Enterprise Test Role']
			Thread.sleep(2000);
			log.info("user link clicking");
			usersTab.click();
			log.info("userstab clicking");
			Thread.sleep(4000);
			int entriesinfo = userinfo.getText().length();
			log.info(entriesinfo);
			String entries = userinfo.getText().substring(17);
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			log.info("********ROWs*******" + rows);
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");

				log.info("*** xpath of child role : **** " + "//*[@id='myDataTableroleuser']//tbody//tr[" + i + "]//td[2]//a");
				String cell = driver.findElement(By.xpath("//*[@id='myDataTableroleuser']//tbody//tr[" + i + "]//td[2]//a")).getText();
				log.info("Name of user : " + cell);
				String[] user = users.split(",");
				if (users.contains(cell)) {
					log.info("Role access is not revoked");
					Assert.fail("Role access is not revoked");
					break;
				} 
				else
					log.info("Role access is revoked as expected");


			}
		} catch (Exception e) {
			log.info("Role access removal validation is failed");

		}

	}

	public void validateUsersRoleAccess(String usersToCertify, String usersToRevoke ) throws InterruptedException {
		try {	
			
		//	searchUser.sendKeys("user");
			
			if (userCount.getText().contains("0 entries"))
				log.info("No records to certify or revoke");
			else {
				validateRoleOwnerCertification(usersToCertify);
				validateRoleOwnerCertificationRevoke(usersToRevoke);
			}
			
			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}
	
	public void validateRoleOwnerCertificationRevoke(String user) throws InterruptedException {
		try {
			Thread.sleep(4000);
			
			String[] users = user.split(",");
			for (int j = 0; j < users.length; j++) {
			    // You may want to check for a non-word character before blindly
			    // performing a replacement
			    // It may also be necessary to adjust the character class
			   
			
			log.info("Searching user validation of ceritification");
			searchUsers.clear();
			searchUsers.sendKeys(users[j]);
			Thread.sleep(2000);
			log.info("Begining of validation of ceritification");
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,250)");
			if (userCount.getText().contains("0 entries"))
				softAssert.fail("No records to certify or revoke");
			
			log.info("********message********: " + userCount.getText());
			int entriesinfo = userCount.getText().length();
			
			String entries =null;
			if(entriesinfo == 29) {
				entries = userCount.getText().substring(19);	
			}else
			 entries = userCount.getText().substring(17);
	
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of certification: " + finalEntries2);
			int rows =Integer.valueOf(finalEntries2);
			
			log.info("********ROWs*******" + rows);
			
			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				log.info("***xpath of Security system:**** " + "//*[@id='myDataTable14']//tbody//tr[" + i + "]//td[2]");
			//	String cell = driver.findElement(By.xpath("//*[@id='myDataTable14']//tr[" + i + "]//td[2]")).getText();
				//log.info("Name of security system: " + cell);
				String userName = driver.findElement(By.xpath("//*[@id='myDataTable14']//tr[" + i + "]//td[4]")).getText();
				log.info("Name of user : " + userName);
					log.info("revoking");
					try {
						log.info("***xpath of revoke:****"+"//*[@id='myDataTable14']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']" );
						Thread.sleep(1000);
					driver.findElement(By.xpath("//*[@id='myDataTable14']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']")).click();
					}catch(Exception e) {
						
						log.info("Java executor to click on Revoke");
						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",
								driver.findElement(By.xpath("//*[@id='myDataTable14']//tbody/tr[" + i+ "]//td[2]//i[@class='iconSV-revoke svred tooltips']")));
					}

				}
					
			}
			
			
		
			Thread.sleep(10000);
		} catch (Exception e) {
			softAssert.fail("Certification validation has failed for " + users);
			

		}
	}
	
	
	
	
	public void validateAssociatedEntitlement(String entitlement) throws InterruptedException {
		try {
			Thread.sleep(4000);
			entitlements.click();
			Thread.sleep(4000);
			String[] entitlements = entitlement.split(",");
			for (int j = 0; j < entitlements.length; j++) {
			    // You may want to check for a non-word character before blindly
			    // performing a replacement
			    // It may also be necessary to adjust the character class
			   
			
			log.info("Searching user validation of ceritification");
			searchEntitlements.clear();
			searchEntitlements.sendKeys(entitlements[j]);
			Thread.sleep(2000);
			log.info("Begining of validation of ceritification");
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,250)");
			if (entCount.getText().contains(" 0 entries"))
				log.info("No records to certify or revoke");
			else {
			log.info("********message********: " + entCount.getText());
			int entriesinfo = entCount.getText().length();
			
			String entries =null;
			if(entriesinfo == 29) {
				entries = entCount.getText().substring(19);	
			}else
			 entries = entCount.getText().substring(17);
	
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of certification: " + finalEntries2);
			int rows =Integer.valueOf(finalEntries2);
			
			log.info("********ROWs*******" + rows);
			
			// Iterating over the List
			for (int i = 1; i <= rows; i++) {
				log.info("Before For loop");
				log.info("***xpath of Security system:**** " + "//*[@id='myDataTable15']//tbody//tr[" + i + "]//td[2]");
			
				String userName = driver.findElement(By.xpath("//*[@id='myDataTable15']//tr[" + i + "]//td[2]")).getText();
				String validation="certify";
				if (validation.contains("certify")) {
					log.info("certifying");
			
					Thread.sleep(3000);
					try {
						log.info("***xpath of certify:**** " + "//*[@id='myDataTable14']//tr[" + i + "]//td[1]//i[@class='iconSV-certify svgreen tooltips']");
						driver.findElement(By.xpath("//*[@id='myDataTable15']//tr[" + i + "]//td[1]//i[@class='iconSV-certify svgreen tooltips']")).click();
					} catch (Exception e) {

						JavascriptExecutor executor = (JavascriptExecutor) driver;
						executor.executeScript("arguments[0].click();",   driver.findElement(By.xpath("//*[@id='myDataTable15']//tr[" + i + "]//td[1]//i[@class='iconSV-certify svgreen tooltips']")));
					}
				}

				}
					
			}
			}
			
			Thread.sleep(10000);
		} catch (Exception e) {
			// Assert.fail("Certification validation has failed for " + users);
			log.info("Certification validation has failed " + e);
			//softAssert.fail("Certification validation has failed for " + users);
			

		}
	}
	
	
}

