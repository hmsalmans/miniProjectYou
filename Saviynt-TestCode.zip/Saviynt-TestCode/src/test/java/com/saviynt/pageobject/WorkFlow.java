package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.time.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;
import org.junit.Assert;

public class WorkFlow {

	WebDriver driver;
	private static Logger log = LogManager.getLogger();
	public static String requestID = "";
	SoftAssert softAssert = new SoftAssert();
	public WorkFlow(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	////Element Repository with element locators////
	@FindBy(xpath = "//*[@class='MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@type ='text']")
	public WebElement search;
	@FindBy(xpath = "//span[text() ='Request Access for Others']")
	public WebElement requestAccessforOthers;
	@FindBy(xpath = "//span[text()='Request New Access']")
	public WebElement requestNewAccessExternalUser;
	@FindBy(xpath = "//div[contains(@class,'searchBox')]")
	public WebElement userSearchBox;
	@FindBy(xpath = "//span[text()='Manage']")
	public WebElement manage;
	@FindBy(xpath = "//span[text()='Add New Access']")
	public WebElement addNewAccess;
	@FindBy(xpath = "//input[@id='outlined-adornment-password']")
	public WebElement appSearchBox;
	@FindBy(xpath = "//div[@id='panel1a-header']")
	public WebElement app;
	@FindBy(xpath = "//span[text() ='Request New Account']")
	public WebElement requestNewAccount;
	@FindBy(xpath = "//input[@id='modify-account-name']")
	public WebElement accountName;
	@FindBy(xpath = "//span[text()='Review & Submit']")
	public WebElement reviewSubmit;
	@FindBy(xpath = "//div[@class='account-attributes row']")
	public WebElement appName;
	@FindBy(xpath = "//div[contains(@class,'upload-list-text')]")
	public WebElement comments;
	@FindBy(xpath = "//input[@type='checkbox' and @value='checkedC']")
	public WebElement checkbox;
	@FindBy(xpath = "//span[text()='Submit']")
	public WebElement submit;
	@FindBy(xpath = "/div[@class='next-approver']")
	public WebElement nextApprover;
	@FindBy(xpath = "//div[@class='account-details text-center']")
	public WebElement requestId;
	@FindBy(xpath = "//span[text()='Pending Approvals']")
	public WebElement pendingApprovals;

	@FindBy(xpath = "//input[@type='text']")
	public WebElement searchRequestId;
	@FindBy(xpath = "//*[contains(@class,'MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary') and contains(@tabindex,'2')]")
	public WebElement view;
	@FindBy(xpath = "//*[text()='Approve']")
	public WebElement approve;
	@FindBy(xpath = "//*[text()='Select All']")
	public WebElement STA_EntitlementSelectAllLink;
	@FindBy(xpath = "//*[@id='fullscreencomponent']//span[text()='Approve']")
	public WebElement STA_EntitlementApprove;
	@FindBy(xpath = "//*[@class='defaultRejectIcon ']")
	public WebElement reject;
	@FindBy(xpath = "//span[text()='Confirm']")
	public WebElement confirm;
	@FindBy(xpath = "//input[@id='Business Justification']")
	public WebElement businessJustification;
	@FindBy(xpath = "//*[@class='ant-upload']//textarea")
	public WebElement commentsFinalApproval;

	@FindBy(xpath = "//span[text()='Final Confirmation']")
	public WebElement finalConfirmation;
	@FindBy(xpath = "//*[@class='discontinue-subtitle approvereject']")
	public WebElement successMessage;
	@FindBy(xpath = "//span[text()='Back to All Request Approvals']")
	public WebElement backToRequestHistory;

	@FindBy(xpath = "//a[contains(text(),'Accounts')]")
	public WebElement accountsTab;
	@FindBy(xpath = "//td[3]")
	public WebElement secSys;
	@FindBy(xpath = "//span[text()='All Employees']")
	public WebElement allEmployees;
	@FindBy(xpath = "//h4[text()='STA Disconnected']")
	public WebElement securitySystemHeader;
	@FindBy(xpath = "//*[text()='Request New Account']")
	public WebElement requestNewAccess;
	@FindBy(xpath = "//*[text()='Select Access']")
	public WebElement selectAccess;
	@FindBy(xpath = "//*[@class='row']//input")
	public WebElement accountNameInputTextField;

	@FindBy(xpath = "//*[@id='modify-account-name']")
	public WebElement accountName1;
	@FindBy(xpath = "//*[text()='Review & Submit']")
	public WebElement reviewAndSubmit;
	@FindBy(xpath = "//*[text()='Review']")
	public WebElement reviewHeader;

	@FindBy(xpath = "//*[@class='MuiIconButton-label']//input")
	public WebElement checkBox;
	@FindBy(xpath = "//span[text()='Submit']")
	public WebElement submitFinal;
	@FindBy(xpath = "//*[text()='Request Approvals']")
	public WebElement requestApproval;
	@FindBy(xpath = "//h5[@class='mt-3']")
	// *[@class='header-title']
	public WebElement requestConfirmationMessage;
	@FindBy(xpath = "//*[@class='next-approver']//span[2]")
	public WebElement nextApproverDetails;
	@FindBy(xpath = "//*[text()='Request History']")
	public WebElement requestHistoryLink;
	@FindBy(xpath = "//*[@id='panel1a-header']//span[text()='Add']")
	public WebElement addEntitlementOption;
	@FindBy(xpath = "//*[@class='entitlement-list']//input")
	public WebElement searchEntitlement;
	@FindBy(xpath = "//*[@class='divTableCell add']//button")
	public WebElement addEntitlementButton;
	@FindBy(xpath = "(//*[@class='MuiButton-label' or text()='Done'])[4]")
	public WebElement doneButton;
	@FindBy(xpath = "//*[@class='divTableHead customCheck']//input")
	public WebElement selectAllCheckBox;
	@FindBy(xpath = "//*[@id='full-width-tabpanel-one']//input")
	public WebElement searchFieldCurrentAccess;

	@FindBy(xpath = "//*[text()='STA Disconnected']")
	public WebElement existingApplicationName;
	@FindBy(xpath = "//*[@class='MuiButton-label' and text()='Delete']")
	public WebElement deleteExistingApplicationButton;
	@FindBy(xpath = "//*[@class='MuiButton-label' and text()='Modify']")
	public WebElement modifyExistingApplicationButton;
	@FindBy(xpath = "//*[@id='comments']")
	public WebElement commentBoxFordeleteExistingApplication;
	@FindBy(xpath = "//*[@class='MuiButton-label' and text()='Remove']")
	public WebElement removeBoxFordeleteExistingApplication;

	@FindBy(xpath = "//span[text()='Workflow List']")
	public WebElement workFlowList;
	@FindBy(xpath = "//span[text()='Workflow Approval']")
	public WebElement workFlowApproval;
	@FindBy(xpath = "//a[contains(@href,'javascript:;')and@class='btn btn-primary']")
	public WebElement workFlowAction;
	@FindBy(xpath = "//a[contains(@href,'/ECM/jbpmworkflowmanagement/jbpmworkfloweditor?status=new')]")
	public WebElement createWorkFlow;
	@FindBy(xpath = "//*[@name='name']")
	public WebElement workFlowName;
	@FindBy(xpath = "(//*[@class='inputEx-Field'])[2]")
	public WebElement workFlowType;
	@FindBy(xpath = "*//span[text()='Start']")
	public WebElement workFlowStart;
	@FindBy(xpath = "*//span[text()='TASK : Access Approval']")
	public WebElement accessApproval;
	@FindBy(xpath = "*//span[text()='TASK : Managers Manager Approval']")
	public WebElement managersManagerApproval;
	@FindBy(xpath = "*//span[text()='TASK : Manager Approval']")
	public WebElement managerApproval;
	@FindBy(xpath = "*//span[text()='TASK : Resource Owner Approval']")
	public WebElement resourceOwnerApproval;
	@FindBy(xpath = "*//span[text()='TASK : Owners Manager Approval']")
	public WebElement OwnerManagerApproval;
	@FindBy(xpath = "*//span[text()='TASK : SOD Owner Approval']")
	public WebElement SODOwnerApproval;
	@FindBy(xpath = "*//span[text()='CONDITION : If Else']")
	public WebElement conditonIfElse;
	@FindBy(xpath = "*//span[text()='Activity : Invite Action']")
	public WebElement inviteAction;
	@FindBy(xpath = "*//span[text()='Activity : Rejected Access']")
	public WebElement rejectedAccess;
	@FindBy(xpath = "*//span[text()='Activity : Grant Access']")
	public WebElement grantAccess;
	@FindBy(xpath = "*//span[text()='Escalation']")
	public WebElement escalation;
	@FindBy(xpath = "*//span[text()='comment']")
	public WebElement comment;
	@FindBy(xpath = "*//span[text()='End']")
	public WebElement end;
	@FindBy(xpath = "//span[@id='WiringEditor-saveButton']")
	public WebElement saveWorkFlow;
	@FindBy(xpath = "//span[@id='WiringEditor-sendForApprovalButton']")
	public WebElement sendWorkFlowApproval;
	@FindBy(xpath = "//span[@id='WiringEditor-backButton']")
	public WebElement backButton;
	@FindBy(xpath = "//a[contains(@href,'/ECM')and text()='Home']")
	public WebElement home;
	@FindBy(xpath = "//*[@id='yui-gen28-label']")
	public WebElement workFlowNameLabel;
	@FindBy(xpath = "//*[@class='WireIt-Layer']")
	public WebElement DropTo;
	@FindBy(xpath = "//*[@id='dtsearch_workflowList']")
	public WebElement workFlowSearch;
	@FindBy(xpath = "(//i[@class='icon-search'])[1]")
	public WebElement workFlowSearchButton;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement workFlowCount;
	@FindBy(xpath = "//*[@class='buttonAlignmt']")
	public WebElement selectFile;
	@FindBy(xpath = "//label[1]//ins[@class='iCheck-helper']")
	public List<WebElement> yesRadioBtn;
	@FindBy(xpath = "//*[@class='btn blue']")
	// "//i[@class='glyphicon glyphicon-eye-open']")
	public WebElement upload;
	@FindBy(xpath = "//div[@id='userImportTable']//th")
	public List<WebElement> header;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li")
	public List<WebElement> headerDrpdwn;
	@FindBy(xpath = "//*[@id='importBtn']/a[1]")
	public WebElement importBtn;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement searchDropdwn;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement userCount;
	@FindBy(xpath = "//a[@class='tooltip1']")
	public WebElement userLink;
	@FindBy(xpath = "//a[contains(text(),'Accounts')]")
	public WebElement accounts;
	@FindBy(xpath = "//td[8]")
	public WebElement accountStatus;
	@FindBy(xpath = "//div[@class='tsk-success']")
	public WebElement pendingTaskType;
	@FindBy(xpath = "//div[@class='tsk-warning']")
	public WebElement pendingTaskTypeWarning;

	@FindBy(xpath = "//td[8]")
	public WebElement securitySystem;
	@FindBy(xpath = "//input[@id='leaveStatus']")
	public WebElement leaveStatusField;
	@FindBy(xpath = "//td[contains(text(),'42617-In Progress')]")
	public WebElement parentTaskStatus;
	@FindBy(xpath = "//*[@class='modal-title' and text()='Comments']")
	public WebElement completeTaskPopUp;

	@FindBy(xpath = "(//*[@id='yui-gen0-button']")
	public WebElement submitCompleteTaskPopUp1;
	@FindBy(xpath = "//*[@class='add btn green']")
	public WebElement submitCompleteTaskPopUp2;
	@FindBy(xpath = "//a[@class='btn btn-xs default']")
	public WebElement taskactions;

	@FindBy(xpath = "//*[@class='dropdown-menu']//li[3]")
	public WebElement complete;
	@FindBy(xpath = "//*[@class='uniform']")
	public WebElement checkBoxForCommentsTaskCompletePopUp;
	@FindBy(xpath = "//*[@class='control-label col-md-12']")
	public WebElement messageWithMoreTaskForCompleteRequest;
	@FindBy(xpath = "//*[@class='divTableCell displayName']//h5")
	public WebElement existingApplication;
	@FindBy(xpath = "//*[@class='btnbox']//span[text()='Modify']")
	public WebElement modifyExistingApplication;
	@FindBy(xpath = "//*[@class='header-title']")
	public WebElement modifyExistingApplicationHeaderTitle;
	@FindBy(xpath = "(//*[@class='MuiButton-label' and text()='Add'])[1]")
	public WebElement addUnderSTAEntitlement;
	@FindBy(xpath = "//*[@class='entitlement-title']")
	public WebElement STAEntitlementTitle;
	@FindBy(xpath = "//*[@class='entitlement-list']//input")
	public WebElement searchUnderSTAEntitlement;
	@FindBy(xpath = "//*[@class='divTableCell add']//button")
	public WebElement addSelectedSTAEntitlement;

	@FindBy(xpath = "(//*[@class='ml-auto']//span)[2]")
	public WebElement countOfEntitlementSearchedFor;
	@FindBy(xpath = "//*[@class='MuiButton-label' and text()='Done'] ")
	public WebElement doneSearchEntitlementPage;
	@FindBy(xpath = "//*[@class='header-title']//button")
	public WebElement backToAppplicationPage;
	@FindBy(xpath = "//*[@id='panel1a-header']//h6[text()='STA Disconnected']")
	public WebElement requestHistoryApplicationPage;
	@FindBy(xpath = "(//*[@id='panel1a-header']//h6[text()='New Account Request & Approval']")
	public WebElement newAccountRequestApprovalSection;
	@FindBy(xpath = "(//*[text()='Access Pending'])[1]")
	public WebElement accessPendingLink;
	@FindBy(xpath = "//*[@class='MuiSvgIcon-root MuiSvgIcon-fontSizeLarge']")
	public WebElement closeButtonRequestHistoryPage;
	@FindBy(xpath = "//*[@class='icon-section']")
	public WebElement iconsectionApplication;
	@FindBy(xpath = "//*[@id='comments']")
	public WebElement commentsForEnablementOrLockAccountMyAccessExternalUser;
	@FindBy(xpath = "//*[text()='Proceed']")
	public WebElement confirmEnablementOrLockAccountMyAccessExternalUser;
	@FindBy(xpath = "(//*[@class='MuiButton-label' and text()='Add'])[1]")
	public WebElement addSTAEntitlement;
	@FindBy(xpath = "//*[@id='s2id_autogen13']//a")
	public WebElement showAll;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement showAllInput;

	@FindBy(xpath = "//input[@type='text']")
	public WebElement searchFieldPendingApproval;
	@FindBy(xpath = "//*[@id='root']//span[2]")
	public WebElement countOfRecordForUserPendingApproval;
	@FindBy(id = "dtsearch_usersList")
	public WebElement search_usersList;

	@FindBy(xpath = "(//*[@class='icon-search'])[1]")
	public WebElement searchButton;

	@FindBy(xpath = "//*[@class='grid-container']//span[@class='warning-text']")
	public WebElement inflightRequestMessage;

	public void navigateToRequestAccessforOthers() throws InterruptedException {
		try {
			Thread.sleep(1000);
			menu.click();
			search.sendKeys("Request Access for Others");
			Thread.sleep(1000);
			requestAccessforOthers.click();
			Thread.sleep(1000);
			log.info("User is on Request Access for Others");

		} catch (Exception e) {
			Assert.fail("Navigation has failed to Request Access for Others");

		}
	}

	/**
	 ** This method is to navigate to request access for others page.     
	 */

	public void navigateToRequestAccessExternalUser() throws InterruptedException {
		try {
			Thread.sleep(2000);
			menu.click();
			search.sendKeys("Request New Access");
			Thread.sleep(1000);
			requestNewAccessExternalUser.click();
			Thread.sleep(1000);
			log.info("User is on Request Access Page");

		} catch (Exception e) {
			Assert.fail("Navigation has failed to Request Access Page as as External User");

		}
	}

	public void searchUserToRequestAccess(String userName) throws InterruptedException {
		try {
			log.info("Search user under All Employees");
			Thread.sleep(2000);
			allEmployees.click();
			Thread.sleep(10000);
			log.info("********username******" + userName);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			search.sendKeys(userName);
			log.info("End of search");
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);

		} catch (Exception e) {
			log.info("User not found"+e);

		}
		try {
			log.info("Clicking Manage user button");
			// Getting all links with tag button on Manage access page
			List<WebElement> links = driver.findElements(By.tagName("button"));
			int i = links.size();
			for (int j = 0; j < i; j++) {

				if (links.get(j).getText().contains("Manage")) {
					links.get(j).click();
					Thread.sleep(5000);

				}
			}

		} catch (Exception e) {

			log.info("Manage button is not clickable" + e);
		}
	}

	/**
	 *        * This method is search an entitlement and validate it
	 * 
	 *     
	 */

	public void modifyRequestAccess(String securitySys, String entitlementName) throws InterruptedException {
		try {
			log.info("Modify Exiting Request and Search of the Entitlement");
			log.info("existingApplication" + existingApplication.getText());
			if (existingApplication.getText().contains(securitySys)) {
				Thread.sleep(2000);
				modifyExistingApplication.click();
				Thread.sleep(3000);
				if (modifyExistingApplicationHeaderTitle.getText().contains("Modify Access")) {
					log.info("User is on Modify Access Page");
					addUnderSTAEntitlement.click();
					Thread.sleep(4000);
					if (STAEntitlementTitle.getText().contains("STA_Entitlement")) {
						log.info("User is on STA entitlement page");
						searchUnderSTAEntitlement.sendKeys(entitlementName);
						Thread.sleep(4000);
						if (countOfEntitlementSearchedFor.getText().contains("1 - 1 of 1")) {
							log.info("Search Entitlement is  Listed");
						} else if (countOfEntitlementSearchedFor.getText().contains("1 - 0 of 0")) {
							log.info("Search Entitlement is not Listed");
						}

					}
					doneSearchEntitlementPage.click();
					backToAppplicationPage.click();
				}

			}

		} catch (Exception e) {
			log.info(e);
		}
	}

	/**
	 *        * This method to search and raise a request for others.       * @param
	 * securitySys      * @param userAccountName      * @param STA_Entitlement     
	 */
	public void searchEndpointToRequestAccess(String securitySys, String userAccountName, String STA_Entitlement)
			throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			Thread.sleep(4000);
			log.info("before Search by security system: " + securitySys);
			appSearchBox.sendKeys(securitySys);
			Thread.sleep(4000);
			log.info("after Search by security system: " + securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase("STA Disconnected")) {
					links.get(j).click();
					Thread.sleep(1000);
					log.info("Exisitng :" + driver.findElement(By.xpath("//*[@class='label owned']")).getText());
					if (driver.findElement(By.xpath("//*[@class='label owned']")).isDisplayed() && driver
							.findElement(By.xpath("//*[@class='label owned']")).getText().contains("EXISTING")) {
						requestNewAccess.click();
						log.info("Before Entering the account Name");
						Thread.sleep(2000);
						accountNameInputTextField.sendKeys(userAccountName);
						log.info("After Entering the account Name");
						Thread.sleep(2000);

					} else {
						Thread.sleep(2000);
						requestNewAccess.click();
						Thread.sleep(4000);
					}
					// Add STA Entitlement
					log.info("Add STA entitlement");
					addSTAEntitlement.click();
					Thread.sleep(2000);
					searchUnderSTAEntitlement.sendKeys(STA_Entitlement);
					Thread.sleep(2000);
					addSelectedSTAEntitlement.click();
					Thread.sleep(1000);
					doneSearchEntitlementPage.click();
					Thread.sleep(2000);
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						reviewAndSubmit.click();
						Thread.sleep(2000);
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							submitFinal.click();
							log.info("User submits the access request with all details");
							Thread.sleep(5000);
							if (requestConfirmationMessage.getText().contains("Confirmation")) {
								log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
								log.info("Request New access for the user is completed: " + securitySys);
								Thread.sleep(1000);

							}

						}
					}
				}

			}

		} catch (Exception e) {
			//Assert.fail("Creation of New Request failed ");
			log.info("Creation of New Request failed ");

		}
		String requestDetails = requestConfirmationMessage.getText();
		String[] splitedRequestId = requestDetails.split("\\s+");
		requestID = splitedRequestId[1];
		log.info("Request ID created for Access Request:" + requestID);

	}

	/**
	 *        * This method to search and raise a request for others target system
	 * with in flight checked       * @param securitySys      * @param
	 * userAccountName      * @param STA_Entitlement     
	 */
	public void searchEndpointToRequestAccessInFlight(String securitySys, String userAccountName, String Entitlement)
			throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			// addNewAccess.click();
			Thread.sleep(2000);
			log.info("before Search by security system: " + securitySys);
			appSearchBox.sendKeys(securitySys);
			log.info("after Search by security system: " + securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(securitySys)) {
					links.get(j).click();
					Thread.sleep(1000);
					log.info("Exisitng :" + driver.findElement(By.xpath("//*[@class='label owned']")).getText());
					if (driver.findElement(By.xpath("//*[@class='label owned']")).isDisplayed() && driver
							.findElement(By.xpath("//*[@class='label owned']")).getText().contains("EXISTING")) {
						requestNewAccess.click();
						log.info("Before Entering the account Name");
						// accountNameInputTextField.click();
						Thread.sleep(2000);
						accountNameInputTextField.sendKeys(userAccountName);
						log.info("After Entering the account Name");
						Thread.sleep(2000);

					} else {
						requestNewAccess.click();
						Thread.sleep(1000);
					}
					// Add STA Entitlement
					log.info("Add STA entitlement");
					addSTAEntitlement.click();
					searchUnderSTAEntitlement.sendKeys(Entitlement);
					Thread.sleep(2000);
					addSelectedSTAEntitlement.click();
					Thread.sleep(1000);
					doneSearchEntitlementPage.click();
					Thread.sleep(2000);
					// System.out.println("Select access "+selectAccess.getText());
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						reviewAndSubmit.click();
						Thread.sleep(2000);
						// System.out.println("Review Header"+reviewHeader.getText());
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							try {
								submitFinal.click();
								log.info("User submits the access request with all details");
								Thread.sleep(5000);

								if (requestConfirmationMessage.getText().contains("Confirmation")) {
									log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
									log.info("Request New access for the user is completed: " + securitySys);
									Thread.sleep(1000);

								}
							} catch (Exception e) {
								//////// write condition//////////

							}

						}
					}
				}

			}

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestDetails = requestConfirmationMessage.getText();
		String[] splitedRequestId = requestDetails.split("\\s+");
		requestID = splitedRequestId[1];
		log.info("Request ID created for Access Request:" + requestID);

	}

	/**
	 *        * This method to search and raise a request for others target system
	 * with in flight checked       * @param securitySys      * @param
	 * userAccountName      * @param STA_Entitlement     
	 */
	public void validateRequestAccessInFlight(String securitySys) throws InterruptedException {
		try {
			log.info("Request Access for a Target System with Inflight cheched");
			// addNewAccess.click();
			Thread.sleep(2000);
			log.info("before Search by security system: " + securitySys);
			appSearchBox.sendKeys(securitySys);
			log.info("after Search by security system: " + securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				log.info(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(securitySys)) {
					links.get(j).click();
					Thread.sleep(1000);
					if (driver.findElement(By.xpath("//h4[text()='" + securitySys + "']")).getText()
							.contains(securitySys)) {
						if (inflightRequestMessage.getText().contains("Your request is already pending for approval")
								&& driver.findElement(By.xpath("//*[@class='hint-msg']")).getText()
								.contains("Request in flight")) {
							log.info("New Request is not allowed to created for the target sytem with inflight checked:"
									+ securitySys);

						} else {
							Assert.fail("New Request is allowed to created for the target sytem with inflight checked:"
									+ securitySys);
						}
					}

				}
			}

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}

	}

	public String searchEndpointToRequestAccessDelegate(String nextApprover, String securitySys, String userAccountName)
			throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			// addNewAccess.click();
			Thread.sleep(2000);
			log.info("before Search by security system: " + securitySys);
			appSearchBox.sendKeys(securitySys);
			log.info("after Search by security system: " + securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase("STA Disconnected")) {
					links.get(j).click();
					Thread.sleep(1000);
					log.info("Exisitng :" + driver.findElement(By.xpath("//*[@class='label owned']")).getText());
					if (driver.findElement(By.xpath("//*[@class='label owned']")).isDisplayed() && driver
							.findElement(By.xpath("//*[@class='label owned']")).getText().contains("EXISTING")) {
						requestNewAccess.click();
						log.info("Before Entering the account Name");
						// accountNameInputTextField.click();
						Thread.sleep(2000);
						accountNameInputTextField.sendKeys(userAccountName);
						log.info("After Entering the account Name");
						Thread.sleep(2000);

					} else {
						requestNewAccess.click();
						Thread.sleep(1000);
					}
					// System.out.println("Select access "+selectAccess.getText());
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						reviewAndSubmit.click();
						Thread.sleep(2000);
						// System.out.println("Review Header"+reviewHeader.getText());
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							submitFinal.click();
							log.info("User submits the access request with all details");
							Thread.sleep(5000);

							if (requestConfirmationMessage.getText().contains("Confirmation")) {
								log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
								log.info("Request New access for the user is completed: " + securitySys);
								Thread.sleep(1000);
								if (nextApproverDetails.getText().contains(nextApprover)) {
									log.info("Request is pending with Delegated User: " + nextApprover);
								} else {
									Assert.fail("Request is not pending with Delegated User: " + nextApprover);
								}

							}

						}
					}
				}

			}

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestIdDetails = requestConfirmationMessage.getText();
		return requestIdDetails;

	}

	/**
	 *        * This method is to request access for the Target system for
	 * validation of Reject 
	 * 
	 *     
	 */

	public void searchEndpointToRequestAccessForRejectValidation(String securitySys, String entitlement)
			throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			// addNewAccess.click();
			Thread.sleep(2000);
			log.info("before Search by security system: " + securitySys);
			appSearchBox.sendKeys(securitySys);
			log.info("after Search by security system: " + securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(3000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase("STA Disconnected")) {
					links.get(j).click();
					Thread.sleep(1000);
					log.info("Exisitng :" + driver.findElement(By.xpath("//*[@class='label owned']")).getText());
					if (driver.findElement(By.xpath("//*[@class='label owned']")).isDisplayed() && driver
							.findElement(By.xpath("//*[@class='label owned']")).getText().contains("EXISTING")) {
						requestNewAccess.click();
						log.info("Before Entering the account Name");
						// accountNameInputTextField.click();
						Thread.sleep(2000);
						accountNameInputTextField.sendKeys("test reject 18");
						log.info("After Entering the account Name");
						Thread.sleep(2000);

					} else {
						requestNewAccess.click();
						Thread.sleep(1000);
					}
					// Add STA Entitlement
					log.info("Add STA entitlement");
					addSTAEntitlement.click();
					searchUnderSTAEntitlement.sendKeys(entitlement);
					Thread.sleep(2000);
					addSelectedSTAEntitlement.click();
					Thread.sleep(1000);
					doneSearchEntitlementPage.click();
					Thread.sleep(2000);
					// System.out.println("Select access "+selectAccess.getText());
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						reviewAndSubmit.click();
						Thread.sleep(2000);
						// System.out.println("Review Header"+reviewHeader.getText());
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							submitFinal.click();
							log.info("User submits the access request with all details");
							Thread.sleep(5000);

							if (requestConfirmationMessage.getText().contains("Confirmation")) {
								log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
								log.info("Request New access for the user is completed: " + securitySys);

							}

						}
					}
				}

			}

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestDetails = requestConfirmationMessage.getText();
		String[] splitedRequestId = requestDetails.split("\\s+");
		requestID = splitedRequestId[1];
		log.info("Request ID created for Access Request:" + requestID);

	}

	public void searchEndpointToRequestAccessForExternalUser(String userAccountName, String securitySys)
			throws InterruptedException {
		try {
			log.info("New access Request for the user to the already existing singleflow security system");
			// addNewAccess.click();
			Thread.sleep(2000);
			appSearchBox.sendKeys(securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(securitySys)) {
					links.get(j).click();
					log.info("Exisitng :" + driver.findElement(By.xpath("//*[@class='label owned']")).getText());
					if (driver.findElement(By.xpath("//*[@class='label owned']")).isDisplayed() && driver
							.findElement(By.xpath("//*[@class='label owned']")).getText().contains("EXISTING")) {
						requestNewAccess.click();
						log.info("Before Entering the account Name");
						// accountNameInputTextField.click();
						Thread.sleep(2000);
						accountNameInputTextField.sendKeys(userAccountName);
						log.info("After Entering the account Name");
						Thread.sleep(2000);

					} else {
						requestNewAccess.click();
						Thread.sleep(1000);
					}
					if (selectAccess.getText().contains("Select Access")) {
						log.info("User is on the Select Access page with details of end points");
						Thread.sleep(3000);
						reviewAndSubmit.click();
						Thread.sleep(1000);
						// System.out.println("Review Header"+reviewHeader.getText());
						if (reviewHeader.getText().contains("Review")) {
							log.info("User is on the Review page with details of end points");
							Thread.sleep(1000);
							checkBox.click();
							Thread.sleep(1000);
							submitFinal.click();
							log.info("User submits the access request with all details");
							Thread.sleep(5000);

							if (requestConfirmationMessage.getText().contains("Confirmation")) {
								log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
								log.info("Request New access for the user is completed: " + securitySys);

							}
							// Thread.sleep(1000);
							// requestHistoryLink.click();
							// log.info("User is on Request History page");
						}
					}

				}

			}

		} catch (Exception e) {
			log.error("Creation of New Request failed ");

		}
		String requestDetails = requestConfirmationMessage.getText();
		String[] splitedRequestId = requestDetails.split("\\s+");
		requestID = splitedRequestId[1];
		log.info("Request ID created for Access Request:" + requestID);

	}

	public String searchEndpointToRequestAccessForExternalUserForEntitlement(String userAccount, String securitySys,
			String entitlement) throws InterruptedException {
		try {
			log.info("Search for the Target System:" + securitySys + " And Raise an Access Request");
			// addNewAccess.click();
			Thread.sleep(2000);
			appSearchBox.sendKeys(securitySys);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(5000);
			List<WebElement> links = driver.findElements(By.xpath("//*[text()='" + securitySys + "']"));
			int i = links.size();
			for (int j = 0; j < i; j++) {
				// Printing the links
				System.out.println(links.get(j).getText());
				if (links.get(j).getText().equalsIgnoreCase(securitySys)) {
					links.get(j).click();
					log.info("Exisitng :" + driver.findElement(By.xpath("//*[@class='label owned']")).getText());
					if (driver.findElement(By.xpath("//*[@class='label owned']")).isDisplayed() && driver
							.findElement(By.xpath("//*[@class='label owned']")).getText().contains("EXISTING")) {
						requestNewAccess.click();
						log.info("Before Entering the account Name");
						// accountNameInputTextField.click();
						Thread.sleep(2000);
						accountNameInputTextField.sendKeys(userAccount);
						log.info("After Entering the account Name");
						Thread.sleep(2000);

					} else {
						requestNewAccess.click();
						Thread.sleep(1000);
					}

					log.info("Adding the user to Entitlements");
					Thread.sleep(4000);
					addEntitlementOption.click();
					searchEntitlement.clear();
					searchEntitlement.sendKeys(entitlement);
					Thread.sleep(2000);
					addEntitlementButton.click();
					doneButton.click();
					Thread.sleep(3000);
					log.info("********Scroll Begins******");
					JavascriptExecutor js = (JavascriptExecutor) driver;
					js.executeScript("window.scrollBy(0,5000)", "");
					log.info("********Scroll End******");
					selectAllCheckBox.click();
					Thread.sleep(2000);
					log.info("Validate if the Entitlment is added");
					if (driver.findElement(By.xpath("//*[@class='MuiSnackbarContent-message']//div[1]")).getText()
							.contains("1")) {
						log.info("Entitlement" + entitlement + "added successfully");

						if (selectAccess.getText().contains("Select Access")) {
							log.info("User is on the Select Access page with details of end points");
							Thread.sleep(3000);
							reviewAndSubmit.click();
							Thread.sleep(1000);
							// System.out.println("Review Header"+reviewHeader.getText());
							if (reviewHeader.getText().contains("Review")) {
								log.info("User is on the Review page with details of end points");
								Thread.sleep(1000);
								checkBox.click();
								Thread.sleep(1000);
								submitFinal.click();
								log.info("User submits the access request with all details");
								Thread.sleep(5000);

								if (requestConfirmationMessage.getText().contains("Confirmation")) {
									log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
									log.info("Request New access for the user is completed: " + securitySys);

								}
								// Thread.sleep(1000);
								// requestHistoryLink.click();
								// log.info("User is on Request History page");
							}
						}

					}

				}
			}

		} catch (Exception e) {
			log.info("Creation of New Request failed ");

		}
		String requestIdDetails = requestConfirmationMessage.getText();
		return requestIdDetails;

	}

	public void searchEndpointToRemoveAccess(String accountName, String securitySys) throws InterruptedException {
		try {
			log.info("Remove Access Request for an existing user in the Target System");
			Thread.sleep(2000);
			searchFieldCurrentAccess.sendKeys(accountName);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(4000);
			if (driver.findElement(By.xpath("//*[text()='" + securitySys + "']")).getText().contains(securitySys)) {
				Thread.sleep(3000);
				deleteExistingApplicationButton.click();
				log.info("Before:Enter the comments while removing the access"
						+ driver.findElement(By.xpath("//*[@class='discard-title']")).getText());
				Thread.sleep(4000);
				commentBoxFordeleteExistingApplication.sendKeys("For Test Automation Access Removal");
				log.info("After:Enter the comments while removing the access");
				removeBoxFordeleteExistingApplication.click();
				Thread.sleep(3000);
				if (requestConfirmationMessage.getText().contains("Confirmation")) {
					log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
					log.info("Request New access for the user is completed: " + securitySys);

				}
			}

		} catch (Exception e) {
			log.error("Access Removal of an existing user from a Target system is failed" + e);

		}
	}

	public void searchEndpointToLock(String accountName, String securitySys) throws InterruptedException {
		try {
			log.info("Lock the Account of the user");
			Thread.sleep(2000);
			searchFieldCurrentAccess.sendKeys(accountName);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(4000);

			if (driver.findElement(By.xpath("//*[text()='" + securitySys + "']")).getText().contains(securitySys)) {
				Thread.sleep(3000);

				iconsectionApplication.click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@class='MuiList-root MuiMenu-list']//li[text()='lock']")).click();
				Thread.sleep(1000);
				commentsForEnablementOrLockAccountMyAccessExternalUser.sendKeys("Test:" + "lock");
				confirmEnablementOrLockAccountMyAccessExternalUser.click();
				log.info("User Account request with all details");
				Thread.sleep(5000);

				if (requestConfirmationMessage.getText().contains("Confirmation")) {
					log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
					log.info("Request New access for the user is completed: " + securitySys);

				}
			}

		} catch (Exception e) {
			Assert.fail("Lock Account of an existing user from a Target system is failed" + e);

		}
	}

	public void searchEndpointTounLock(String accountName, String securitySys) throws InterruptedException {
		try {
			log.info("unLock the Account of the user");
			Thread.sleep(2000);
			searchFieldCurrentAccess.sendKeys(accountName);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(4000);

			if (driver.findElement(By.xpath("//*[text()='" + securitySys + "']")).getText().contains(securitySys)) {
				Thread.sleep(3000);

				iconsectionApplication.click();
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@class='MuiList-root MuiMenu-list']//li[text()='unlock']")).click();
				Thread.sleep(1000);
				commentsForEnablementOrLockAccountMyAccessExternalUser.sendKeys("Test:" + "unlock");
				confirmEnablementOrLockAccountMyAccessExternalUser.click();
				log.info("User Account request with all details");
				Thread.sleep(5000);

				if (requestConfirmationMessage.getText().contains("Confirmation")) {
					log.info("%%%%confirmaion%%%%:" + requestConfirmationMessage.getText());
					log.info("Request New access for the user is completed: " + securitySys);

				}
			}

		} catch (Exception e) {
			log.error("unLock Account of an existing user from a Target system is failed" + e);

		}
	}

	public void requestAccessToEndpoint() throws InterruptedException {
		try {

			app.click();
			requestNewAccount.click();
			reviewSubmit.click();
			comments.sendKeys("for test automation");
			checkbox.click();
			submit.click();
			log.info("Next Approver : " + nextApprover.getText());
			log.info("Request Id : " + requestId.getText());

		} catch (Exception e) {
			Assert.fail("Failed to request endpoint access");

		}
	}

	public void navigateToPendingApprovalsPage() throws InterruptedException {
		try {
			Thread.sleep(8000);
			// if(driver.findElement(By.xpath("//*[@class='request-welcome-user']")).getText().contains("TestAutomation_Manager"))
			// {
			// Thread.sleep(2000);
			menu.click();
			Thread.sleep(2000);
			search.sendKeys("Pending  Approvals");
			Thread.sleep(1000);
			pendingApprovals.click();
			Thread.sleep(5000);
			log.info("User is on Pending  Approvals");

			// }

		} catch (Exception e) {
			Assert.fail("Navigation has failed to Pending  Approvals");

		}
	}

	public void searchRequestId(String RequestIdFetch) throws InterruptedException {
		Thread.sleep(8000);

		try {

			if (requestApproval.getText().contains("Request Approvals")) {
				Thread.sleep(4000);
				// searchRequestId.sendKeys(User);
				// rb.keyPress(KeyEvent.VK_ENTER);
				// rb.keyRelease(KeyEvent.VK_ENTER);
				searchRequestId.sendKeys(RequestIdFetch);
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(2000);
				System.out.println("***Label***" + driver.findElement(By.xpath(
						"//*[@class='MuiButtonBase-root MuiButton-root MuiButton-text MuiButton-textPrimary']/.//span[contains(@class,'MuiButton-label')]"))
				.getAttribute("innerHTML"));
				try {
					Thread.sleep(5000);

					if (view.getAttribute("innerHTML").contains("View")) {
						log.info("Clicking View Approval button");
						Thread.sleep(10000);
						view.click();
					}

					// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
					// WebElement view= (WebElement)
					// wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(By.xpath("//*[@class='MuiButtonBase-root
					// MuiButton-root MuiButton-text
					// MuiButton-textPrimary']/.//span[contains(@class,'MuiButton-label')]")));
					// ((JavascriptExecutor)driver).executeScript("arguments[0].click();",view);

				} catch (Exception e) {
					log.info("View button is not clickable");

				}

			}

		} catch (Exception e) {
			log.error("Request Id is not found");

		}
	}

	public void approveRequest() throws InterruptedException {
		try {
			Thread.sleep(1000);
			approve.click();
			confirm.click();
			businessJustification.sendKeys("for test automation");
			Thread.sleep(1000);
			commentsFinalApproval.sendKeys("for test automation");
			finalConfirmation.click();
			Thread.sleep(3000);
			successMessage.getText();
			if (successMessage.getText().contains("1 items approved and 0 items rejected.")) {
				log.info("Final approval is successful");
			}
			backToRequestHistory.click();
			Thread.sleep(4000);
		} catch (Exception e) {
			Assert.fail("Final Approval of the New Access Request has failed");

		}
	}

	/**
	 *        * This method is to validate account has been added to the user     
	 * 
	 * @throws AWTException
	 */

	public void validateAccountCreation(String user, String securitySys, String accountName)
			throws InterruptedException, AWTException {
		try {

			userLink.click();
			accountsTab.click();
			Thread.sleep(15000);
			showAll.click();
			showAllInput.sendKeys("100");
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(15000);
			if (driver.findElement(By.xpath("//*[text()='" + securitySys + "']")).getText().contains(securitySys)
					&& driver.findElement(By.xpath("//*[@id='sample2']//tbody//tr/td//a[text()='" + accountName + "']"))
					.getText().contains(accountName)
					&& driver.findElement(By.xpath("//*[@class='active-status']")).getText()
					.contains("Manually Provisioned"))
				log.info("New Account: " + accountName + " has been successfully provisioned for the user: " + user
						+ " And to the security system: " + securitySys);
			else if (userCount.getText().contains("0 entries"))
				Assert.fail("New Account: " + accountName + "hasn't been provisioned for the user: " + user
						+ " And to the security system: " + securitySys);
			// log.info("Approve the pending tasks of the user: " + user);
			// secSys.getText();
		} catch (NoSuchElementException e) {
			Assert.fail("Account validation has failed"+e);

		}

		Thread.sleep(1000);
	}

	/**
	 *        * This method is to validate account has been locked for the user     
	 * 
	 * @throws AWTException
	 */
	public void validateAccountLock(String user, String securitySys) throws InterruptedException {
		try {

			userLink.click();
			accountsTab.click();
			Thread.sleep(15000);
			if (driver.findElement(By.xpath("//*[text()='" + securitySys + "']")).getText().contains(securitySys)
					&& driver.findElement(By.xpath("//*[text()='Locked']")).getText().contains("Locked"))
				log.info("Account of : " + user + " And to the security system: " + securitySys + "has been locked");
			else if (userCount.getText().contains("0 entries"))
				Assert.fail("Account of : " + user + "is not found");
		} catch (NoSuchElementException e) {
			Assert.fail("Validate account Lock has failed");

		}

		Thread.sleep(1000);
	}

	/**
	 *        * This method is to validate account has been suspended for the user
	 *     
	 * 
	 * @throws AWTException
	 */

	public void validateAccountSuspension(String user, String securitySys, String accountName)
			throws InterruptedException, AWTException {
		try {

			userLink.click();
			accountsTab.click();
			Thread.sleep(15000);
			showAll.click();
			showAllInput.sendKeys("100");
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(15000);
			if (driver.findElement(By.xpath("//*[text()='" + securitySys + "']")).getText().contains(securitySys)
					&& driver.findElement(By.xpath("//*[@id='sample2']//tbody//tr/td//a[text()='" + accountName + "']"))
					.getText().contains(accountName)
					&& driver.findElement(By.xpath("//*[@class='inactive-status']")).getText()
					.contains("Manually Suspended"))
				log.info("New Account: " + accountName + " has been suspended for the user: " + user
						+ " And to the security system: " + securitySys);
			else if (userCount.getText().contains("0 entries"))
				Assert.fail("New Account: " + accountName + "hasn't been suspended for the user: " + user
						+ " And to the security system: " + securitySys);
		} catch (NoSuchElementException e) {
			Assert.fail("Account validation has failed");

		}

		Thread.sleep(1000);
	}

	public void approveTask() throws InterruptedException {
		// log.info("Approving Task");
		taskactions.click();
		Thread.sleep(1000);
		complete.click();
		Thread.sleep(6000);
		submit.click();
		Thread.sleep(1000);
		log.info("Task has been approved successfully");

	}

	/**
	 *        * This method is to validate pending task     
	 */
	public void validatePendingTask(String user, String securitySys) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		if (pendingTaskType.getText().contains("New Account") && securitySystem.getText().contains(securitySys))
			log.info("pending task has been found for following user" + user);
		else if (userCount.getText().contains("0 entries"))
			Assert.fail("No pending task found for following user" + user);
		// log.info("Approve the pending taks of the user: " + user);
		approvePendingTaskForWorkFlowAsExternalUser();

		Thread.sleep(1000);

	}


	public void validatePendingTaskForAccessRemoval(String user, String securitySys)
			throws InterruptedException, AWTException {
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		if (pendingTaskTypeWarning.getText().contains("Remove Account")
				&& securitySystem.getText().contains(securitySys))
			log.info("pending task has been found for following user" + user);

		else if (userCount.getText().contains("0 entries"))
			Assert.fail("No pending task found for following user" + user);
		// log.info("Approve the pending taks of the user: " + user);
		approvePendingTaskForWorkFlowAsExternalUserForAccessRemoval();

		Thread.sleep(1000);

	}

	/**
	 *        * This method is to validate pending task is created when a request is
	 * rejected. If yes, test case fails     
	 */

	public void validatePendingTaskForRejectAccess(String user, String securitySys)
			throws InterruptedException, AWTException {
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		if (userCount.getText().contains("0 entries"))
			log.info("No pending task is found for the user" + user);

		else if (pendingTaskType.getText().contains("New Account") && securitySystem.getText().contains(securitySys))
			Assert.fail("pending task has been found for the user" + user);
		Thread.sleep(1000);

	}

	public void validatePendingTaskForRoleUpdate(String user) throws InterruptedException, AWTException {

		// searchpendingTasks.sendKeys(user);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		if (pendingTaskType.getText().contains("New Account") || pendingTaskType.getText().contains("Add Access"))
			log.info("pending task has been found for following user" + user);

		else if (userCount.getText().contains("0 entries"))
			Assert.fail("No pending task found for following user" + user);
		// log.info("Approve the pending taks of the user: " + user);
		approvePendingTask();

		Thread.sleep(1000);

	}

	/**
	 *        * This method is search workflow by name under workflow list 
	 **/
	public void workflowSearch(String workFlowName) {

		try {
			workFlowSearch.clear();
			workFlowSearch.sendKeys(workFlowName);
			Thread.sleep(3000);
			workFlowSearchButton.click();
			Thread.sleep(3000);
		} catch (Exception e) {
			log.info("Search WorkFlow has failed");

		}

	}

	/**
	 *        * This method is to validate where workflow created is found. If not
	 * test case will be failed
	 **/

	public void validateWorkFlowCreation(String workFlowName) throws AWTException, InterruptedException {
		if (workFlowCount.getText().contains("0 entries"))
			Assert.fail("No WorkFlow found with following name");
		if (driver.findElement(By.xpath("//*[text()='" + workFlowName + "']")).isDisplayed())
			log.info("WorkFlow is found");

	}

	public void provideCSVWithEndPointDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection("C:\\Users\\rajeswari.loyi\\Desktop\\WorkflowUserList.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		Thread.sleep(1000);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);

	}

	public void uploadDetails() throws InterruptedException, AWTException, FileNotFoundException {

		Thread.sleep(4000);
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();
		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);
		header.get(1).click();
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		importBtn.click();
		Thread.sleep(2000);
	}

	public void validateAccountStatus(String user) throws InterruptedException, AWTException {
		if (userCount.getText().contains("0 entries"))
			Assert.fail("No User found with following name");

		userLink.click();
		accounts.click();

		Thread.sleep(2000);
		if (accountStatus.getText().equalsIgnoreCase("Manually Provisioned"))
			log.info("Leave status has been updated successfully for the existing user");
		else
			Assert.fail("Leave status hasn't been updated successfully for the existing user");

	}

	public void validateCompletedTask(String user) throws InterruptedException, AWTException {
		Thread.sleep(2000);

		if (pendingTaskType.getText().contains("Disable Account"))
			log.info("Disable Account task is completed");
		else if (userCount.getText().contains("0 entries"))
			Assert.fail("Disable Account task is not completed");

	}

	public void validateLeaveStatus(String user, String leaveStatus) throws InterruptedException, AWTException {
		if (userCount.getText().contains("0 entries"))
			Assert.fail("No User found with following name");
		log.info("Validation of Leave status");
		userLink.click();
		Thread.sleep(2000);
		System.out.println("leaveStatusField:" + leaveStatusField.getAttribute("Value"));
		if (leaveStatusField.getAttribute("Value").equalsIgnoreCase(leaveStatus))
			log.info("Leave status: " + leaveStatus + " has been updated successfully for the existing user");
		else
			Assert.fail("Leave status hasn't been updated successfully for the existing user");

	}

	public void validatePendignTaskHasManagerEntitlementAndApprove(String user)
			throws InterruptedException, AWTException {

		List<WebElement> tabsOdd = driver.findElements(By.xpath("//*[@class='odd']"));
		List<WebElement> tabsEven = driver.findElements(By.xpath("//*[@class='even']"));
		// List<String> all_elements_odd=new LinkedList();
		for (WebElement listOfOdd : tabsOdd) {
			if (listOfOdd.getText().contains("Manager")) {
				log.info("Pending Task list has entry with Entitlement as Manager");
				Thread.sleep(1000);

				driver.findElement(By.xpath("//*[@name='pendingTasks']")).click();
				approvePendingTask();

			}
		}

	}

	public void approvePendingTask() throws InterruptedException, AWTException {

		try {
			log.info("Approving pending Task");
			taskactions.click();
			Thread.sleep(1000);
			log.info("*****Before clicking on complete task*******");
			complete.click();
			log.info("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			if (completeTaskPopUp.getText().contains("Comments")) {
				Thread.sleep(4000);
				if (messageWithMoreTaskForCompleteRequest.isDisplayed()
						&& messageWithMoreTaskForCompleteRequest.getText().contains(
								"There are 1more task with this request. Would you like to include all of them?")) {
					{
						checkBoxForCommentsTaskCompletePopUp.click();
					}
				}

				// Keyboard action to complete a pending task as element locator is not working
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				log.info("Pending Task has been approved successfully");
				Thread.sleep(15000);
			}

		} catch (Exception e) {

			Assert.fail("Pending Tasks hasn't been approved");
		}

	}

	/**
	 *        * This method is to approve pending task     
	 */

	public void approvePendingTaskForWorkFlowAsExternalUser() throws InterruptedException, AWTException {
		try {
			log.info("Approving pending Task");
			taskactions.click();
			Thread.sleep(3000);
			log.info("*****Before clicking on complete task*******");
			complete.click();
			log.info("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			if (completeTaskPopUp.getText().contains("Comments")) {
				Thread.sleep(4000);
				checkBoxForCommentsTaskCompletePopUp.click();
			}
			Thread.sleep(1000);
			log.info("*****Before clicking on submit*******");
			submitCompleteTaskPopUp2.click();
			log.info("*****after clicking on submit*******");
			log.info("Pending Task has been approved successfully");
			Thread.sleep(15000);
			driver.navigate().refresh();

		} catch (Exception e) {
			log.info(e);
			Assert.fail("Pending Tasks hasn't been approved");
		}

	}

	/**
	 *        * This method is to approve pending task for Access removal  
	 */

	public void approvePendingTaskForWorkFlowAsExternalUserForAccessRemoval()
			throws InterruptedException, AWTException {
		try {
			log.info("Approving pending Task");
			taskactions.click();
			Thread.sleep(3000);
			log.info("*****Before clicking on complete task*******");
			complete.click();
			log.info("****After clicking on complete task************");
			Thread.sleep(10000);
			// log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			Thread.sleep(1000);
			log.info("*****Before clicking on submit*******");
			submitCompleteTaskPopUp2.click();
			log.info("*****after clicking on submit*******");
			log.info("Pending Task has been approved successfully");
			Thread.sleep(15000);
			driver.navigate().refresh();

		} catch (Exception e) {
			log.info(e);
			Assert.fail("Pending Tasks hasn't been approved");
		}

	}

	public void RoleModificationForapprovePendingTask() throws InterruptedException, AWTException {

		try {
			log.info("Approving pending Task");
			taskactions.click();
			Thread.sleep(1000);
			System.out.println("*****Before clicking on complete task*******");
			complete.click();
			System.out.println("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			if (completeTaskPopUp.getText().contains("Comments")) {
				Thread.sleep(4000);
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_TAB);
				rb.keyRelease(KeyEvent.VK_TAB);
				rb.keyPress(KeyEvent.VK_ENTER);
				rb.keyRelease(KeyEvent.VK_ENTER);
				// submitCompleteTaskPopUp2.click();

				log.info("Pending Task has been approved successfully");
				Thread.sleep(15000);
			}

		} catch (Exception e) {

			Assert.fail("Pending Tasks hasn't been approved");
		}

	}

	/**
	 *        * This method is for Manager to approve the request
	 * 
	 *     
	 */
	public void approveRequestAsManagerForWorkFlow() throws InterruptedException {
		try {
			Thread.sleep(3000);
			log.info("Approve the New account Access Request");
			approve.click();
			if (STA_EntitlementSelectAllLink.isDisplayed()) {
				STA_EntitlementSelectAllLink.click();
				Thread.sleep(2000);
				STA_EntitlementApprove.click();
			}
			Thread.sleep(2000);
			confirm.click();
			Thread.sleep(2000);
			businessJustification.sendKeys("for test automation");
			Thread.sleep(1000);
			commentsFinalApproval.sendKeys("for test automation");
			Thread.sleep(1000);
			finalConfirmation.click();
			Thread.sleep(6000);
			successMessage.getText();
			if (successMessage.getText().contains("1 items approved and 0 items rejected.")) {
				log.info("Final approval is successful");
			}
			backToRequestHistory.click();
			Thread.sleep(8000);


		} catch (Exception e) {
			// Assert.fail("Final Approval of the New Access Request has failed");
			log.info("Final Approval of the New Access Request has failed" + e);

		}
	}


	/**
	 *        * This method is for Manager to approve the request
	 * 
	 *     
	 */
	public void approveRequestAsManagerFromRequestApprovalPage() throws InterruptedException {
		try {
			Thread.sleep(3000);
			log.info("Approve the New account Access Request");
			approve.click();
			STA_EntitlementSelectAllLink.click();
			Thread.sleep(2000);
			STA_EntitlementApprove.click();
			confirm.click();

			/*
			 * if (driver.findElement(By.xpath("//*[@class='partialmodal-container']")).
			 * isDisplayed()) {
			 * driver.findElement(By.xpath("//span[text()='Proceed To Confirm']")).click();
			 * Thread.sleep(2000); }
			 */
			Thread.sleep(2000);
			businessJustification.sendKeys("for test automation");
			Thread.sleep(1000);
			commentsFinalApproval.sendKeys("for test automation");
			finalConfirmation.click();
			Thread.sleep(3000);
			successMessage.getText();
			if (successMessage.getText().contains("1 items approved and 0 items rejected.")) {
				log.info("Final approval is successful");
			}
			backToRequestHistory.click();
			Thread.sleep(8000);
		} catch (Exception e) {
			// Assert.fail("Final Approval of the New Access Request has failed");
			log.info("Final Approval of the New Access Request has failed" + e);

		}
	}

	/**
	 *        * This method is for Manager to reject an approval request     
	 */

	public void rejectRequestAsManagerForWorkFlow() throws InterruptedException {
		try {
			Thread.sleep(1000);
			log.info("Reject the New account Access Request");
			reject.click();
			confirm.click();
			/*
			 * if (driver.findElement(By.xpath("//*[@class='partialmodal-container']")).
			 * isDisplayed()) {
			 * driver.findElement(By.xpath("//span[text()='Proceed To Confirm']")).click();
			 * Thread.sleep(2000); }
			 */
			Thread.sleep(2000);
			businessJustification.sendKeys("reject for test automation");
			Thread.sleep(1000);
			commentsFinalApproval.sendKeys(" reject for test automation");
			finalConfirmation.click();
			Thread.sleep(3000);
			successMessage.getText();
			if (successMessage.getText().contains("0 items approved and 1 items rejected.")) {
				log.info("Reject approval is successful");
			}
			backToRequestHistory.click();
			Thread.sleep(8000);
		} catch (Exception e) {
			log.info("Reject Approval of the New Access Request has failed" + e);
			Assert.fail("Reject Approval of the New Access Request has failed");

		}
	}

	/**
	 *        * This method to search request id in pending approval page. 
	 * 
	 *     
	 **/

	public void searchRequestIdPendingApprovalPage(String requestId) throws InterruptedException {
		try {
			Thread.sleep(2000);
			log.info("RequestId:" + requestId);
			Thread.sleep(4000);
			if (requestApproval.getText().contains("Request Approvals")) {
				Thread.sleep(2000);
				log.info("******Begining of Search******" + requestId);
				searchFieldPendingApproval.sendKeys(requestId);
				log.info("******Begining of Robotic enter******");
				Thread.sleep(3000);
				Robot rb = new Robot();
				rb.keyPress(KeyEvent.VK_ENTER);
				log.info("******Robotic enter Key Press******");
				rb.keyRelease(KeyEvent.VK_ENTER);
				log.info("******Robotic enter Key Release******");
				Thread.sleep(10000);
				log.info("countOfRecordForUserPendingApproval" + countOfRecordForUserPendingApproval.getText());
				if (countOfRecordForUserPendingApproval.getText().contains("1")) {
					Thread.sleep(1000);
					if (view.getAttribute("innerHTML").contains("View")) {
						log.info("Clicking View Approval button");
						Thread.sleep(10000);
						view.click();
					}
				}
			}

			log.info("Search request Id has been completed successfully on Pending Approval Page");
		} catch (Exception e) {
			//Assert.fail("Search request Id has failed on Pending Approval Page");
			log.info("Search request Id has failed on Pending Approval Page");

		}

	}

	public void User_validates_pendingApprovalWithManagerManager_whenManagerTerminated(String user, String securitySys)
			throws InterruptedException {
		try {
			log.info("Request History Application header title:" + requestHistoryApplicationPage.getText());
			if (requestHistoryApplicationPage.getText().contains(securitySys)) {
				if (newAccountRequestApprovalSection.isDisplayed()) {
					accessPendingLink.click();
					Thread.sleep(2000);
					if (driver.findElement(By.xpath("(//*[@id='panel1a-content']//i/span[text()='" + user + "'])[1]"))
							.getText().contains(user))

						log.info("Access Approval is pending with:" + user + "When Manager is terminated");
				} else {
					log.info("Access Approval is not pending with:" + user + "When Manager is terminated");
				}

			}
			closeButtonRequestHistoryPage.click();
		} catch (NoSuchElementException e) {
			Assert.fail("Validate has failed for pending approval when Manager is terminated");

		}

	}

	public void searchRequestIDPendingTask(String user) throws InterruptedException {
		try {
			search_usersList.clear();
			search_usersList.sendKeys(user);
			Thread.sleep(1000);
			searchButton.click();
			Thread.sleep(2000);
			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}
	public void searchRequestIDPendingTaskForAccessRemoval(String user,String securitySys ) throws InterruptedException {
		try {
			search_usersList.clear();
			search_usersList.sendKeys(user);
			Thread.sleep(1000);
			searchButton.click();
			Thread.sleep(2000);
			if ((userCount.getText().contains("0 entries"))){
				softAssert.fail("No pending task found for following user" + user);

			}else {
				if (pendingTaskType.getText().contains("Remove Account") && securitySystem.getText().contains(securitySys))
					log.info("pending task has been found for following user" + user);
			}
		} catch (Exception e) {
			Assert.fail("Search user for pending task has failed");

		}

	}


	public void searchUserToRequestAccessForRole(String workFlowUser) throws InterruptedException {
		try {
			log.info("Search user under All Employees");
			Thread.sleep(2000);
			allEmployees.click();
			Thread.sleep(1000);
			log.info("********username******" + workFlowUser);
			Robot rb = new Robot();
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			search.sendKeys(workFlowUser);
			System.out.println("End of search");
			rb.keyPress(KeyEvent.VK_ENTER);
			rb.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);

		} catch (Exception e) {
			Assert.fail("User not found");

		}
		try {
			Thread.sleep(10000);
			log.info("Clicking Manage user button");
			driver.findElement(By.xpath("(//*[@class='divTableRow row0']//button//span[text()='Manage'])[4]")).click();
			List<WebElement> links = driver.findElements(By.tagName("button"));
		} catch (Exception e) {

			log.info("Manage button is not clickable" + e);
		}
	}
}
