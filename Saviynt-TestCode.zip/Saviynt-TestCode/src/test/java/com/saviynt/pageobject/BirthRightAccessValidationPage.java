package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.junit.Assert;

public class BirthRightAccessValidationPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();
	WorkFlow wf = new WorkFlow(driver);

	public BirthRightAccessValidationPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	////Element Repository with element locators////
	@FindBy(xpath = "//td[8]")
	public WebElement securitySystem;
	@FindBy(xpath = "//div[@class='tsk-success']")
	public WebElement pendingTaskType;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement userCount;
	@FindBy(id = "dtsearch_usersList")
	public WebElement search_usersList;
	@FindBy(xpath = "(//*[@class='icon-search'])[1]")
	public WebElement searchButton;
	@FindBy(xpath = "//a[@class='tooltip1']")
	public WebElement userLink;
	@FindBy(xpath = "//a[contains(text(),'Accounts')]")
	public WebElement accounts;
	@FindBy(xpath = "//a[@class='btn btn-xs default']")
	public WebElement taskactions;
	@FindBy(xpath = "//*[@class='dropdown-menu']//li//a[@class='discontinuetask']")
	public WebElement discontinue;
	@FindBy(xpath = "//*[contains(text(),'Discontinuing Task')]")
	public WebElement discontinueCheck;
	@FindBy(xpath = "//a[@class='btn green']")
	public WebElement yes;
	@FindBy(xpath = "//div[@id='taskComments']")
	public WebElement discontinueTaskPopUp;
	@FindBy(xpath = "//*[@id='discontinuecomments']")
	public WebElement discontinueComments;
	@FindBy(xpath = "//a[@class='add btn green']")
	public WebElement submitComments;
	@FindBy(xpath = "//*[@class='dropdown-menu']//li[3]")
	public WebElement complete;
	@FindBy(xpath = "//*[@class='uniform']")
	public WebElement checkBoxForCommentsTaskCompletePopUp;
	@FindBy(xpath = "//*[@class='control-label col-md-12']")
	public WebElement messageWithMoreTaskForCompleteRequest;
	@FindBy(xpath = "//*[@class='modal-title' and text()='Comments']")
	public WebElement completeTaskPopUp;
	@FindBy(xpath = "//a[@id='arsPendingTaskAction']")
	public WebElement pendingTaskAction;
	@FindBy(xpath = "//a[@id='completeSelectedTask']")
	public WebElement completeSelectedTask;
	@FindBy(xpath = "//*[@id='coments']")
	public WebElement comments;
	@FindBy(xpath = "//button[@id='yui-gen0-button']")
	public WebElement submit;
	@FindBy(xpath = "//td[8]")
	public WebElement accountStatus;
	@FindBy(xpath = "//*[@class='buttonAlignmt']")
	public WebElement selectFile;
	@FindBy(xpath = "//div[@id='userImportTable']//th")
	public List<WebElement> header;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li")
	public List<WebElement> headerDrpdwn;
	@FindBy(xpath = "//label[1]//ins[@class='iCheck-helper']")
	public List<WebElement> yesRadioBtn;
	@FindBy(xpath = "//label[2]//ins[@class='iCheck-helper']")
	public List<WebElement> noRadioBtn;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement searchDropdwn;
	@FindBy(xpath = "//*[@id='importBtn']/a[1]")
	public WebElement importBtn;
	@FindBy(xpath = "//*[@class='btn blue']")
	public WebElement upload;

	
	/**
	 ** This method is to provide the CSV files for BirthrightAccess
	 */
	public void provideCSV() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				System.getProperty("user.dir") + "\\src\\test\\resources\\TestData\\BirthRightAccess.csv");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

	}

	/**
	 ** This method is to upload user request

	 */
	public void uploadUserRequest() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();
		Thread.sleep(2000);
		yesRadioBtn.get(4).click();
		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);
		header.get(1).click();
		searchDropdwn.sendKeys("FIRSTNAME");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(2).click();
		searchDropdwn.sendKeys("LASTNAME");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(3).click();
		searchDropdwn.sendKeys("STATUSKEY");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(4).click();
		searchDropdwn.sendKeys("LEAVESTATUS");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		importBtn.click();
		Thread.sleep(2000);
		driver.navigate().refresh();

	}

	/**
	 ** This method is to validate pending tasks

	 */
	public void validatePendingTask(String user, String securitySystems) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		log.info("********message********: " + userCount.getText());
		String entries = userCount.getText().substring(17);
		String finalEntries = entries.replace("entries", " ");
		String finalEntries2 = entries.replace("entries", " ").trim();
		log.info("No of pending tasks: " + finalEntries2);
		int rows = Integer.valueOf(finalEntries2);
		// int rows = Integer.parseInt(finalEntries2);
		log.info("********ROWs*******" + rows);
		if (userCount.getText().contains("0 entries"))
			Assert.fail("No pending task found for following user" + user);
		// Iterating over the List
		for (int i = 1; i <= rows; i++) {
			log.info("Before For loop");
			String cell = driver.findElement(By.xpath("//tr[" + i + "]//td[8]")).getText();
			String cell1 = driver.findElement(By.xpath("//tr[" + i + "]//td[8]")).getText();
			log.info("Name of security system: " + cell);
			log.info(" test0 " + securitySystems.contains("STA Disconnected 2"));
			log.info(" test1 " + cell1.contains(cell));
			// log.info(" test2 "+cell.contains(securitySystems[]));
			if (pendingTaskType.getText().contains("New Account") && securitySystems.contains(cell)) {
				log.info(" test3 " + securitySystems.contains(cell));
				log.info("pending task has been found for following user" + user);
				log.info("approving pending task");
				driver.findElement(By.xpath("//tr[" + i + "]//input[@name='pendingTasks']")).click();
				approveSelectedPendingTask();

			}
		}
	}

	/**
	 ** This method is to search user
	 * * @param username

	 */
	public void searchUser(String user) throws InterruptedException {
		try {
			search_usersList.clear();
			search_usersList.sendKeys(user);
			Thread.sleep(1000);
			searchButton.click();
			Thread.sleep(2000);
			log.info("Search user has been completed successfully");
		} catch (Exception e) {
			Assert.fail("Search user failed");

		}

	}

	/**
	 ** This method is to validate account creation of an user
	 * * @param username
	 *  * @param security system/Target System

	 */
	public void validateAccountCreation(String user, String securitySys) throws InterruptedException {
		try {

			userLink.click();
			accounts.click();
			Thread.sleep(1000);
			log.info("********message********: " + userCount.getText());
			String entries = userCount.getText().substring(18);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);
			if (userCount.getText().contains("0 entries"))
				Assert.fail("No accounts are found for following user" + user);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,1000)");
			for (int i = 1; i <= rows; i++) {
				log.info(i);
				log.info("Before For loop");
				String secsys = driver.findElement(By.xpath("//*[@id='sample2']//tbody/tr[" + i + "]//td[3]"))
						.getText();
				log.info("Xpath of the security system on accounts tab:" + "//*[@id='sample2']//tbody/tr[" + i
						+ "]//td[3]");
				log.info("Name of security system: " + secsys);
				if (securitySys.contains(secsys) && accountStatus.getText().equalsIgnoreCase("Manually Provisioned")) {
					log.info(" test2 " + securitySys.contains(secsys));
					log.info(secsys + " account has been created for following user : " + user);
				}
			}

		} catch (NoSuchElementException e) {
			// Assert.fail("Validate account creation has failed");
			log.info("Validate account creation has failed" + e);

		}

		Thread.sleep(1000);
	}

	/**
	 ** This method is to validate account creation for Birth right access
	 * * @param username
	 * * @param security system

	 */
	public void validateAccountCreationForBirthRight(String user, String securitySys)
			throws InterruptedException, AWTException {
		try {
			Thread.sleep(1000);
			log.info("********message********: " + userCount.getText());
			String entries = userCount.getText().substring(17);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);
			if (userCount.getText().contains("0 entries"))
				Assert.fail("No accounts are found for following user" + user);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,1000)");

			for (int i = 1; i <= rows; i++) {
				log.info(i);
				log.info("Before For loop");
				String secsys = driver.findElement(By.xpath("//*[@id='usersList']//tbody/tr[" + i + "]//td[9]"))
						.getText();
				log.info("Xpath of security system on Pending tasks tab:" + "//*[@id='usersList']//tbody/tr[" + i
						+ "]//td[9]");
				log.info("Name of security system: " + secsys);
				if (pendingTaskType.getText().contains("New Account") && secsys.contains(securitySys))
					log.info("pending task has been found for following user" + user);

				else if (userCount.getText().contains("0 entries"))
					Assert.fail("No pending task found for following user" + user);
				approvePendingTask();
				Thread.sleep(1000);
			}

		} catch (NoSuchElementException e) {
			// Assert.fail("Validate account creation has failed");
			log.info(e);

		}

		Thread.sleep(1000);
	}

	/**
	 ** This method is to approve a pending tasks for an user

	 */
	public void approveSelectedPendingTask() throws InterruptedException, AWTException {

		try {
			log.info("Approving selected pending Tasks");
			pendingTaskAction.click();
			Thread.sleep(1000);
			System.out.println("*****Before clicking on complete selected task*******");
			completeSelectedTask.click();
			System.out.println("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			if (completeTaskPopUp.getText().contains("Comments")) {
				Thread.sleep(4000);
				comments.sendKeys("for test automation");
				submit.click();
				log.info("Pending Task has been approved successfully");
				Thread.sleep(15000);
			}

		} catch (Exception e) {

			Assert.fail("Pending Tasks hasn't been approved");
		}

	}

	/**
	 ** This method is to approve a pending task

	 */
	public void approvePendingTask() throws InterruptedException, AWTException {

		try {
			log.info("Approving pending Task");
			taskactions.click();
			Thread.sleep(1000);
			System.out.println("*****Before clicking on complete task*******");
			complete.click();
			System.out.println("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("CompleteTask pop up header :" + completeTaskPopUp.getText());
			if (completeTaskPopUp.getText().contains("Comments")) {
				Thread.sleep(5000);
				log.info("adding comments");
				comments.sendKeys("for test automation");
				log.info("added comments");
			}

			submit.click();

			log.info("selected pending Task has been approved successfully");
			Thread.sleep(15000);

		} catch (Exception e) {
			// Assert.fail("Pending Tasks hasn't been approved");
			log.info(e);
		}

	}

	/**
	 ** This method is to discontinue a pending task for Birth right
	 * * @param username
	 *  * @param security system
	 */
	public void discontinuePendingTaskForBirthRight(String user, String securitySys)
			throws InterruptedException, AWTException {
		try {
			Thread.sleep(1000);
			log.info("********message********: " + userCount.getText());
			String entries = userCount.getText().substring(17);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			log.info("********ROWs*******" + rows);
			if (userCount.getText().contains("0 entries"))
				Assert.fail("No accounts are found for following user" + user);
			JavascriptExecutor Js1 = (JavascriptExecutor) driver;
			Js1.executeScript("window.scrollBy(0,1000)");
			for (int i = 1; i <= rows; i++) {
				log.info(i);
				log.info("Before For loop");
				String secsys = driver.findElement(By.xpath("//*[@id='usersList']//tbody/tr[" + i + "]//td[9]"))
						.getText();
				log.info("Xpath of security system on Pending tasks tab:" + "//*[@id='usersList']//tbody/tr[" + i
						+ "]//td[9]");
				log.info("Name of security system: " + secsys);
				if (pendingTaskType.getText().contains("New Account") && secsys.contains(securitySys))
					log.info("pending task has been found for following user" + user);
				else if (userCount.getText().contains("0 entries"))
					Assert.fail("No pending task found for following user" + user);
				// log.info("Approve the pending taks of the user: " + user);
				discontinuePendingTask();
				Thread.sleep(1000);

			}

		} catch (NoSuchElementException e) {
			// Assert.fail("Validate account creation has failed");
			log.info(e);

		}

		Thread.sleep(1000);
	}

	/**
	 ** This method is to discontinue  a pending task

	 */
	public void discontinuePendingTask() throws InterruptedException, AWTException {

		try {
			log.info("discontinuing pending Task");
			taskactions.click();
			Thread.sleep(1000);
			System.out.println("*****Before clicking on complete task*******");
			discontinue.click();
			System.out.println("****After clicking on complete task************");
			Thread.sleep(10000);
			log.info("discontinue pop up header :" + discontinueCheck.getText());
			if (discontinueCheck.isDisplayed()) {
				Thread.sleep(1000);
				yes.click();
				Thread.sleep(3000);
			}
			if (discontinueTaskPopUp.isDisplayed()) {
				Thread.sleep(5000);
				log.info("adding comments");
				discontinueComments.sendKeys("for test automation");
				log.info("added comments");
			}

			submitComments.click();

			log.info("selected pending Task has been discontinued successfully");
			Thread.sleep(15000);

		} catch (Exception e) {

			log.info(e);
		}

	}

	/**
	 ** This method is to validate no account creation if task is discontinued
	 *if not test case fails    
	 */
	public void validateAccountCreationAfterDiscontinuation(String user, String securitySys) throws InterruptedException {
		try {

			userLink.click();
			accounts.click();
			Thread.sleep(1000);

			log.info("********message********: " + userCount.getText());
			String entries = userCount.getText().substring(18);
			String finalEntries = entries.replace("entries", " ");
			String finalEntries2 = entries.replace("entries", " ").trim();
			log.info("No of rows: " + finalEntries2);
			int rows = Integer.valueOf(finalEntries2);
			// int rows = Integer.parseInt(finalEntries2);
			log.info("********ROWs*******" + rows);

			if (userCount.getText().contains("0 entries"))

				log.info("No accounts are found for following user " + user);
			else {
				Assert.fail("Accounts are found for following user " + user);
			}


		} catch (NoSuchElementException e) {
			//Assert.fail("Validate account creation has failed");
			log.info("Validate account creation has failed"+e);

		}

		Thread.sleep(1000);
	}


}