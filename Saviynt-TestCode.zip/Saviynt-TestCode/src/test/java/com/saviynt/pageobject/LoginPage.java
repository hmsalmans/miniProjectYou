package com.saviynt.pageobject;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.junit.Assert;

public class LoginPage {

	private WebDriver driver;

	private static Logger log = LogManager.getLogger();

	// Constructor of the page class
	public LoginPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

////Element Repository with element locators////

	@FindBy(id = "username")
	public WebElement userName;
	@FindBy(name = "j_password")
	public WebElement password;
	@FindBy(xpath = "//button[normalize-space(text()) = 'Login']")
	public WebElement login;
	@FindBy(xpath = "//*[contains(text(), 'You are logged in')]")
	public WebElement loginMessage;
	@FindBy(xpath = "//span[contains(text(),'The password entered is incorrect.')]")
	public WebElement incorrectPwd;
	@FindBy(xpath = "//span[contains(text() ,'not able to find a user')]")
	public WebElement invalidUserName;

	public void setUserName(String userId) {
		userName.sendKeys(userId);
	}

	public void setPassword(String pwd) {
		password.sendKeys(pwd);
	}

	public void setManagerUserName(String managerName) {
		userName.sendKeys(managerName);
	}

	public void setManagerPassword(String managerPwd) {
		password.sendKeys(managerPwd);
	}

	public void setAmdinName(String adminName) {
		userName.sendKeys(adminName);
	}

	public void setAmdinPassword(String adminPwd) {
		password.sendKeys(adminPwd);
	}

	public void clickSubmit() {
		login.click();
	}

	/**
	 *        * This method is to validate where user is logged into successfully. 
	 **/
	public void loginCheck() throws Exception {
		Thread.sleep(5000);
		if (loginMessage.getText().contains("You are logged in")) {
			log.info("User has logged in successfully");
		} else {
			log.info("User has not logged in successfully");
		}
	}
}
