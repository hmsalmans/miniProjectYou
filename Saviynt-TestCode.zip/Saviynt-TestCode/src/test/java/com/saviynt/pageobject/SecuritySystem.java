package com.saviynt.pageobject;

import java.awt.AWTException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.junit.Assert;

public class SecuritySystem {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();

	public SecuritySystem(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	////Element Repository with element locators////
	@FindBy(xpath = "//*[@id='dtsearch_securitysystemsList']")
	public WebElement securitySystemSearch;
	@FindBy(xpath = "(//*[@class='icon-search'])[1]")
	public WebElement securitySystemSearchButton;
	@FindBy(xpath = "(//div[@class='dataTables_info'])[2]")
	public WebElement securitySystemCount;

	/** 
	     * This method is to search security system	     
	     */
	public void SecuritySysSearch(String SecuritySysName) {

		try {
			securitySystemSearch.clear();
			securitySystemSearch.sendKeys(SecuritySysName);
			Thread.sleep(1000);
			securitySystemSearchButton.click();
			Thread.sleep(1000);
		} catch (Exception e) {
			log.info("Search Security System has failed");

		}

	}

	/** 
	     * This method is to validate security system creation
	    @	SecuirtySystemName     
	     */
	public void validateSecurityCreation(String SecuirtySystemName) throws AWTException, InterruptedException {
		if (securitySystemCount.getText().contains("0 entries"))
			Assert.fail("No security system found with following name");
		if (driver.findElement(By.xpath("//*[text()='" + SecuirtySystemName + "']")).isDisplayed())
			log.info("Security System is found");

	}

}
