package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.time.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.junit.Assert;

public class LOA_LTDPage {

	WebDriver driver;
	private static Logger log = LogManager.getLogger();

	public LOA_LTDPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	////Element Repository with element locators////
	@FindBy(xpath = "//div[@id='userImportTable']//th")
	public List<WebElement> header;
	@FindBy(xpath = "//*[@id='select2-drop']//ul//li")
	public List<WebElement> headerDrpdwn;
	@FindBy(xpath = "//*[@id='importBtn']/a[1]")
	public WebElement importBtn;
	@FindBy(xpath = "//label[1]//ins[@class='iCheck-helper']")
	public List<WebElement> yesRadioBtn;
	@FindBy(xpath = "//label[2]//ins[@class='iCheck-helper']")
	public List<WebElement> noRadioBtn;
	@FindBy(id = "dtsearch_usersList")
	public WebElement search_usersList;
	@FindBy(xpath = "//input[@placeholder ='Search']")
	public WebElement search1;
	@FindBy(xpath = "(//*[@class='icon-search'])[1]")
	public WebElement searchButton;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement userCount;
	@FindBy(xpath = "//input[@id='leaveStatus']")
	public WebElement leaveStatusField;
	@FindBy(xpath = "//input[@id='dtsearch_usersList']")
	public WebElement searchpendingTasks;
	@FindBy(xpath = "//a[@class='tooltip1']")
	public WebElement userLink;
	@FindBy(xpath = "//*[@class = 'MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@type = 'text']")
	public WebElement search;
	@FindBy(xpath = "//span[text() = 'Pending Tasks']")
	public WebElement pendingTasks;
	@FindBy(xpath = "//span[text() = 'Request History']")
	public WebElement requestHistory;
	@FindBy(xpath = "//span[text() = 'Pending Approvals']")
	public WebElement pendingApprovals;

	@FindBy(xpath = "//div[@class='tsk-success']")
	public WebElement pendingTaskType;
	@FindBy(xpath = "//*[@class='buttonAlignmt']")
	public WebElement selectFile;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement searchDropdwn;
	@FindBy(xpath = "//*[@class='btn blue']")
	// "//i[@class='glyphicon glyphicon-eye-open']")
	public WebElement upload;
	@FindBy(xpath = "//span[text() = 'Completed Tasks']")
	public WebElement completedTasks;
	@FindBy(xpath = "//a[@class='btn btn-xs default']")
	public WebElement taskactions;
	@FindBy(xpath = "//*[@class='dropdown-menu']//li[3]")
	public WebElement complete;
	@FindBy(xpath = "//a[contains(text(),'Accounts')]")
	public WebElement accounts;
	@FindBy(xpath = "//td[8]")
	public WebElement accountStatus;
	@FindBy(xpath = " //*[@id='yui-gen0-button']")
	public WebElement submit;


	/**
	 ** This method is to provide csv with LOA LTD details
	 */
	public void provideCSVWithLOALTDDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"\\C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\UsersLeaveStatusList.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		// release Contol+V for pasting
		rb.keyRelease(KeyEvent.VK_CONTROL);
		rb.keyRelease(KeyEvent.VK_V);
		Thread.sleep(1000);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);

	}

	public void uploadLOALTDDetails() throws InterruptedException, AWTException, FileNotFoundException {

		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();

		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);

		header.get(1).click();
		searchDropdwn.sendKeys("LEAVESTATUS");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		importBtn.click();
		Thread.sleep(2000);

	}

	public void validateLeaveStatus(String user, String leaveStatus) throws InterruptedException, AWTException {
		if (userCount.getText().contains("0 entries"))
			Assert.fail("No User found with following name");
		log.info("Validation of Leave status");
		userLink.click();
		Thread.sleep(2000);
		System.out.println("leaveStatusField:" + leaveStatusField.getAttribute("Value"));
		if (leaveStatusField.getAttribute("Value").equalsIgnoreCase(leaveStatus))
			log.info("Leave status has been updated successfully for the existing user: " + leaveStatus);
		else
			Assert.fail("Leave status hasn't been updated successfully for the existing user");

	}

	public void navigateToCreateUserRequest() throws InterruptedException {
		Thread.sleep(1000);
		menu.click();
		search.sendKeys("Pending Tasks");
		Thread.sleep(1000);
		pendingTasks.click();
		Thread.sleep(1000);
	}

	public void validatePendingTask(String user, String leaveStatus) throws InterruptedException, AWTException {

		// searchpendingTasks.sendKeys(user);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		if (pendingTaskType.getText().contains("Disable Account"))
			log.info("pending task has been found for following user" + user);

		else if (userCount.getText().contains("0 entries"))
			Assert.fail("No pending task found for following user" + user);
		log.info("Approve the pending taks of the user: " + user);
		approvePendingTask();

		Thread.sleep(15000);

	}
	/** 
		     * This method is to navigate to pending task
		     */

	public void navigateToPendingTasks() throws InterruptedException {
		try {
			Thread.sleep(2000);
			menu.click();
			search.sendKeys("Pending Tasks");
			Thread.sleep(4000);
			pendingTasks.click();
			Thread.sleep(1000);
			log.info("User is on pending Tasks");
		} catch (Exception e) {
			Assert.fail("Navigation has failed to pending tasks tab");

		}
	}

	/** 
	     * This method to navigate to pending approval. 

	     */

	public void navigateToPendingApproval() throws InterruptedException {
		try {
			Thread.sleep(4000);
			//driver.navigate().refresh();
			menu.click();
			search.sendKeys("Pending Approvals");
			Thread.sleep(4000);
			pendingApprovals.click();
			Thread.sleep(1000);
			log.info("User is on pending Approvals");
		} catch (Exception e) {
			Assert.fail("Navigation has failed to pending Approvals Page" +e);

		}
	}

	public void navigateToRequestHistoryPage() throws InterruptedException {
		try {
			Thread.sleep(4000);
			menu.click();
			search.sendKeys("Request History");
			Thread.sleep(4000);
			requestHistory.click();
			Thread.sleep(1000);
			log.info("User is on Request History Page");
		} catch (Exception e) {
			Assert.fail("Navigation has failed to Request History Page");

		}
	}
	public void validateCompletedTask(String user) throws InterruptedException, AWTException {
		Thread.sleep(2000);
		if (pendingTaskType.getText().contains("Disable Account"))
			log.info("Disable Account task is completed");
		else if (userCount.getText().contains("0 entries"))
			Assert.fail("Disable Account task is not completed");

	}

	public void approvePendingTask() throws InterruptedException {
		log.info("Approving pending Task");
		taskactions.click();
		Thread.sleep(1000);
		complete.click();
		Thread.sleep(4000);
		submit.click();
		Thread.sleep(1000);
		log.info("Pending Task has been approved successfully");

	}

	public void navigateTocompletedTasks() throws InterruptedException {
		try {
			driver.navigate().refresh();
			Thread.sleep(2000);
			menu.click();
			Thread.sleep(2000);
			// WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
			// wait.until(ExpectedConditions.elementToBeClickable(search));
			search.sendKeys("Completed Tasks");
			Thread.sleep(2000);
			completedTasks.click();
		} catch (Exception e) {
			Assert.fail("Navigation to completed tasks has failed");
		}

	}

	public void validateAccountStatus(String user) throws InterruptedException, AWTException {
		if (userCount.getText().contains("0 entries"))
			Assert.fail("No User found with following name");

		userLink.click();
		accounts.click();

		Thread.sleep(2000);
		if (accountStatus.getText().equalsIgnoreCase("Manually Suspended"))
			log.info("Leave status has been updated successfully for the existing user:" + user);
		else
			Assert.fail("Leave status hasn't been updated successfully for the existing user: " + user);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@class = 'MuiSvgIcon-root']")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//input[@placeholder ='Search']")).sendKeys("Users");
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[text() = 'Users']")).click();
		Thread.sleep(1000);

	}

	public void discontinuePendingTask(String user, String leaveStatus) throws InterruptedException, AWTException {

		// searchpendingTasks.sendKeys(user);
		Thread.sleep(2000);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		if (pendingTaskType.getText().contains("Disable Account"))
			log.info("pending task has been found for following user" + user);

		else if (userCount.getText().contains("0 entries"))
			Assert.fail("No pending task found for following user" + user);
		log.info("Approve the pending taks of the user: " + user);
		BirthRightAccessValidationPage birthRightAccessValidationPage = new BirthRightAccessValidationPage(driver);
		birthRightAccessValidationPage.discontinuePendingTask();

		Thread.sleep(15000);

	}

	public void validatePendingTask1(String user) throws InterruptedException, AWTException {
		log.info("searching the pending taks of the user: " + user);
		searchpendingTasks.sendKeys(user);
		Thread.sleep(2000);
		log.info("searching the pending taks of the user: " + user);
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);

		if (pendingTaskType.getText().contains("Add Access"))
			log.info("pending task has been found for following user" + user);

		else if (userCount.getText().contains("0 entries"))
			Assert.fail("No pending task found for following user" + user);
		log.info("Approve the pending taks of the user: " + user);
		approvePendingTask();

		Thread.sleep(15000);

	}

}
