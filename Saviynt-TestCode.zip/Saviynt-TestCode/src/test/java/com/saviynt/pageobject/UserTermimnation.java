package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.junit.Assert;

import com.google.common.base.Function;

public class UserTermimnation {
	WebDriver driver;

	private static Logger log = LogManager.getLogger();
	ApplicationsPage apps = new ApplicationsPage(driver);
	AdminPage ap = new AdminPage(driver);
	LogoutPage logoutPage = new LogoutPage(driver);

	public UserTermimnation(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	////Element Repository with element locators////
	@FindBy(xpath = "//button[@title='Applications']")
	public WebElement app;
	@FindBy(xpath = "//div[text()='Admin']")
	public WebElement admin;
	@FindBy(xpath = "//span[text() = 'Users']")
	public WebElement users;
	@FindBy(id = "dtsearch_usersList")
	public WebElement search_usersList;

	@FindBy(xpath = "//*[@class = 'MuiSvgIcon-root']")
	public WebElement menu;
	@FindBy(xpath = "//input[@placeholder ='Search']")
	public WebElement search;
	@FindBy(xpath = "//span[text()='One Click Disable']")
	public WebElement disable;
	@FindBy(xpath = "//input[contains(@id, 'search_myDataTable')]")
	public WebElement searchUser;
	@FindBy(xpath = "//input[@name='userkey' and @type='checkbox' and @aria-label='radio option']")
	public WebElement checkUser;
	@FindBy(xpath = "//*[@class='btn red' ]")
	public WebElement remove;
	@FindBy(xpath = "//*[@id='dcomments']")
	public WebElement commentBox;

	@FindBy(xpath = "//div[contains(text(),'You want to proceed to Disable 1 Users? Click')]")
	public WebElement dialaugeBox;
	@FindBy(xpath = "//button[1][@class='btn green' ]")
	public WebElement yesBtn;
	@FindBy(xpath = "//td[4]")
	public WebElement status;
	@FindBy(xpath = "//td[6]")
	public WebElement email;
	@FindBy(xpath = "//*[contains(text(), 'Unexpected Error occurred Please try later')]")
	public WebElement error;
	@FindBy(xpath = "//div[@class='dataTables_info']")
	public WebElement userCount;
	@FindBy(xpath = "(//*[@class='icon-search'])[1]")
	public WebElement searchButton;
	@FindBy(xpath = "(//*[@class='page-title']")
	public WebElement removeAccessForDirectReportsTitle;

	/**
	 ** This method is to navigate to one click disable page
	 */

	public void navigateToOneClickDsable() throws InterruptedException, AWTException {
		try {
			menu.click();
			search.sendKeys("One Click Disable");
			Thread.sleep(1000);
			disable.click();
			Thread.sleep(1000);
			if (removeAccessForDirectReportsTitle.getText().contains("Remove Access For Direct Report")) {
				log.info("User is on REmove Access for Direct Reports Page");
			}
		} catch (NoSuchElementException e) {
			log.info("Element Not found Exception");
		}
	}

	/**
	 ** This method is to search user
	 ** @param extendDate
	 */
	public void selectTerminatingUser(String user) throws AWTException, InterruptedException {
		searchUser.sendKeys(user);
		searchButton.click();
		Robot robot = new Robot(); // Robot class throws AWT Exception
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(6000);
		checkUser.click();
	}

	/**
	 ** This method is to disable user
	 */
	public void removeAccess() throws InterruptedException, AWTException {
		Thread.sleep(5000);

		Robot robot = new Robot(); // Robot class throws AWT Exception
		Thread.sleep(2000);

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(2000);

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(2000);

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(2000);

		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(2000);
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		remove.click();
		// Thread.sleep(5000);
		// System.out.println("**************");
		isLoaded();
		// System.out.println(dialaugeBox.getText());
		if (dialaugeBox.getText().contains("You want to proceed to Disable 1 Users? Click")) {
			commentBox.sendKeys("For testing");
			yesBtn.click();
		}

	}

	/**
	 ** This method is to check leave status
	 */
	public void checkStatus(String user) throws AWTException, InterruptedException {
		try {

			Thread.sleep(4000);
			/*
			 * if(error.isDisplayed()) Assert.fail(error.getText());
			 * 
			 * logoutPage.clickLogout(); driver.quit();
			 */
			search_usersList.clear();
			search_usersList.sendKeys(user);
			searchButton.click();

			Thread.sleep(2000);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
			Thread.sleep(2000);

			if (userCount.getText().contains("0 entries"))
				Assert.fail("No User found with following name");
		} catch (Exception e) {

			e.printStackTrace();
		}

	}
	/**
	 ** This method is to validate leave status
	 */
	public void validateStatus() throws AWTException, InterruptedException {
		try {

			String statusInfo = status.getText();

			if (statusInfo.equalsIgnoreCase("Inactive"))
				log.info("staus of user is " + statusInfo + " as expected");
			else
				Assert.fail("staus of user is " + statusInfo + ".Not as expected");

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	public void isLoaded() throws Error {
		new FluentWait<WebDriver>(driver).withTimeout(Duration.ofSeconds(30)).pollingEvery(Duration.ofSeconds(5))
		.ignoring(NoSuchElementException.class).ignoring(StaleElementReferenceException.class)
		.until(new Function<WebDriver, Boolean>() {
			public Boolean apply(WebDriver webDriver) {
				WebElement element = dialaugeBox;
				System.out.println("Waiting for the element");
				return element != null && element.isDisplayed();
			}
		});
	}

}