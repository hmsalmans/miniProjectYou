package com.saviynt.pageobject;

import java.awt.AWTException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.junit.Assert;

public class ApplicationsPage {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();
	public ApplicationsPage(WebDriver driver) {
		//super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
		
	}
////	Element Repository with element locators////
	@FindBy(xpath = "//button[@title='Applications']")
	public WebElement app;
	@FindBy(xpath = "//div[text()='Home']")
	public WebElement home;
	@FindBy(xpath = "//span[text()='Home']")
	public WebElement homeTitle;
	@FindBy(xpath = "//div[text()='Admin']")
	public WebElement admin;
	@FindBy(xpath = "//div[text()='SOD']")
	public WebElement sod;
	@FindBy(xpath = "//div[text()='Certifications']")
	public WebElement certifications;

	 /** 
	     * This method is to navigate to home page

	     */
	public void navigateToHomePage() throws AWTException, InterruptedException {
		try {
			Thread.sleep(1000);
			app.click();
			home.click();
			Thread.sleep(4000);
			if (homeTitle.isDisplayed())
				log.info("Successfully Navigated to Home page");
			else
				log.info("Fail to Navigate to Home Page");
		} catch (NoSuchElementException e) {
			log.info("Element not found");

		}

	}
	
	
}
