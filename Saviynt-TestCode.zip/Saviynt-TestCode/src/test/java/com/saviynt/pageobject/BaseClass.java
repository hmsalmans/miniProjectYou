package com.saviynt.pageobject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import com.google.common.base.Function;
import com.utils.BrowserUtil;
import com.utils.ExcelUtil;

public class BaseClass {

	public Logger log = LogManager.getLogger();
	public String userId;
	public String pwd;
	public static WebDriver driver;
	BrowserUtil browser = new BrowserUtil();
	private Properties properties;
	
	/**
	 ** This Base Class constructor . Reading the property file

	 */
	public BaseClass() {
		log.info("&&&&&&&&&&&&&&&&&");
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader(System.getProperty("user.dir") + "//src//test//resources//configs//Saviynt_NewQA.properties"));
			properties = new Properties();
			try {
				properties.load(reader);
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException("Configuration.properties not found at " + System.getProperty("user.dir") + "//src//test//resources//configs//Saviynt_NewQA.properties");
		}		
		 String brwser = getValue("browser");
		 driver = browser.getDriver(brwser);
		 log.info(driver);

	}
	
	/**
	 ** This method is to return the value from property file
	 *@param key 
	 */
	public String getValue(String key){
		String value = properties.getProperty(key);
		if(value!= null) 
			return value;
		else throw new RuntimeException(key + " not specified in the properties file.");		
	}
	
	/**
	 ** This method is to return the values from property file
	 *@param key 
	 */
	public String[] getValues(String key){
		String[] value = properties.getProperty(key).split(",");
		if(value!= null) 
			return value;
		else throw new RuntimeException(key + " not specified in the properties file.");		
	}
	
	/**
	 ** This method is to return integer value from property file
	 *@param key 
	 */
	public int getIntValue(String key){
		String value = properties.getProperty(key);
		int newValue=Integer.parseInt(value);
		if(newValue!= 0) 
			return newValue;
		else throw new RuntimeException(key + " not specified in the properties file.");		
	}
	
	/**
	 ** This method is to highlight an weblement
	 */
	public static void highLightElement(WebDriver driver, WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);

		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println(e.getMessage());
		}

		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element);
	}
	
	/**
	 ** This method is to take screenshot of every step mentioned in the feature file

	 */
	public static void takeSnapShot(WebDriver webdriver, String fileName) throws Exception {

		TakesScreenshot scrShot = ((TakesScreenshot) webdriver);
		File srcFile = scrShot.getScreenshotAs(OutputType.FILE);
		// Open the current date and time
		String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
		File DestFile = new File(".//Screenshot//" + fileName + "-" + timestamp + ".png");
		// Copy the screenshot on the desire location with different name using current
		// date and time
		FileUtils.copyFile(srcFile, DestFile);
	}

	/**
	 ** This method is to attach the screenshot to the report . Called in the hooks
	 */
	public static byte[] getByteScreenshot() throws IOException {
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		byte[] fileContent = FileUtils.readFileToByteArray(srcFile);
		return fileContent;
		
	}
	

}