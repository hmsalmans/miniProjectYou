package com.saviynt.pageobject;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mortbay.log.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.junit.Assert;

public class ChangeOfPosition {
	WebDriver driver;
	private static Logger log = LogManager.getLogger();

	public ChangeOfPosition(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

////Element Repository with element locators////
	@FindBy(xpath = "//*[@class='buttonAlignmt']")
	public WebElement selectFile;
	@FindBy(xpath = "//label[1]//ins[@class='iCheck-helper']")
	public List<WebElement> yesRadioBtn;
	@FindBy(xpath = "//*[@class='btn blue']")
	public WebElement upload;
	@FindBy(xpath = "//div[@id='userImportTable']//th")
	public List<WebElement> header;
	@FindBy(xpath = "//*[@id='select2-drop']//div//input")
	public WebElement searchDropdwn;
	@FindBy(xpath = "//*[@id='importBtn']/a[1]")
	public WebElement importBtn;

	 /** 
	     * This method is to provide csv files with details with details of new job code and Status details of user. 
	    **/

	
	public void provideCSVWithDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		selectFile.click();
		Thread.sleep(2000);
		Robot rb = new Robot();
		StringSelection str = new StringSelection(
				"\\C:\\Saviyant-auto\\allianceod_saviynt_testautomation\\src\\test\\resources\\TestData\\ChangeOfPositionUsersList.csv");

		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, null);
		// press Contol+V for pasting
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		Thread.sleep(1000);
		Thread.sleep(1000);
		// for pressing and releasing Enter
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(1000);

	}
	
	 /** 
	     * This method is to upload user request details using user upload link in Saviynt
	    **/

	public void uploadUserRequestWithUdateDetails() throws InterruptedException, AWTException, FileNotFoundException {
		Thread.sleep(4000);
		// firstRowHeadingRadiobtn.click();
		yesRadioBtn.get(0).click();
		Thread.sleep(2000);
		yesRadioBtn.get(1).click();
		Thread.sleep(2000);
		yesRadioBtn.get(2).click();
		Thread.sleep(2000);
		yesRadioBtn.get(3).click();
		Thread.sleep(2000);
		yesRadioBtn.get(4).click();
		Thread.sleep(4000);
		upload.click();
		Thread.sleep(2000);
		header.get(1).click();
		searchDropdwn.sendKeys("FIRSTNAME");
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(2).click();
		searchDropdwn.sendKeys("LASTNAME");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(3).click();
		searchDropdwn.sendKeys("STATUSKEY");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		Thread.sleep(2000);
		header.get(6).click();
		searchDropdwn.sendKeys("JOBCODE");
		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);
		//Thread.sleep(2000);
		Thread.sleep(3000);
		importBtn.click();
		Thread.sleep(2000);

	}

}