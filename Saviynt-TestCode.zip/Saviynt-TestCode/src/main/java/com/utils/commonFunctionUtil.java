package com.utils;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.time.Duration;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Properties;
import org.zeroturnaround.zip.ZipUtil;
import org.apache.commons.io.comparator.LastModifiedFileComparator;
import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.SimpleEmail;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class commonFunctionUtil  {
	private static Logger log = LogManager.getLogger();
	public static WebDriver driver;
	private static final String OUTPUT_ZIP_FOLDER = "C://Saviyant-auto//allianceod_saviynt_testautomation//test-output//Report.zip";
	private static String SOURCE_FOLDER; // SourceFolder path

	/**
	 * * This method is for Explicit wait for a WebElement display and ready
	 * to be clickable       * Time out of 1 min     
	 */

	public static void waitElementToBeClickable(WebElement element) throws Error {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(60));
		wait.until(ExpectedConditions.elementToBeClickable(element));

	}

	/**
	 * * This method is browser hard refresh      
	 */
	public static void browerRefesh() {
		driver.navigate().refresh();

	}

	/**
	 * * This method is to send latest execution report to specific mail ids     
	 */
	public void sendEmail(String hostName, int portNumber,String attachmentDescription,String[]toMailIds, String fromMailId, String encryptedKey,String mailSubject,String mailBody) {
		/**Zip the report folder ***/
		zipReport(SOURCE_FOLDER,OUTPUT_ZIP_FOLDER);
		/**Create the attachment- final test execution report ***/
		EmailAttachment attachment = new EmailAttachment();
		attachment.setPath(OUTPUT_ZIP_FOLDER);
		attachment.setDisposition(EmailAttachment.ATTACHMENT);
		attachment.setDescription(attachmentDescription);
		attachment.setName(attachmentDescription);
		/**Create the email template for sending out the execution report ***/
		MultiPartEmail email = new MultiPartEmail();
		email.setHostName(hostName);
		email.setSmtpPort(portNumber);
		email.setAuthenticator(new DefaultAuthenticator(fromMailId, encryptedKey));
		email.setSSLOnConnect(true);
		try {
			email.setFrom(fromMailId);
			email.setSubject(mailSubject);
			email.setMsg(mailBody);
			for(String toMailId:toMailIds) {
				email.addTo(toMailId);
			}
			// add the attachment
			email.attach(attachment);
			email.send();
			log.info("***********Email sent****");
		} catch (EmailException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * * This method is to zip the report folder  
	 */
	
	public static void zipReport(String Sourcepath, String outputPath) {
		log.info("Source folder: "+Sourcepath);
		//Sourcepath=Sourcepath.replaceAll("\","//");
		Sourcepath = Sourcepath.replaceAll("\\\\","//");
		log.info("modified path: "+Sourcepath);
		ZipUtil.pack(new File(Sourcepath), new File(outputPath),true);
	}

	/**
	 * * This method is to sort the output folder and select the latest folder and zip it 
	 */
	
	public static String getLatestReportFolders() {
		String path="C://Saviyant-auto//allianceod_saviynt_testautomation//test-output";
		File file=new File(path);
		File report[]=file.listFiles();
		Arrays.sort(report);
		log.info(report[0]);
		if (report[0].isDirectory()) {
				log.info("Directory: " +report[0].getName()+ report[0].getAbsolutePath());
				SOURCE_FOLDER=report[0].getAbsolutePath();
			}else {
				log.info("Uknown: " +report[0].getName());
			}
		
		return SOURCE_FOLDER;
	}

}
