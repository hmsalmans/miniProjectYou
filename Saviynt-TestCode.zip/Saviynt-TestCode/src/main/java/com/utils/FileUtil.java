
package com.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.apache.commons.io.FileUtils;

public class FileUtil {
	public static void createDirectory() {
		try {

			Path path = Paths.get("C:\\Saviynt\\saviyntAutomation\\Screenshot");

			Files.createDirectories(path);

			System.out.println("Directory is created!");

		} catch (IOException e) {

			System.err.println("Failed to create directory!" + e.getMessage());

		}
	}

	public static void deleteDir(File dirFile) {
		if (dirFile.isDirectory()) {
			File[] dirs = dirFile.listFiles();
			for (File dir : dirs) {
				deleteDir(dir);
			}
		}
		dirFile.delete();
	}

	private static InputStream toInputStream(File storeFile) throws IOException {
		byte[] data = FileUtils.readFileToByteArray(storeFile);
		return new ByteArrayInputStream(data);
	}
}
