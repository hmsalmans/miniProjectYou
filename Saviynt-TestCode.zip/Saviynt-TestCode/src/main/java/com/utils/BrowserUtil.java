package com.utils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserUtil {
	public WebDriver driver;
	public static String browser =  " " ;//PropertiesUtil.getValue("url") ;
	
	public WebDriver getDriver(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			ChromeOptions options = new ChromeOptions();
			options.addArguments("--no-sandbox"); // Bypass OS security model
			options.addArguments("start-maximized"); // open Browser in maximized mode
			options.addArguments("disable-infobars"); // disabling info bars
			options.addArguments("--disable-extensions"); // disabling extensions
			options.addArguments("--disable-gpu"); // applicable to windows os only
			options.addArguments("--disable-dev-shm-usage"); // overcome limited resource problems
			options.addArguments("user-data-dir=C:\\environments\\selenium") ;//changing the directory
			driver = WebDriverManager.chromedriver().capabilities(options).create(); // running with chrome options
			System.out.println("**************");
		}

		if (browser.equalsIgnoreCase("edge")) {
			driver = WebDriverManager.edgedriver().create(); // using webdriver manager to set the binaries
			System.out.println("**************");
		}

		else if (browser.equalsIgnoreCase("Firefox")) {
			FirefoxOptions options = new FirefoxOptions();
			//Accept all the certificate
			options.setAcceptInsecureCerts(true);
			driver = new FirefoxDriver(options);
			//driver = WebDriverManager.firefoxdriver().create(); // using webdriver manager to set the binaries
			System.out.println("**************");
		}
		return driver;
		
	}

}