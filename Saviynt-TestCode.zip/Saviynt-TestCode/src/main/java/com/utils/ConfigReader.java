package com.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {
	private Properties prop;

	public Properties init_prop() {
		prop=new Properties();
		try {
			FileReader reader = new FileReader(
					System.getProperty("user.dir") + "\\src\\test\\resources\\configs\\Saviynt_NewQA.properties");
			try {
				prop.load(reader);
			} catch (IOException e) {

				e.printStackTrace();
			}
			String url = prop.getProperty("url");


		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		return prop;
	}


}
