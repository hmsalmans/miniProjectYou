package com.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class ExcelUtil {
	XSSFWorkbook workbook;
	XSSFSheet sheet;

	//Constructor of the ExcelUtil class for accepting excel path and sheetname
	public ExcelUtil(String excelPath,String sheetName) {
		try {

			workbook = new XSSFWorkbook(excelPath);
			// Get desired sheet from the workbook
			sheet = workbook.getSheet(sheetName);

		}catch(Exception e) {
			e.printStackTrace();

		}

	}

	//Read cell value based on the rowNumber and column number
	public String readCellValue(int RowNum, int ColNum) {
		try {
			FormulaEvaluator formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
			XSSFRow row = sheet.getRow(RowNum);

			String cellData = "";
			XSSFCell cell = row.getCell(ColNum);
			cell.setCellType(CellType.STRING);
			cellData = cell.getStringCellValue();
			return cellData;

		} catch (Exception e) {
			return "undefined";
		}

	}

	public String readCellValueForSOD(int RowNum, int ColNum) {

		try {
			FileInputStream file = new FileInputStream(
					new File("C://Saviyant-auto//allianceod_saviynt_testautomation//src//test//resources//TestData//InputParameterForSODViolation.xlsx"));

			// Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			// Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheetAt(1);

			FormulaEvaluator formulaEvaluator = workbook.getCreationHelper().createFormulaEvaluator();
			XSSFRow row = sheet.getRow(RowNum);

			String cellData = "";
			XSSFCell cell = row.getCell(ColNum);
			cell.setCellType(CellType.STRING);
			cellData = cell.getStringCellValue();
			return cellData;

		} catch (Exception e) {
			return "undefined";
		}

	}
}